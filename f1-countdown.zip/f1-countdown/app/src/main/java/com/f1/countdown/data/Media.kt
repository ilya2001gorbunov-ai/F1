package com.f1.countdown.data

import android.content.Context
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Настоящие логотипы команд и фото пилотов.
 * Источники: Википедия / Викиданные / Wikimedia Commons (официальные логотипы и портреты).
 * Найденные адреса запоминаются на устройстве, поэтому повторно из сети ищутся только один раз.
 */
object Media {
    private const val PREFS = "media_cache"
    private val mem = ConcurrentHashMap<String, String>()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun segment(wikiUrl: String): String? =
        wikiUrl.substringAfter("/wiki/", "").substringBefore('#').substringBefore('?').takeIf { it.isNotBlank() }

    /** Кэш: пустая строка = «изображения нет» (запоминаем). Ошибка сети — исключение, ничего не запоминаем. */
    private fun cached(ctx: Context, key: String, compute: () -> String?): String? {
        mem[key]?.let { return it.ifEmpty { null } }
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.getString(key, null)?.let {
            mem[key] = it
            return it.ifEmpty { null }
        }
        val v = compute() ?: ""
        mem[key] = v
        prefs.edit().putString(key, v).apply()
        return v.ifEmpty { null }
    }

    /** Адрес логотипа команды по constructorId (например «mercedes»), либо null. */
    fun teamLogo(ctx: Context, teamId: String): String? = try {
        cached(ctx, "team:$teamId") {
            val ct = JSONObject(Http.getString("https://api.jolpi.ca/ergast/f1/constructors/$teamId.json"))
                .getJSONObject("MRData").getJSONObject("ConstructorTable").getJSONArray("Constructors")
            val title = ct.optJSONObject(0)?.optString("url")?.let { segment(it) } ?: return@cached null
            val pages = JSONObject(
                Http.getString(
                    "https://en.wikipedia.org/w/api.php?action=query&prop=pageprops&ppprop=wikibase_item" +
                        "&redirects=1&format=json&titles=$title",
                ),
            ).getJSONObject("query").getJSONObject("pages")
            val qid = pages.keys().asSequence().firstNotNullOfOrNull {
                pages.getJSONObject(it).optJSONObject("pageprops")?.optString("wikibase_item")?.takeIf { q -> q.isNotBlank() }
            } ?: return@cached null
            val claims = JSONObject(
                Http.getString(
                    "https://www.wikidata.org/w/api.php?action=wbgetclaims&format=json&entity=$qid&property=P154",
                ),
            ).optJSONObject("claims")?.optJSONArray("P154")
            val file = claims?.optJSONObject(0)?.optJSONObject("mainsnak")?.optJSONObject("datavalue")
                ?.optString("value")?.takeIf { it.isNotBlank() } ?: return@cached null
            "https://commons.wikimedia.org/wiki/Special:FilePath/${enc(file)}?width=256"
        }
    } catch (_: Exception) {
        null
    }

    /** Адрес фото пилота по ссылке на его страницу в Википедии (поле url из Ergast), либо null. */
    fun driverPhoto(ctx: Context, wikiUrl: String): String? = try {
        val title = segment(wikiUrl)
        if (title == null) {
            null
        } else {
            cached(ctx, "drv:$title") {
                JSONObject(Http.getString("https://en.wikipedia.org/api/rest_v1/page/summary/$title"))
                    .optJSONObject("thumbnail")?.optString("source")?.takeIf { it.isNotBlank() }
            }
        }
    } catch (_: Exception) {
        null
    }
}
