@file:OptIn(ExperimentalMaterial3Api::class)

package com.f1.countdown.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.f1.countdown.widget.RaceWidgetProvider
import com.f1.countdown.widget.WidgetKind

@Composable
fun App() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val ctx = LocalContext.current
    val bg = MaterialTheme.colorScheme.background
    var showWidgetPicker by remember { mutableStateOf(false) }

    if (showWidgetPicker) {
        AlertDialog(
            onDismissRequest = { showWidgetPicker = false },
            title = { Text("Добавить виджет") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    for (kind in WidgetKind.entries) {
                        // одно и то же действие для примера и для подписи под ним
                        val pin = {
                            showWidgetPicker = false
                            if (!RaceWidgetProvider.requestPin(ctx, kind)) {
                                Toast.makeText(
                                    ctx,
                                    "Долгое нажатие на рабочем столе → Виджеты → F1",
                                    Toast.LENGTH_LONG,
                                ).show()
                            }
                        }
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .clickable(onClick = pin)
                                .padding(vertical = 8.dp),
                        ) {
                            WidgetPreview(
                                kind,
                                if (kind.compact) {
                                    Modifier.size(140.dp)
                                } else {
                                    Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(2.2f)
                                },
                                onClick = pin,
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(kind.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                "Нажмите, чтобы добавить на главный экран",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showWidgetPicker = false }) { Text("Отмена") }
            },
        )
    }

    Scaffold(
        containerColor = bg,
        topBar = {
            TopAppBar(
                title = {
                    Text("FORMULA 1", fontWeight = FontWeight.Black, letterSpacing = 2.sp, color = F1Red)
                },
                actions = {
                    TextButton(onClick = { showWidgetPicker = true }) { Text("+ Виджет") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = bg),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("📰") },
                    label = { Text("Новости") },
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("📅") },
                    label = { Text("Календарь") },
                )
                NavigationBarItem(
                    selected = tab == 3,
                    onClick = { tab = 3 },
                    icon = { Text("🏆") },
                    label = { Text("Зачёт") },
                )
                NavigationBarItem(
                    selected = tab == 2,
                    onClick = { tab = 2 },
                    icon = { Text("🔴") },
                    label = { Text("LIVE") },
                )
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> NewsScreen(onOpenLive = { tab = 2 }); 1 -> CalendarScreen(); 3 -> StandingsScreen(); else -> LiveScreen() }
        }
    }
}
