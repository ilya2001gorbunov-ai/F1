package com.f1.countdown.data

import android.content.Context
import java.time.Duration
import java.time.Instant

/**
 * Запоминает сессии, чью трансляцию на главном экране уже не нужно показывать:
 * эфир закончился (приложение это заметило) или пользователь закрыл карточку крестиком.
 * Записи хранятся на устройстве, поэтому карточка не возвращается после перезапуска приложения.
 */
object LiveState {
    private const val PREFS = "live_state"
    private const val KEY = "hidden"

    fun key(s: Session): String = "${s.round}_${s.type.name}_${s.start.epochSecond}"

    fun load(ctx: Context): Set<String> = try {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY, emptySet())
            ?.toSet()
            ?: emptySet()
    } catch (_: Exception) {
        emptySet()
    }

    /** Добавляет сессию в список скрытых и возвращает обновлённый список. */
    fun add(ctx: Context, s: Session): Set<String> {
        // старше недели записи не нужны — выбрасываем, чтобы список не рос
        val weekAgo = Instant.now().minus(Duration.ofDays(7)).epochSecond
        val next = (load(ctx) + key(s)).filter {
            (it.substringAfterLast('_').toLongOrNull() ?: 0L) > weekAgo
        }.toSet()
        try {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putStringSet(KEY, next)
                .apply()
        } catch (_: Exception) {
        }
        return next
    }
}
