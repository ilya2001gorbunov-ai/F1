package com.f1.countdown.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1.countdown.data.StandingsData
import com.f1.countdown.data.StandingsRepo

/** Раздел «Зачёт»: личный зачёт пилотов и кубок конструкторов текущего сезона. */
@Composable
fun StandingsScreen() {
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    var reload by remember { mutableIntStateOf(0) }
    var sel by remember { mutableIntStateOf(0) }
    val state by produceState<Pair<Boolean, StandingsData?>>(false to null, reload) {
        value = true to StandingsRepo.load()
    }
    val (loaded, data) = state

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            listOf("Пилоты", "Команды").forEachIndexed { i, label ->
                val on = i == sel
                Text(
                    label,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                    color = if (on) Color.White else gray,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(if (on) F1Red else Color.Transparent)
                        .clickable { sel = i }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }
        when {
            !loaded -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = F1Red) }
            data == null -> Column(Modifier.padding(top = 24.dp)) {
                Text("Не удалось загрузить зачёт. Проверьте интернет.", color = gray)
                Spacer(Modifier.size(8.dp))
                Text(
                    "Повторить",
                    color = F1Red,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { reload++ },
                )
            }
            sel == 0 -> LazyColumn {
                items(data.drivers) { d ->
                    Line(d.pos, d.teamId, d.team, d.name, d.team, d.points, d.wins)
                }
            }
            else -> LazyColumn {
                items(data.teams) { t ->
                    Line(t.pos, t.teamId, t.team, t.team, "", t.points, t.wins)
                }
            }
        }
    }
}

@Composable
private fun Line(pos: String, teamId: String, team: String, title: String, sub: String, points: String, wins: String) {
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            pos,
            modifier = Modifier.width(28.dp),
            fontWeight = FontWeight.Bold,
            color = if (pos == "1") F1Red else gray,
        )
        TeamBadge(teamId, team, 32.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(points, fontWeight = FontWeight.Bold)
            Text(if (wins != "0" && wins.isNotEmpty()) "побед: $wins" else "очки", fontSize = 11.sp, color = gray)
        }
    }
}
