package com.f1.countdown.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.layout.ContentScale
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.f1.countdown.data.Media
import com.f1.countdown.data.USER_AGENT
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

private class TeamStyle(val color: Color, val abbr: String)

private val teamStyles = mapOf(
    "mclaren" to TeamStyle(Color(0xFFFF8000), "MCL"),
    "ferrari" to TeamStyle(Color(0xFFE80020), "SF"),
    "red_bull" to TeamStyle(Color(0xFF3671C6), "RB"),
    "mercedes" to TeamStyle(Color(0xFF27F4D2), "AMG"),
    "williams" to TeamStyle(Color(0xFF64C4FF), "W"),
    "aston_martin" to TeamStyle(Color(0xFF229971), "AM"),
    "alpine" to TeamStyle(Color(0xFF0093CC), "A"),
    "haas" to TeamStyle(Color(0xFFB6BABD), "H"),
    "rb" to TeamStyle(Color(0xFF6692FF), "VCARB"),
    "sauber" to TeamStyle(Color(0xFF52E252), "S"),
    "audi" to TeamStyle(Color(0xFFF50537), "AUDI"),
    "cadillac" to TeamStyle(Color(0xFFB0B7BF), "CAD"),
    "renault" to TeamStyle(Color(0xFFFFF500), "R"),
    "alphatauri" to TeamStyle(Color(0xFF2B4562), "AT"),
    "alfa" to TeamStyle(Color(0xFF900000), "AR"),
)

/**
 * Значок команды. Если в res/drawable лежит файл team_<constructorId> (например team_ferrari.png),
 * показывается он (можно положить настоящие логотипы). Иначе рисуется круг в цвете команды.
 */
@Composable
fun TeamBadge(teamId: String, teamName: String, size: Dp = 32.dp) {
    val ctx = LocalContext.current
    val logo by produceState<String?>(null, teamId) {
        value = withContext(Dispatchers.IO) { Media.teamLogo(ctx.applicationContext, teamId) }
    }
    val url = logo
    if (url != null) {
        // настоящий логотип на светлой подложке (тёмные логотипы читаются и на тёмной теме)
        SubcomposeAsyncImage(
            model = ImageRequest.Builder(ctx).data(url).addHeader("User-Agent", USER_AGENT).crossfade(true).build(),
            contentDescription = teamName,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color(0xFFF2F2F2))
                .padding(size * 0.14f),
            error = { FallbackBadge(teamId, teamName, size) },
        )
        return
    }
    FallbackBadge(teamId, teamName, size)
}

@Composable
private fun FallbackBadge(teamId: String, teamName: String, size: Dp) {
    val ctx = LocalContext.current
    val resId = remember(teamId) { ctx.resources.getIdentifier("team_$teamId", "drawable", ctx.packageName) }
    if (resId != 0) {
        Image(painterResource(resId), contentDescription = teamName, modifier = Modifier.size(size))
        return
    }
    val style = teamStyles[teamId] ?: TeamStyle(
        Color.hsv((abs(teamId.hashCode()) % 360).toFloat(), 0.5f, 0.6f),
        teamName.take(3).uppercase(),
    )
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(style.color),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            style.abbr,
            fontSize = (size.value * 0.30f).sp,
            fontWeight = FontWeight.Black,
            maxLines = 1,
            color = if (style.color.luminance() > 0.5f) Color.Black else Color.White,
        )
    }
}
