@file:OptIn(ExperimentalMaterial3Api::class)

package com.f1.countdown.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.produceState
import androidx.compose.ui.platform.LocalContext
import com.f1.countdown.data.Sessions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.f1.countdown.data.Fmt
import com.f1.countdown.data.NewsItem
import com.f1.countdown.data.NewsRepo
import com.f1.countdown.data.Schedule
import com.f1.countdown.data.countdown
import kotlinx.coroutines.launch

@Composable
fun NewsScreen(onOpenLive: () -> Unit = {}) {
    var items by remember { mutableStateOf<List<NewsItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val appCtx = LocalContext.current.applicationContext
    val sessions by produceState(Sessions.builtIn()) {
        withContext(Dispatchers.IO) { Sessions.cached(appCtx) }?.let { value = it }
    }
    val clock by rememberNow(30_000)
    val liveSession = sessions.firstOrNull { isLiveNow(it, clock) }

    fun refresh() {
        scope.launch {
            loading = true
            val r = NewsRepo.load()
            if (r.isNotEmpty()) items = r
            failed = r.isEmpty()
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (liveSession != null) item(key = "live-player") { LiveStreamCard(liveSession, onOpenLive) }
        item { NextRaceCard() }
        item {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                SectionTitle("Новости")
                if (loading) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = F1Red)
                } else {
                    TextButton(onClick = { refresh() }) { Text("Обновить") }
                }
            }
        }
        if (failed) {
            item {
                Text(
                    "Не удалось загрузить новости. Проверьте интернет и нажмите «Обновить».",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        items(items) { NewsCard(it) }
    }
}

@Composable
private fun NewsCard(n: NewsItem) {
    val uri = LocalUriHandler.current
    Card(
        onClick = { runCatching { uri.openUri(n.link) } },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column {
            if (n.image != null) {
                AsyncImage(
                    model = n.image,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                )
            }
            Column(Modifier.padding(14.dp)) {
                Text(n.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (n.summary.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        n.summary,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(8.dp))
                val date = n.date?.let { " · " + Fmt.newsDate(it) } ?: ""
                Text(
                    n.source + date,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun NextRaceCard() {
    val now by rememberNow(1000)
    val race = Schedule.next(now)
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        if (race == null) {
            Box(Modifier.padding(20.dp)) { Text("Сезон 2026 завершён. До встречи в новом сезоне!") }
            return@Card
        }
        val cd = countdown(race, now)
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (cd.started) "ГОНКА ИДЁТ" else "БЛИЖАЙШАЯ ГОНКА",
                    style = MaterialTheme.typography.labelSmall,
                    color = F1Red,
                    fontWeight = FontWeight.Bold,
                )
                Text("${race.flag} ${race.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    "${race.circuit} · ${race.city}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(4.dp))
                Text(Fmt.full(race), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(10.dp))
                Row {
                    CountBox(cd.days.toString(), "ДНЕЙ")
                    CountBox(Fmt.two2(cd.hours), "ЧАСОВ")
                    CountBox(Fmt.two2(cd.minutes), "МИНУТ")
                    CountBox(Fmt.two2(cd.seconds), "СЕК")
                }
            }
            TrackImage(race, Modifier.size(96.dp), stroke = 2.5.dp)
        }
    }
}
