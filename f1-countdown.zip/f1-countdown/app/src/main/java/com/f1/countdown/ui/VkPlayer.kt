package com.f1.countdown.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.f1.countdown.data.LiveState
import com.f1.countdown.data.Schedule
import com.f1.countdown.data.Session
import com.f1.countdown.data.SessionType
import kotlinx.coroutines.delay
import java.time.Duration
import java.time.Instant

/** Страница видео сообщества VK с комментаторами (vk.ru/f1commentatorsnews). */
private const val VK_CHANNEL_URL = "https://vk.ru/video/@f1commentatorsnews"

/** Пока эфира на странице канала нет, страница перезагружается так часто — чтобы подхватить только что начавшийся эфир. */
private const val RELOAD_EVERY_MS = 45_000L

// ---------------------------------------------------------------------------------------------
// Когда показывать карточку с трансляцией
// ---------------------------------------------------------------------------------------------

/** Карточка появляется ровно в момент старта сессии. Чтобы показывать её заранее, поставьте здесь, например, Duration.ofMinutes(10). */
private val LIVE_LEAD: Duration = Duration.ZERO

/**
 * Через сколько после старта карточка пропадает в любом случае.
 * Гонка — 3 часа (больше регламент не допускает даже с остановками), остальные сессии короче.
 * Если эфир закончится раньше, карточка скроется сама (см. определение конца эфира ниже).
 */
private fun liveCap(type: SessionType): Duration = when (type) {
    SessionType.RACE -> Duration.ofHours(3)
    SessionType.QUALI -> Duration.ofHours(2)
    else -> Duration.ofMinutes(90)
}

/** Попадает ли момент now в окно показа карточки для этой сессии. */
fun isLiveNow(s: Session, now: Instant): Boolean {
    val from = s.start.minus(LIVE_LEAD)
    val to = s.start.plus(liveCap(s.type))
    return !now.isBefore(from) && now.isBefore(to)
}

/**
 * Сессия, которую надо показать на главном экране прямо сейчас (или null).
 * Состояние пересчитывается ровно в моменты старта и конца окон, а не раз в полминуты,
 * поэтому карточка появляется и исчезает в точное время. [hidden] — уже закончившиеся или скрытые сессии.
 */
@Composable
fun rememberLiveSession(sessions: List<Session>, hidden: Set<String>): State<Session?> =
    produceState<Session?>(null, sessions, hidden) {
        while (true) {
            val now = Instant.now()
            value = sessions
                .filter { isLiveNow(it, now) && LiveState.key(it) !in hidden }
                .maxByOrNull { it.start }
            val nextBoundary = sessions
                .flatMap { listOf(it.start.minus(LIVE_LEAD), it.start.plus(liveCap(it.type))) }
                .filter { it.isAfter(now) }
                .minOrNull()
            val wait = if (nextBoundary == null) 30_000L else Duration.between(now, nextBoundary).toMillis() + 100
            delay(wait.coerceIn(500L, 30_000L))
        }
    }

// ---------------------------------------------------------------------------------------------
// Поиск эфира на странице VK и определение его окончания
// ---------------------------------------------------------------------------------------------

enum class PlayerStatus { SEARCHING, WAITING, LIVE }

/**
 * Скрипт, который работает внутри страницы VK (раз в 3 секунды):
 *  1. На странице канала ищет ссылку с пометкой LIVE / «Прямой эфир» / «В эфире» и открывает её.
 *     Если за 12 секунд такой ссылки нет — сообщает приложению «эфира нет» (noLive).
 *  2. На странице видео запускает воспроизведение; когда видео пошло — сообщает «эфир идёт» (liveFound).
 *  3. Эфир считается закончившимся (ended), если видео дошло до конца, либо на странице появилась надпись
 *     «Трансляция завершена» и при этом картинка перестала двигаться. Условие должно выполниться два раза подряд.
 */
private const val AUTO_JS = """
(function(){
  if (window.__f1auto) return; window.__f1auto = true;
  var B = window.F1Bridge;
  function say(m){ try { if (B && B[m]) B[m](); } catch(e){} }
  var LIVE_RE = /(^|\s)LIVE(\s|${'$'})|Прямой эфир|В эфире/i;
  var END_RE = /Трансляция (завершена|закончилась|окончена)|Эфир (завершён|завершен|окончен)|Прямой эфир (завершён|завершен)|Стрим (завершён|завершен)/i;
  var t0 = Date.now(), reportedLive = false, reportedNo = false;
  var seenPlaying = false, lastTime = -1, stuck = 0, endHits = 0;
  function videoPage(){ return /video-?\d+_\d+/.test(location.href); }
  function liveLink(){
    var links = document.querySelectorAll('a[href*="video"]');
    for (var i = 0; i < links.length; i++) {
      var txt = links[i].innerText || links[i].textContent || '';
      if (LIVE_RE.test(txt)) return links[i];
    }
    return null;
  }
  setInterval(function(){
    var v = document.querySelector('video');
    if (videoPage()) {
      if (v && v.paused && !v.ended) { try { v.play(); } catch(e){} }
      var playing = !!v && !v.paused && v.currentTime > 0;
      if (playing) { seenPlaying = true; if (!reportedLive) { reportedLive = true; say('liveFound'); } }
      var t = v ? v.currentTime : -1;
      if (t === lastTime) { stuck++; } else { stuck = 0; lastTime = t; }
      var text = (document.body && document.body.innerText) || '';
      var finished = !!v && v.ended;
      if (!finished && seenPlaying && stuck >= 3 && END_RE.test(text)) finished = true;
      endHits = finished ? endHits + 1 : 0;
      if (endHits >= 2) { say('ended'); endHits = -1000; }
      return;
    }
    var a = liveLink();
    if (a) { a.click(); return; }
    if (!reportedNo && Date.now() - t0 > 12000) { reportedNo = true; say('noLive'); }
  }, 3000);
})();
"""

/** Мост между скриптом на странице VK и приложением (в странице доступен как window.F1Bridge). */
class VkLiveBridge(
    private val webView: () -> WebView?,
    private val onStatus: (PlayerStatus) -> Unit,
    private val onEnded: () -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())

    /** Принимаем сообщения только от страниц VK. */
    private fun trusted(): Boolean {
        val host = webView()?.url?.let { Uri.parse(it).host }.orEmpty()
        return host.contains("vk")
    }

    @JavascriptInterface
    fun liveFound() {
        main.post { if (trusted()) onStatus(PlayerStatus.LIVE) }
    }

    @JavascriptInterface
    fun noLive() {
        main.post { if (trusted()) onStatus(PlayerStatus.WAITING) }
    }

    @JavascriptInterface
    fun ended() {
        main.post { if (trusted()) onEnded() }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Полноэкранный режим HTML5-видео: показывает видео поверх всего окна в ландшафте. */
private class FullscreenChrome(
    private val activity: Activity?,
    private val onChange: (Boolean) -> Unit,
) : WebChromeClient() {
    private var customView: View? = null
    private var callback: WebChromeClient.CustomViewCallback? = null
    private var previousOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

    override fun onShowCustomView(view: View, cb: WebChromeClient.CustomViewCallback) {
        val act = activity
        if (act == null) {
            cb.onCustomViewHidden()
            return
        }
        if (customView != null) {
            cb.onCustomViewHidden()
            return
        }
        customView = view
        callback = cb
        previousOrientation = act.requestedOrientation
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        view.setBackgroundColor(android.graphics.Color.BLACK)
        (act.window.decorView as ViewGroup).addView(
            view,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.getInsetsController(act.window, act.window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        onChange(true)
    }

    override fun onHideCustomView() {
        val act = activity
        val view = customView ?: return
        customView = null
        if (act != null) {
            (act.window.decorView as ViewGroup).removeView(view)
            act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            WindowCompat.getInsetsController(act.window, act.window.decorView)
                .show(WindowInsetsCompat.Type.systemBars())
            act.requestedOrientation = previousOrientation
        }
        callback?.onCustomViewHidden()
        callback = null
        onChange(false)
    }

    fun exit() = onHideCustomView()
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun VkWebPlayer(
    modifier: Modifier,
    status: PlayerStatus,
    onStatus: (PlayerStatus) -> Unit,
    onEnded: () -> Unit,
) {
    val ctx = LocalContext.current
    var fullscreen by remember { mutableStateOf(false) }
    val chrome = remember(ctx) { FullscreenChrome(ctx.findActivity()) { fullscreen = it } }
    val statusCb by rememberUpdatedState(onStatus)
    val endedCb by rememberUpdatedState(onEnded)
    val holder = remember { arrayOfNulls<WebView>(1) }

    // «Назад» выходит из полноэкранного режима, а не из приложения
    BackHandler(enabled = fullscreen) { chrome.exit() }
    // при уходе с экрана возвращаем обычный режим и ориентацию
    DisposableEffect(chrome) { onDispose { chrome.exit() } }

    // Пока эфира нет — периодически перезагружаем страницу канала: так подхватывается эфир, начавшийся позже
    LaunchedEffect(status) {
        if (status == PlayerStatus.WAITING) {
            while (true) {
                delay(RELOAD_EVERY_MS)
                holder[0]?.loadUrl(VK_CHANNEL_URL)
            }
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { c ->
            WebView(c).apply {
                holder[0] = this
                setBackgroundColor(android.graphics.Color.BLACK)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webChromeClient = chrome
                addJavascriptInterface(
                    VkLiveBridge({ holder[0] }, { statusCb(it) }, { endedCb() }),
                    "F1Bridge",
                )
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val u = request.url
                        val scheme = u.scheme.orEmpty()
                        if (scheme != "http" && scheme != "https") return true // не уходим в приложение VK
                        val host = u.host.orEmpty()
                        val isVk = host.contains("vk") || host.contains("userapi") || host.contains("mail.ru")
                        if (isVk) return false
                        runCatching {
                            view.context.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                        return true
                    }

                    override fun onPageFinished(view: WebView, url: String?) {
                        view.evaluateJavascript(AUTO_JS, null)
                    }
                }
                loadUrl(VK_CHANNEL_URL)
            }
        },
        onRelease = {
            holder[0] = null
            it.destroy()
        },
    )
}

/**
 * Карточка главного экрана: прямой эфир VK Видео + подсказка про раздел LIVE.
 * [onFinished] вызывается, когда эфир закончился или пользователь закрыл карточку крестиком.
 */
@Composable
fun LiveStreamCard(session: Session, onOpenLive: () -> Unit, onFinished: () -> Unit) {
    val race = Schedule.races.firstOrNull { it.round == session.round }
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    val bright = MaterialTheme.colorScheme.onSurface
    var status by remember(session) { mutableStateOf(PlayerStatus.SEARCHING) }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            when (status) {
                PlayerStatus.LIVE -> Text("● В ЭФИРЕ", color = F1Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                PlayerStatus.WAITING -> Text("○ ЖДЁМ ЭФИР", color = gray, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                PlayerStatus.SEARCHING -> Text("○ ПОДКЛЮЧАЕМСЯ", color = gray, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Spacer(Modifier.width(10.dp))
            Text(
                session.type.title + (race?.let { " · ${it.name}" } ?: ""),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Text(
                "✕",
                color = gray,
                fontSize = 16.sp,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable(onClick = onFinished)
                    .padding(horizontal = 8.dp, vertical = 2.dp),
            )
        }
        Spacer(Modifier.height(10.dp))
        VkWebPlayer(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(14.dp)),
            status = status,
            onStatus = { status = it },
            onEnded = onFinished,
        )
        Spacer(Modifier.height(8.dp))
        val hint = buildAnnotatedString {
            append("трансляции с других платформ можно найти в разделе ")
            withStyle(SpanStyle(textDecoration = TextDecoration.Underline, color = bright)) {
                append("live")
            }
        }
        ClickableText(
            text = hint,
            style = TextStyle(fontSize = 11.sp, color = gray),
            onClick = { onOpenLive() },
        )
    }
}
