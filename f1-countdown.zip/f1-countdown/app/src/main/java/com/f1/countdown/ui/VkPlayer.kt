package com.f1.countdown.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.f1.countdown.data.Schedule
import com.f1.countdown.data.Session
import com.f1.countdown.data.SessionType
import java.time.Duration
import java.time.Instant

/** Страница видео сообщества VK с комментаторами (vk.ru/f1commentatorsnews). */
private const val VK_CHANNEL_URL = "https://vk.ru/video/@f1commentatorsnews"

/** Скрипт: ищет на странице видео с пометкой LIVE, открывает его и запускает воспроизведение. */
private const val AUTO_JS = """
(function(){
  if (window.__f1auto) return; window.__f1auto = true;
  function tryPlay(n){
    var v = document.querySelector('video');
    if (v && v.paused) { try { v.play(); } catch(e){} }
    if (n < 12) setTimeout(function(){ tryPlay(n+1); }, 1000);
  }
  var tries = 0;
  var iv = setInterval(function(){
    tries++;
    var links = document.querySelectorAll('a[href*="video"]');
    for (var i = 0; i < links.length; i++) {
      var a = links[i];
      var txt = (a.innerText || a.textContent || '');
      if (/(^|\s)LIVE(\s|${'$'})|Прямой эфир|В эфире/i.test(txt)) {
        clearInterval(iv); a.click(); setTimeout(function(){ tryPlay(0); }, 2500); return;
      }
    }
    if (document.querySelector('video')) { clearInterval(iv); tryPlay(0); return; }
    if (tries > 15) clearInterval(iv);
  }, 1000);
})();
"""

private fun duration(type: SessionType): Duration = when (type) {
    SessionType.RACE -> Duration.ofMinutes(120)
    SessionType.FP1, SessionType.FP2, SessionType.FP3, SessionType.QUALI -> Duration.ofMinutes(60)
    SessionType.SPRINT, SessionType.SPRINT_QUALI -> Duration.ofMinutes(45)
}

/** Идёт ли сессия сейчас (с запасом: за 10 минут до старта и 30 минут после финиша). */
fun isLiveNow(s: Session, now: Instant): Boolean {
    val from = s.start.minus(Duration.ofMinutes(10))
    val to = s.start.plus(duration(s.type)).plus(Duration.ofMinutes(30))
    return !now.isBefore(from) && now.isBefore(to)
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Полноэкранный режим HTML5-видео: показывает видео поверх всего окна в ландшафте. */
private class FullscreenChrome(
    private val activity: Activity?,
    private val onChange: (Boolean) -> Unit,
) : WebChromeClient() {
    private var customView: View? = null
    private var callback: WebChromeClient.CustomViewCallback? = null
    private var previousOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

    override fun onShowCustomView(view: View, cb: WebChromeClient.CustomViewCallback) {
        val act = activity
        if (act == null) {
            cb.onCustomViewHidden()
            return
        }
        if (customView != null) {
            cb.onCustomViewHidden()
            return
        }
        customView = view
        callback = cb
        previousOrientation = act.requestedOrientation
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        view.setBackgroundColor(android.graphics.Color.BLACK)
        (act.window.decorView as ViewGroup).addView(
            view,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.getInsetsController(act.window, act.window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        onChange(true)
    }

    override fun onHideCustomView() {
        val act = activity
        val view = customView ?: return
        customView = null
        if (act != null) {
            (act.window.decorView as ViewGroup).removeView(view)
            act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            WindowCompat.getInsetsController(act.window, act.window.decorView)
                .show(WindowInsetsCompat.Type.systemBars())
            act.requestedOrientation = previousOrientation
        }
        callback?.onCustomViewHidden()
        callback = null
        onChange(false)
    }

    fun exit() = onHideCustomView()
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun VkWebPlayer(modifier: Modifier) {
    val ctx = LocalContext.current
    var fullscreen by remember { mutableStateOf(false) }
    val chrome = remember(ctx) { FullscreenChrome(ctx.findActivity()) { fullscreen = it } }
    // «Назад» выходит из полноэкранного режима, а не из приложения
    BackHandler(enabled = fullscreen) { chrome.exit() }
    // при уходе с экрана возвращаем обычный режим и ориентацию
    DisposableEffect(chrome) { onDispose { chrome.exit() } }

    AndroidView(
        modifier = modifier,
        factory = { c ->
            WebView(c).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webChromeClient = chrome
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val u = request.url
                        val scheme = u.scheme.orEmpty()
                        if (scheme != "http" && scheme != "https") return true // не уходим в приложение VK
                        val host = u.host.orEmpty()
                        val isVk = host.contains("vk") || host.contains("userapi") || host.contains("mail.ru")
                        if (isVk) return false
                        runCatching {
                            view.context.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                        return true
                    }

                    override fun onPageFinished(view: WebView, url: String?) {
                        view.evaluateJavascript(AUTO_JS, null)
                    }
                }
                loadUrl(VK_CHANNEL_URL)
            }
        },
        onRelease = { it.destroy() },
    )
}

/** Карточка главного экрана: прямой эфир VK Видео + подсказка про раздел LIVE. */
@Composable
fun LiveStreamCard(session: Session, onOpenLive: () -> Unit) {
    val race = Schedule.races.firstOrNull { it.round == session.round }
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    val bright = MaterialTheme.colorScheme.onSurface
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("● LIVE", color = F1Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.width(10.dp))
            Text(
                session.type.title + (race?.let { " · ${it.name}" } ?: ""),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
            )
        }
        Spacer(Modifier.height(10.dp))
        VkWebPlayer(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(14.dp)),
        )
        Spacer(Modifier.height(8.dp))
        val hint = buildAnnotatedString {
            append("трансляции с других платформ можно найти в разделе ")
            withStyle(SpanStyle(textDecoration = TextDecoration.Underline, color = bright)) {
                append("live")
            }
        }
        ClickableText(
            text = hint,
            style = TextStyle(fontSize = 11.sp, color = gray),
            onClick = { onOpenLive() },
        )
    }
}
