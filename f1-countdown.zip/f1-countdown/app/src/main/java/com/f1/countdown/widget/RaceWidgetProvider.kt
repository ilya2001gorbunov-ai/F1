package com.f1.countdown.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.widget.RemoteViews
import com.f1.countdown.MainActivity
import com.f1.countdown.R
import com.f1.countdown.data.FlagColors
import com.f1.countdown.data.FlagPalette
import com.f1.countdown.data.Fmt
import com.f1.countdown.data.Schedule
import com.f1.countdown.data.TrackRepo
import com.f1.countdown.data.countdown
import kotlin.concurrent.thread

/** Виды виджетов. */
enum class WidgetKind(
    val title: String,
    val provider: Class<out RaceWidgetProvider>,
    val layout: Int,
    val compact: Boolean,
    val flagColors: Boolean,
) {
    CLASSIC("Классический 4×2", RaceWidgetProvider::class.java, R.layout.widget_race, false, false),
    SMALL("Компактный 2×2", RaceWidgetSmallProvider::class.java, R.layout.widget_race_small, true, false),
    FLAG("Цвета флага 4×2", RaceWidgetFlagProvider::class.java, R.layout.widget_race, false, true),
}

/** Минималистичный виджет: контур трассы на прозрачном фоне, дата/время по МСК и обратный отсчёт. */
open class RaceWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            AppWidgetManager.ACTION_APPWIDGET_UPDATE,
            AppWidgetManager.ACTION_APPWIDGET_OPTIONS_CHANGED,
            AppWidgetManager.ACTION_APPWIDGET_ENABLED,
            AppWidgetManager.ACTION_APPWIDGET_DISABLED,
            ACTION_TICK,
            -> {
                val pending = goAsync()
                thread {
                    try {
                        updateAll(context.applicationContext)
                    } catch (_: Throwable) {
                    } finally {
                        pending.finish()
                    }
                }
            }
        }
    }

    companion object {
        const val ACTION_TICK = "com.f1.countdown.WIDGET_TICK"

        /** Попросить виджеты обновиться (вызывается при запуске приложения). */
        fun refresh(context: Context) {
            context.sendBroadcast(
                Intent(context, RaceWidgetProvider::class.java).setAction(ACTION_TICK),
            )
        }

        /** Предложить пользователю добавить виджет на главный экран. */
        fun requestPin(context: Context, kind: WidgetKind = WidgetKind.CLASSIC): Boolean {
            val mgr = AppWidgetManager.getInstance(context)
            return if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(context, kind.provider), null, null)
            } else {
                false
            }
        }

        private fun tickIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
            context,
            1,
            Intent(context, RaceWidgetProvider::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        private fun cancelTick(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(tickIntent(context))
        }

        private fun scheduleNextTick(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val next = (System.currentTimeMillis() / 60_000 + 1) * 60_000 + 500
            am.setAndAllowWhileIdle(AlarmManager.RTC, next, tickIntent(context))
        }

        /** Обновляет все виджеты всех видов; если ни одного нет — выключает таймер. */
        private fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            var any = false
            for (kind in WidgetKind.entries) {
                val ids = mgr.getAppWidgetIds(ComponentName(context, kind.provider))
                if (ids.isEmpty()) continue
                any = true
                val views = buildViews(context, kind)
                for (id in ids) mgr.updateAppWidget(id, views)
            }
            if (any) scheduleNextTick(context) else cancelTick(context)
        }

        private fun buildViews(context: Context, kind: WidgetKind): RemoteViews {
            val v = RemoteViews(context.packageName, kind.layout)
            val open = PendingIntent.getActivity(
                context,
                0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            v.setOnClickPendingIntent(R.id.w_root, open)

            val race = Schedule.next()
            if (race == null) {
                v.setTextViewText(R.id.w_title, "СЕЗОН ЗАВЕРШЁН")
                v.setTextViewText(R.id.w_date, if (kind.compact) "до встречи!" else "до встречи в новом сезоне")
                v.setTextViewText(R.id.w_d, "--")
                v.setTextViewText(R.id.w_h, "--")
                v.setTextViewText(R.id.w_m, "--")
                v.setViewVisibility(R.id.w_track, View.GONE)
                return v
            }

            val cd = countdown(race)
            val title = if (kind.compact) {
                race.name.removePrefix("Гран-при ").uppercase()
            } else {
                "${race.round} · ${race.name}".uppercase()
            }
            val date = when {
                cd.started -> "Гонка идёт!"
                kind.compact -> "${Fmt.shortDate(race.startMsk)} · ${Fmt.timeMsk(race)}"
                else -> Fmt.full(race)
            }
            v.setTextViewText(R.id.w_title, title)
            v.setTextViewText(R.id.w_date, date)
            v.setTextViewText(R.id.w_d, cd.days.toString())
            v.setTextViewText(R.id.w_h, Fmt.two2(cd.hours))
            v.setTextViewText(R.id.w_m, Fmt.two2(cd.minutes))

            val points = TrackRepo.points(context, race)
            val palette = if (kind.flagColors) FlagColors.of(race.flag) else null
            v.setViewVisibility(R.id.w_track, View.VISIBLE)
            v.setImageViewBitmap(R.id.w_track, drawTrack(points, 360, 9f, palette))
            return v
        }

        /** Контур трассы на полностью прозрачном фоне: белый или в цветах флага страны. */
        private fun drawTrack(p: FloatArray, size: Int, stroke: Float, palette: FlagPalette?): Bitmap {
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val pad = stroke * 2.5f
            val side = size - 2 * pad
            val path = Path()
            for (i in 0 until p.size / 2) {
                val x = pad + p[i * 2] * side
                val y = pad + p[i * 2 + 1] * side
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }

            fun basePaint(width: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = width
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }

            if (palette == null) {
                val paint = basePaint(stroke).apply {
                    color = Color.WHITE
                    setShadowLayer(stroke * 0.8f, 0f, stroke * 0.3f, 0x80000000.toInt())
                }
                canvas.drawPath(path, paint)
            } else {
                // Полупрозрачная светлая подложка, чтобы тёмные полосы флага были видны на любых обоях
                canvas.drawPath(path, basePaint(stroke * 1.8f).apply { color = 0x55FFFFFF })

                val b = RectF()
                path.computeBounds(b, true)
                val n = palette.colors.size
                val colors = IntArray(n * 2)
                val positions = FloatArray(n * 2)
                for (i in 0 until n) {
                    colors[i * 2] = palette.colors[i]
                    colors[i * 2 + 1] = palette.colors[i]
                    positions[i * 2] = i.toFloat() / n
                    positions[i * 2 + 1] = (i + 1).toFloat() / n
                }
                val shader = if (palette.vertical) {
                    LinearGradient(b.left, 0f, b.right.coerceAtLeast(b.left + 1f), 0f, colors, positions, Shader.TileMode.CLAMP)
                } else {
                    LinearGradient(0f, b.top, 0f, b.bottom.coerceAtLeast(b.top + 1f), colors, positions, Shader.TileMode.CLAMP)
                }
                canvas.drawPath(path, basePaint(stroke).apply { this.shader = shader })
            }
            return bmp
        }
    }
}

class RaceWidgetSmallProvider : RaceWidgetProvider()

class RaceWidgetFlagProvider : RaceWidgetProvider()
