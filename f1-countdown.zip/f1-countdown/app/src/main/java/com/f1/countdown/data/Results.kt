package com.f1.countdown.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

data class PastResult(
    val label: String,
    val driver: String,
    val teamId: String,
    val team: String,
)

data class Past(val season: Int, val rows: List<PastResult>)

sealed interface PastState {
    object Loading : PastState
    object NoData : PastState
    object Error : PastState
    class Ok(val past: Past) : PastState
}

/** Строка полной классификации. */
data class ClassRow(
    val pos: String,
    val driver: String,
    val teamId: String,
    val team: String,
    val info: String,
    val points: String,
)

/** Одна вкладка результатов уикенда: «Гонка», «Квалификация», «Спринт». */
data class ClassTab(val label: String, val rows: List<ClassRow>)

sealed interface WeekendState {
    object Loading : WeekendState
    object NotYet : WeekendState
    object Error : WeekendState
    class Ok(val tabs: List<ClassTab>) : WeekendState
}

object DriverNames {
    private val ru = mapOf(
        "Piastri" to "Оскар Пиастри", "Norris" to "Ландо Норрис", "Verstappen" to "Макс Ферстаппен",
        "Russell" to "Джордж Расселл", "Leclerc" to "Шарль Леклер", "Hamilton" to "Льюис Хэмилтон",
        "Sainz" to "Карлос Сайнс", "Antonelli" to "Кими Антонелли", "Alonso" to "Фернандо Алонсо",
        "Albon" to "Александр Элбон", "Hülkenberg" to "Нико Хюлькенберг", "Bearman" to "Оливер Бермен",
        "Hadjar" to "Исак Аджар", "Lawson" to "Лиам Лоусон", "Gasly" to "Пьер Гасли",
        "Ocon" to "Эстебан Окон", "Stroll" to "Лэнс Стролл", "Tsunoda" to "Юки Цунода",
        "Bortoleto" to "Габриэл Бортолето", "Colapinto" to "Франко Колапинто", "Doohan" to "Джек Дуэн",
        "Bottas" to "Валттери Боттас", "Pérez" to "Серхио Перес", "Magnussen" to "Кевин Магнуссен",
        "Ricciardo" to "Даниэль Риккардо", "Zhou" to "Гуань Юй Чжоу", "Sargeant" to "Логан Сарджент",
        "Albon" to "Александр Элбон", "Vettel" to "Себастьян Феттель", "Räikkönen" to "Кими Райкконен",
    )

    fun name(family: String, given: String): String = ru[family] ?: "$given $family"
}

/** Итоги прошлого заезда на трассе: победитель гонки, поул квалификации, победитель спринта. */
object ResultsRepo {
    private val cache = HashMap<String, JSONArray>()

    private fun races(path: String): JSONArray {
        synchronized(cache) { cache[path]?.let { return it } }
        val text = Http.getString("https://api.jolpi.ca/ergast/f1/$path.json?limit=100")
        val arr = JSONObject(text).getJSONObject("MRData").getJSONObject("RaceTable").getJSONArray("Races")
        synchronized(cache) { cache[path] = arr }
        return arr
    }

    private fun findByCircuit(arr: JSONArray, race: Race): JSONObject? {
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            val loc = r.optJSONObject("Circuit")?.optJSONObject("Location") ?: continue
            val lat = loc.optString("lat").toDoubleOrNull() ?: continue
            val lon = loc.optString("long").toDoubleOrNull() ?: continue
            if (Geo.km(race.lat, race.lon, lat, lon) < 12.0) return r
        }
        return null
    }

    private fun findByRound(arr: JSONArray, round: String): JSONObject? {
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            if (r.optString("round") == round) return r
        }
        return null
    }

    private fun row(label: String, race: JSONObject, key: String): PastResult? {
        val res = race.optJSONArray(key)?.optJSONObject(0) ?: return null
        val d = res.getJSONObject("Driver")
        val c = res.getJSONObject("Constructor")
        return PastResult(
            label = label,
            driver = DriverNames.name(d.optString("familyName"), d.optString("givenName")),
            teamId = c.optString("constructorId"),
            team = c.optString("name"),
        )
    }

    suspend fun lastYear(race: Race): PastState = withContext(Dispatchers.IO) {
        try {
            val first = if (Instant.now().isAfter(race.end)) 2026 else 2025
            for (season in first downTo 2022) {
                val wins = races("$season/results/1")
                val hit = findByCircuit(wins, race) ?: continue
                val round = hit.optString("round")
                val rows = ArrayList<PastResult>()
                row("Гонка", hit, "Results")?.let { rows.add(it) }
                try {
                    findByRound(races("$season/qualifying/1"), round)
                        ?.let { row("Квалификация", it, "QualifyingResults") }
                        ?.let { rows.add(it) }
                } catch (_: Exception) {
                }
                try {
                    findByRound(races("$season/sprint/1"), round)
                        ?.let { row("Спринт", it, "SprintResults") }
                        ?.let { rows.add(it) }
                } catch (_: Exception) {
                }
                if (rows.isNotEmpty()) return@withContext PastState.Ok(Past(season, rows))
            }
            PastState.NoData
        } catch (_: Exception) {
            PastState.Error
        }
    }

    private fun classRows(race: JSONObject, key: String, qualifying: Boolean): List<ClassRow> {
        val arr = race.optJSONArray(key) ?: return emptyList()
        val out = ArrayList<ClassRow>()
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            val d = r.getJSONObject("Driver")
            val c = r.getJSONObject("Constructor")
            val info = if (qualifying) {
                listOf("Q3", "Q2", "Q1").map { r.optString(it) }.firstOrNull { it.isNotBlank() } ?: ""
            } else {
                r.optJSONObject("Time")?.optString("time")?.takeIf { it.isNotBlank() } ?: r.optString("status")
            }
            val pts = r.optString("points")
            out.add(
                ClassRow(
                    pos = r.optString("position").ifBlank { (i + 1).toString() },
                    driver = DriverNames.name(d.optString("familyName"), d.optString("givenName")),
                    teamId = c.optString("constructorId"),
                    team = c.optString("name"),
                    info = info,
                    points = if (qualifying || pts == "0" || pts.isBlank()) "" else pts,
                ),
            )
        }
        return out
    }

    /** Полные результаты уже прошедшего этапа текущего сезона: гонка, квалификация, спринт (если был). */
    suspend fun weekend(race: Race): WeekendState = withContext(Dispatchers.IO) {
        try {
            val season = 2026
            val wins = races("$season/results/1")
            val hit = findByCircuit(wins, race) ?: return@withContext WeekendState.NotYet
            val round = hit.optString("round")
            val tabs = ArrayList<ClassTab>()
            fun load(path: String, key: String, label: String, q: Boolean) {
                try {
                    val arr = JSONObject(Http.getString("https://api.jolpi.ca/ergast/f1/$season/$round/$path.json?limit=100"))
                        .getJSONObject("MRData").getJSONObject("RaceTable").getJSONArray("Races")
                    val rows = arr.optJSONObject(0)?.let { classRows(it, key, q) } ?: emptyList()
                    if (rows.isNotEmpty()) tabs.add(ClassTab(label, rows))
                } catch (_: Exception) {
                }
            }
            load("results", "Results", "Гонка", false)
            load("sprint", "SprintResults", "Спринт", false)
            load("qualifying", "QualifyingResults", "Квалификация", true)
            if (tabs.isEmpty()) WeekendState.NotYet else WeekendState.Ok(tabs)
        } catch (_: Exception) {
            WeekendState.Error
        }
    }
}
