package com.f1.countdown.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory

/**
 * Изображения флагов стран. Лежат в assets/flags/<код страны>.png (векторные флаги, растеризованные
 * в высоком разрешении, без прозрачных краёв), поэтому закрашивают трассу целиком и выглядят чётко.
 * Код страны получается из флага-эмодзи (два региональных индикатора). Результат кэшируется.
 */
object FlagArt {
    private val cache = HashMap<String, Bitmap?>()

    @Synchronized
    fun bitmap(ctx: Context, flagEmoji: String): Bitmap? {
        if (cache.containsKey(flagEmoji)) return cache[flagEmoji]
        val bmp = try {
            iso(flagEmoji)?.let { code ->
                ctx.assets.open("flags/$code.png").use { BitmapFactory.decodeStream(it) }
            }
        } catch (_: Throwable) {
            null
        }
        cache[flagEmoji] = bmp
        return bmp
    }

    /** «🇮🇹» → «it». */
    private fun iso(emoji: String): String? {
        val cps = emoji.codePoints().toArray()
        if (cps.size != 2) return null
        val sb = StringBuilder(2)
        for (cp in cps) {
            if (cp !in 0x1F1E6..0x1F1FF) return null
            sb.append('a' + (cp - 0x1F1E6))
        }
        return sb.toString()
    }
}
