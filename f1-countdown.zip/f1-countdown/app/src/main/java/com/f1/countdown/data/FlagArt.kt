package com.f1.countdown.data

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint

/**
 * Изображение флага страны. Рисуется системным шрифтом эмодзи (флаги есть на всех современных Android),
 * затем обрезается по границам самого флага. Результат кэшируется.
 */
object FlagArt {
    private val cache = HashMap<String, Bitmap?>()

    @Synchronized
    fun bitmap(flagEmoji: String): Bitmap? {
        if (cache.containsKey(flagEmoji)) return cache[flagEmoji]
        val bmp = try {
            render(flagEmoji)
        } catch (_: Throwable) {
            null
        }
        cache[flagEmoji] = bmp
        return bmp
    }

    private fun render(emoji: String): Bitmap? {
        val size = 800
        val src = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(src)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 400f }
        val width = paint.measureText(emoji)
        val fm = paint.fontMetrics
        canvas.drawText(emoji, (size - width) / 2f, size / 2f - (fm.ascent + fm.descent) / 2f, paint)

        val px = IntArray(size * size)
        src.getPixels(px, 0, size, 0, 0, size, size)
        var minX = size
        var minY = size
        var maxX = -1
        var maxY = -1
        for (y in 0 until size) {
            for (x in 0 until size) {
                if ((px[y * size + x] ushr 24) > 60) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX - minX < 60 || maxY - minY < 40) {
            src.recycle()
            return null
        }
        val cropped = Bitmap.createBitmap(src, minX, minY, maxX - minX + 1, maxY - minY + 1)
        if (cropped !== src) src.recycle()
        return cropped
    }
}
