package com.f1.countdown.data

/**
 * Упрощённая палитра флага страны: полосы по порядку.
 * vertical = true — полосы вертикальные (цвет меняется слева направо),
 * иначе горизонтальные (цвет меняется сверху вниз).
 */
class FlagPalette(val colors: IntArray, val vertical: Boolean)

object FlagColors {
    private fun p(vertical: Boolean, vararg rgb: Int) =
        FlagPalette(IntArray(rgb.size) { 0xFF000000.toInt() or rgb[it] }, vertical)

    private val byFlag: Map<String, FlagPalette> = mapOf(
        "🇦🇺" to p(false, 0x00008B, 0xFFFFFF, 0xE4002B), // Австралия
        "🇨🇳" to p(false, 0xDE2910, 0xFFDE00), // Китай
        "🇯🇵" to p(false, 0xFFFFFF, 0xBC002D), // Япония
        "🇺🇸" to p(false, 0xB22234, 0xFFFFFF, 0x3C3B6E), // США
        "🇨🇦" to p(true, 0xFF0000, 0xFFFFFF, 0xFF0000), // Канада
        "🇲🇨" to p(false, 0xCE1126, 0xFFFFFF), // Монако
        "🇪🇸" to p(false, 0xAA151B, 0xF1BF00, 0xAA151B), // Испания
        "🇦🇹" to p(false, 0xED2939, 0xFFFFFF, 0xED2939), // Австрия
        "🇬🇧" to p(false, 0x012169, 0xFFFFFF, 0xC8102E), // Великобритания
        "🇧🇪" to p(true, 0x000000, 0xFDDA24, 0xEF3340), // Бельгия
        "🇭🇺" to p(false, 0xCE2939, 0xFFFFFF, 0x477050), // Венгрия
        "🇳🇱" to p(false, 0xAE1C28, 0xFFFFFF, 0x21468B), // Нидерланды
        "🇮🇹" to p(true, 0x009246, 0xFFFFFF, 0xCE2B37), // Италия
        "🇦🇿" to p(false, 0x00B5E2, 0xEF3340, 0x509E2F), // Азербайджан
        "🇸🇬" to p(false, 0xEF3340, 0xFFFFFF), // Сингапур
        "🇲🇽" to p(true, 0x006847, 0xFFFFFF, 0xCE1126), // Мексика
        "🇧🇷" to p(false, 0x009C3B, 0xFFDF00, 0x002776), // Бразилия
        "🇶🇦" to p(true, 0xFFFFFF, 0x8A1538), // Катар
        "🇦🇪" to p(true, 0xFF0000, 0x00732F, 0xFFFFFF, 0x000000), // ОАЭ
    )

    private val fallback = p(false, 0xFFFFFF, 0xE10600)

    fun of(flagEmoji: String): FlagPalette = byFlag[flagEmoji] ?: fallback
}
