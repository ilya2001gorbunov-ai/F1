package com.f1.countdown.ui

import android.widget.FrameLayout
import android.widget.RemoteViews
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.f1.countdown.widget.RaceWidgetProvider
import com.f1.countdown.widget.WidgetKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Пример виджета: показывается настоящий виджет (с актуальной гонкой) на фоне, похожем на обои.
 */
@Composable
fun WidgetPreview(kind: WidgetKind, modifier: Modifier, onClick: () -> Unit = {}) {
    val ctx = LocalContext.current.applicationContext
    val views by produceState<RemoteViews?>(null, kind) {
        value = withContext(Dispatchers.Default) {
            runCatching { RaceWidgetProvider.previewViews(ctx, kind) }.getOrNull()
        }
    }
    Box(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF1B2A41), Color(0xFF3B1F4A), Color(0xFF0E4D4F)),
                ),
            ),
    ) {
        val v = views
        if (v != null) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    FrameLayout(c).also { frame ->
                        runCatching { frame.addView(v.apply(c, frame)) }
                    }
                },
            )
        }
        // Прозрачный слой поверх примера: нажатие в любом месте примера добавляет виджет
        Box(
            Modifier
                .matchParentSize()
                .clickable(onClick = onClick),
        )
    }
}
