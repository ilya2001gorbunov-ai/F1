package com.f1.countdown.data

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.File

/**
 * Реальные фотографии трасс (аэрофото, вид на трассу) из Википедии / Wikimedia Commons.
 * Схемы, логотипы и векторные картинки отбрасываются — берётся только крупное JPEG-фото.
 * Найденный адрес запоминается на устройстве.
 */
object PhotoRepo {
    private const val CACHE_FILE = "photos_v2.json"
    private const val MIN_WIDTH = 1000

    /** Название статьи о трассе в английской Википедии по номеру этапа. */
    private val titles = mapOf(
        1 to "Albert_Park_Circuit",
        2 to "Shanghai_International_Circuit",
        3 to "Suzuka_International_Racing_Course",
        4 to "Miami_International_Autodrome",
        5 to "Circuit_Gilles_Villeneuve",
        6 to "Circuit_de_Monaco",
        7 to "Circuit_de_Barcelona-Catalunya",
        8 to "Red_Bull_Ring",
        9 to "Silverstone_Circuit",
        10 to "Circuit_de_Spa-Francorchamps",
        11 to "Hungaroring",
        12 to "Circuit_Zandvoort",
        13 to "Monza_Circuit",
        14 to "Madring",
        15 to "Baku_City_Circuit",
        16 to "Marina_Bay_Street_Circuit",
        17 to "Circuit_of_the_Americas",
        18 to "Autódromo_Hermanos_Rodríguez",
        19 to "Autódromo_José_Carlos_Pace",
        20 to "Las_Vegas_Strip_Circuit",
        21 to "Lusail_International_Circuit",
        22 to "Yas_Marina_Circuit",
    )

    private val BAD = Regex(
        "map|layout|logo|flag|diagram|icon|locator|poster|portrait|trophy|podium|seat|ticket|statue|" +
            "configuration|\\bplan\\b|\\.svg|\\.png|\\.gif|\\.tif|coat_of_arms|signature",
        RegexOption.IGNORE_CASE,
    )
    private val GOOD = Regex(
        "aerial|view|panoram|overview|grid|start|straight|paddock|grandstand|pit|corner|turn|circuit|race|grand",
        RegexOption.IGNORE_CASE,
    )
    private val STOP = setOf("circuit", "aerial", "international", "street", "racing", "course", "grand", "prix")

    private val mem = HashMap<Int, String>()
    private var loaded = false

    @Synchronized
    fun url(ctx: Context, round: Int): String? {
        load(ctx)
        mem[round]?.let { return it }
        val found: String? = try {
            fetch(round)
        } catch (_: Exception) {
            null // сеть недоступна — попробуем в следующий раз
        }
        if (found == null) return null
        mem[round] = found
        save(ctx)
        return found
    }

    private fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val f = File(ctx.filesDir, CACHE_FILE)
            if (!f.exists()) return
            val o = JSONObject(f.readText())
            for (k in o.keys()) mem[k.toInt()] = o.getString(k)
        } catch (_: Exception) {
        }
    }

    private fun save(ctx: Context) {
        try {
            val o = JSONObject()
            for ((k, v) in mem) o.put(k.toString(), v)
            File(ctx.filesDir, CACHE_FILE).writeText(o.toString())
        } catch (_: Exception) {
        }
    }

    private fun fetch(round: Int): String? {
        val title = titles[round] ?: return null
        // 1) фотографии из статьи о трассе
        val cands = articleImages(title)
        if (cands.isNotEmpty()) {
            val info = imageInfo(cands.take(8))
            for (t in cands) {
                val ii = info[t] ?: continue
                if (isPhoto(ii)) return imageUrl(ii)
            }
        }
        // 2) поиск по Wikimedia Commons
        return searchCommons(title.replace('_', ' '))
    }

    private fun articleImages(title: String): List<String> {
        val text = Http.getString("https://en.wikipedia.org/api/rest_v1/page/media-list/" + Uri.encode(title))
        val items = JSONObject(text).optJSONArray("items") ?: return emptyList()
        val scored = ArrayList<Pair<String, Double>>()
        for (i in 0 until items.length()) {
            val o = items.getJSONObject(i)
            if (o.optString("type") != "image") continue
            val t = o.optString("title")
            val low = t.lowercase()
            if (!(low.endsWith(".jpg") || low.endsWith(".jpeg"))) continue
            if (BAD.containsMatchIn(t)) continue
            val caption = o.optJSONObject("caption")?.optString("text").orEmpty()
            var score = 0.0
            if (GOOD.containsMatchIn(t) || GOOD.containsMatchIn(caption)) score += 2
            if (o.optBoolean("leadImage")) score += 1
            score -= i * 0.01
            scored.add(t.replace('_', ' ') to score)
        }
        return scored.sortedByDescending { it.second }.map { it.first }
    }

    private fun apiUrl(params: String) =
        "https://commons.wikimedia.org/w/api.php?action=query&format=json&prop=imageinfo" +
            "&iiprop=url%7Csize%7Cmime&iiurlwidth=960&" + params

    /** Заголовок файла (с пробелами) → imageinfo. */
    private fun imageInfo(fileTitles: List<String>): Map<String, JSONObject> {
        val text = Http.getString(apiUrl("titles=" + Uri.encode(fileTitles.joinToString("|"))))
        val pages = JSONObject(text).optJSONObject("query")?.optJSONObject("pages") ?: return emptyMap()
        val out = HashMap<String, JSONObject>()
        for (k in pages.keys()) {
            val p = pages.getJSONObject(k)
            val ii = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            out[p.optString("title")] = ii
        }
        return out
    }

    private fun isPhoto(ii: JSONObject) =
        ii.optString("mime") == "image/jpeg" && ii.optInt("width") >= MIN_WIDTH

    private fun imageUrl(ii: JSONObject): String =
        ii.optString("thumburl").ifEmpty { ii.optString("url") }

    private fun searchCommons(name: String): String? {
        val tokens = name.split(' ', '-')
            .filter { it.length >= 5 && it.lowercase() !in STOP }
            .map { it.lowercase() }
        val q = Uri.encode("$name aerial filetype:bitmap")
        val text = Http.getString(
            apiUrl("generator=search&gsrnamespace=6&gsrlimit=12&gsrsearch=$q"),
        )
        val pages = JSONObject(text).optJSONObject("query")?.optJSONObject("pages") ?: return null
        val found = ArrayList<Triple<Int, String, JSONObject>>()
        for (k in pages.keys()) {
            val p = pages.getJSONObject(k)
            val ii = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            found.add(Triple(p.optInt("index"), p.optString("title"), ii))
        }
        for ((_, title, ii) in found.sortedBy { it.first }) {
            if (BAD.containsMatchIn(title) || !isPhoto(ii)) continue
            if (tokens.isNotEmpty() && tokens.none { title.lowercase().contains(it) }) continue
            return imageUrl(ii)
        }
        return null
    }
}
