package com.f1.countdown.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1.countdown.data.Fmt
import com.f1.countdown.data.MSK
import com.f1.countdown.data.Race
import com.f1.countdown.data.Schedule
import com.f1.countdown.data.Session
import com.f1.countdown.data.SessionType
import com.f1.countdown.data.Sessions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth

private class Popup(val round: Int, val day: LocalDate?, val focus: SessionType?)

@Composable
fun CalendarScreen() {
    var mode by rememberSaveable { mutableIntStateOf(0) }
    val now by rememberNow(60_000)
    val ctx = LocalContext.current.applicationContext
    val sessions by produceState(Sessions.builtIn()) {
        withContext(Dispatchers.IO) { Sessions.cached(ctx) }?.let { value = it }
        withContext(Dispatchers.IO) { Sessions.fetch(ctx) }?.let { value = it }
    }
    var popup by remember { mutableStateOf<Popup?>(null) }

    Column(Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = mode,
            containerColor = Color.Transparent,
            contentColor = F1Red,
        ) {
            Tab(selected = mode == 0, onClick = { mode = 0 }, text = { Text("Месяц") })
            Tab(selected = mode == 1, onClick = { mode = 1 }, text = { Text("Список") })
        }
        if (mode == 0) {
            MonthView(now, sessions) { popup = it }
        } else {
            ListView(now, sessions) { popup = it }
        }
    }

    popup?.let { p ->
        val race = Schedule.races.first { it.round == p.round }
        EventDialog(
            race = race,
            weekend = sessions.filter { it.round == p.round },
            focus = p.focus,
            day = p.day,
            onDismiss = { popup = null },
        )
    }
}

@Composable
private fun ListView(now: Instant, sessions: List<Session>, onOpen: (Popup) -> Unit) {
    val nextIdx = Schedule.races.indexOfFirst { now.isBefore(it.end) }.coerceAtLeast(0)
    val state = rememberLazyListState(initialFirstVisibleItemIndex = nextIdx)
    val byRound = remember(sessions) { sessions.groupBy { it.round } }
    LazyColumn(
        state = state,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(Schedule.races, key = { it.round }) { race ->
            WeekendCard(race, byRound[race.round].orEmpty(), now, onOpen)
        }
    }
}

@Composable
private fun WeekendCard(race: Race, weekend: List<Session>, now: Instant, onOpen: (Popup) -> Unit) {
    val isPast = now.isAfter(race.end)
    val isNext = Schedule.next(now)?.round == race.round
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    var m = Modifier
        .fillMaxWidth()
        .alpha(if (isPast) 0.55f else 1f)
        .clip(RoundedCornerShape(16.dp))
        .background(MaterialTheme.colorScheme.surfaceVariant)
    if (isNext) m = m.border(1.dp, F1Red, RoundedCornerShape(16.dp))

    Column(m.padding(14.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { onOpen(Popup(race.round, null, null)) },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "ЭТАП ${race.round}" + if (isNext) " · БЛИЖАЙШИЙ" else "",
                    fontSize = 11.sp,
                    letterSpacing = 1.sp,
                    color = if (isNext) F1Red else gray,
                )
                Text("${race.flag} ${race.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${race.circuit} · ${race.city}", style = MaterialTheme.typography.bodySmall, color = gray)
            }
            TrackImage(race, Modifier.size(64.dp))
        }
        Spacer(Modifier.height(8.dp))
        for (s in weekend) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onOpen(Popup(race.round, s.msk.toLocalDate(), s.type)) }
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(s.type.color()),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    s.type.title,
                    modifier = Modifier.weight(1f),
                    fontWeight = if (s.type == SessionType.RACE) FontWeight.Bold else FontWeight.Normal,
                )
                Text("${Fmt.shortDate(s.msk)} · ${Fmt.hm(s.msk)}", fontSize = 13.sp, color = gray)
            }
        }
    }
}

@Composable
private fun MonthView(now: Instant, sessions: List<Session>, onOpen: (Popup) -> Unit) {
    val first = Schedule.races.first().startMsk
    val last = Schedule.races.last().startMsk
    val minIdx = first.year * 12 + first.monthValue - 1
    val maxIdx = last.year * 12 + last.monthValue - 1
    val today = LocalDate.now(MSK)
    var idx by rememberSaveable {
        mutableIntStateOf((today.year * 12 + today.monthValue - 1).coerceIn(minIdx, maxIdx))
    }
    val year = idx / 12
    val month = idx % 12 + 1
    val byDay = remember(sessions) { sessions.groupBy { it.msk.toLocalDate() } }
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    val ym = YearMonth.of(year, month)

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { if (idx > minIdx) idx-- }, enabled = idx > minIdx) {
                Text("‹", fontSize = 24.sp)
            }
            Text(
                "${Fmt.monthName(month)} $year",
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            TextButton(onClick = { if (idx < maxIdx) idx++ }, enabled = idx < maxIdx) {
                Text("›", fontSize = 24.sp)
            }
        }
        Row(Modifier.fillMaxWidth()) {
            for (d in Fmt.weekdays) {
                Text(d, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp, color = gray)
            }
        }
        Spacer(Modifier.height(4.dp))

        val offset = ym.atDay(1).dayOfWeek.value - 1
        val len = ym.lengthOfMonth()
        val rows = (offset + len + 6) / 7
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0 until 7) {
                    val day = r * 7 + c - offset + 1
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .padding(2.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (day in 1..len) {
                            val date = ym.atDay(day)
                            val evs = byDay[date].orEmpty()
                            val hasRace = evs.any { it.type == SessionType.RACE }
                            var m = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(if (hasRace) F1Red else Color.Transparent)
                            if (date == today && !hasRace) m = m.border(1.dp, gray, CircleShape)
                            if (evs.isNotEmpty()) m = m.clickable { onOpen(Popup(evs.first().round, date, null)) }
                            Column(
                                m,
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                            ) {
                                Text(
                                    day.toString(),
                                    fontWeight = if (evs.isNotEmpty()) FontWeight.Bold else FontWeight.Normal,
                                    color = if (hasRace) Color.White else MaterialTheme.colorScheme.onSurface,
                                )
                                if (evs.isNotEmpty() && !hasRace) {
                                    Spacer(Modifier.height(2.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        for (t in evs.map { it.type }.distinct().take(3)) {
                                            Box(
                                                Modifier
                                                    .size(5.dp)
                                                    .clip(CircleShape)
                                                    .background(t.color()),
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Legend("Гонка", SessionType.RACE.color())
            Legend("Квалиф.", SessionType.QUALI.color())
            Legend("Спринт", SessionType.SPRINT.color())
            Legend("Практика", SessionType.FP1.color())
        }
        Spacer(Modifier.height(4.dp))
        Text("Время — московское. Нажмите на дату или событие.", fontSize = 12.sp, color = gray)
        Spacer(Modifier.height(8.dp))

        // События месяца в хронологическом порядке (от старых к новым).
        val monthSessions = sessions
            .filter { it.msk.year == year && it.msk.monthValue == month }
            .sortedBy { it.start }
        // Ближайшее предстоящее событие; -1, если в месяце все события уже прошли.
        val nextIdx = monthSessions.indexOfFirst { !it.start.isBefore(now) }
        // Есть предстоящее — встаём на него, иначе список начинается с самого старого события.
        val initialIndex = if (nextIdx >= 0) nextIdx else 0
        val listState = rememberLazyListState(initialFirstVisibleItemIndex = initialIndex)
        // При смене месяца (и после загрузки расписания) позиционируем список заново.
        LaunchedEffect(year, month, sessions) {
            if (monthSessions.isNotEmpty()) listState.scrollToItem(initialIndex)
        }
        if (monthSessions.isEmpty()) {
            Text("В этом месяце событий нет", color = gray, modifier = Modifier.padding(top = 8.dp))
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 8.dp),
            ) {
                itemsIndexed(monthSessions, key = { _, ev -> "${ev.round}-${ev.type}-${ev.start}" }) { i, s ->
                    val isNext = i == nextIdx
                    Column {
                        Text(
                            Fmt.shortDate(s.msk),
                            style = MaterialTheme.typography.labelLarge,
                            color = if (isNext) F1Red else gray,
                            modifier = Modifier.padding(vertical = 4.dp),
                        )
                        val race = Schedule.races.first { it.round == s.round }
                        EventRow(s, race, now, isNext = isNext) {
                            onOpen(Popup(s.round, s.msk.toLocalDate(), s.type))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Legend(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color),
        )
        Spacer(Modifier.width(5.dp))
        Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EventRow(s: Session, race: Race, now: Instant, isNext: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .alpha(if (s.start.isBefore(now)) 0.55f else 1f)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .then(if (isNext) Modifier.border(1.dp, F1Red, RoundedCornerShape(12.dp)) else Modifier)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .width(4.dp)
                .height(36.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(s.type.color()),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.type.title, fontWeight = FontWeight.Bold)
            Text(
                "${race.flag} ${race.name}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(Fmt.hm(s.msk), style = MaterialTheme.typography.titleMedium)
    }
}
