package com.f1.countdown.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1.countdown.data.Fmt
import com.f1.countdown.data.MSK
import com.f1.countdown.data.Schedule
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun CalendarScreen() {
    var mode by rememberSaveable { mutableIntStateOf(0) }
    val now by rememberNow(60_000)
    Column(Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = mode,
            containerColor = Color.Transparent,
            contentColor = F1Red,
        ) {
            Tab(selected = mode == 0, onClick = { mode = 0 }, text = { Text("Месяц") })
            Tab(selected = mode == 1, onClick = { mode = 1 }, text = { Text("Список гонок") })
        }
        if (mode == 0) MonthView(now) else ListView(now)
    }
}

@Composable
private fun ListView(now: Instant) {
    val nextIdx = Schedule.races.indexOfFirst { now.isBefore(it.end) }.coerceAtLeast(0)
    val state = rememberLazyListState(initialFirstVisibleItemIndex = nextIdx)
    LazyColumn(
        state = state,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(Schedule.races, key = { it.round }) { RaceRow(it, now) }
    }
}

@Composable
private fun MonthView(now: Instant) {
    val first = Schedule.races.first().startMsk
    val last = Schedule.races.last().startMsk
    val minIdx = first.year * 12 + first.monthValue - 1
    val maxIdx = last.year * 12 + last.monthValue - 1
    val today = LocalDate.now(MSK)
    var idx by rememberSaveable {
        mutableIntStateOf((today.year * 12 + today.monthValue - 1).coerceIn(minIdx, maxIdx))
    }
    val year = idx / 12
    val month = idx % 12 + 1
    val raceByDay = remember { Schedule.races.associateBy { it.startMsk.toLocalDate() } }
    val monthRaces = Schedule.races.filter { it.startMsk.year == year && it.startMsk.monthValue == month }
    val gray = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { if (idx > minIdx) idx-- }, enabled = idx > minIdx) {
                Text("‹", fontSize = 24.sp)
            }
            Text(
                "${Fmt.monthName(month)} $year",
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            TextButton(onClick = { if (idx < maxIdx) idx++ }, enabled = idx < maxIdx) {
                Text("›", fontSize = 24.sp)
            }
        }
        Row(Modifier.fillMaxWidth()) {
            for (d in Fmt.weekdays) {
                Text(
                    d,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    fontSize = 12.sp,
                    color = gray,
                )
            }
        }
        Spacer(Modifier.height(4.dp))

        val ym = YearMonth.of(year, month)
        val offset = ym.atDay(1).dayOfWeek.value - 1
        val len = ym.lengthOfMonth()
        val rows = (offset + len + 6) / 7
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth()) {
                for (c in 0 until 7) {
                    val day = r * 7 + c - offset + 1
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .padding(3.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (day in 1..len) {
                            val date = ym.atDay(day)
                            val race = raceByDay[date]
                            val isToday = date == today
                            var m = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(if (race != null) F1Red else Color.Transparent)
                            if (isToday && race == null) m = m.border(1.dp, gray, CircleShape)
                            Box(m, contentAlignment = Alignment.Center) {
                                Text(
                                    day.toString(),
                                    fontWeight = if (race != null) FontWeight.Bold else FontWeight.Normal,
                                    color = if (race != null) Color.White else MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            "Красным отмечены дни гонок (по московскому времени)",
            fontSize = 12.sp,
            color = gray,
        )
        Spacer(Modifier.height(16.dp))
        if (monthRaces.isEmpty()) {
            Text("В этом месяце гонок нет", color = gray)
        } else {
            for (race in monthRaces) {
                RaceRow(race, now)
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}
