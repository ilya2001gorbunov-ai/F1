package com.f1.countdown.data

import android.text.Html
import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

data class NewsItem(
    val title: String,
    val summary: String,
    val link: String,
    val image: String?,
    val date: Long?,
    val source: String,
)

object NewsRepo {
    private val FEEDS = listOf(
        "https://f1news.ru/export/news.xml" to "F1News.ru",
        "https://www.motorsport.com/rss/f1/news/" to "Motorsport.com",
    )

    /** Грузит первую рабочую ленту; пустой список — если ни одна не ответила. */
    suspend fun load(): List<NewsItem> = withContext(Dispatchers.IO) {
        for ((url, source) in FEEDS) {
            try {
                val items = parse(download(url), source)
                if (items.isNotEmpty()) return@withContext items
            } catch (_: Exception) {
            }
        }
        emptyList()
    }

    private fun download(url: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) F1Calendar/1.0")
        c.setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
        try {
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    private fun parse(bytes: ByteArray, source: String): List<NewsItem> {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(bytes), null)
        val items = ArrayList<NewsItem>()
        var inItem = false
        var title = ""
        var desc = ""
        var link = ""
        var img: String? = null
        var date: Long? = null
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "item" -> {
                        inItem = true
                        title = ""; desc = ""; link = ""; img = null; date = null
                    }
                    "title" -> if (inItem) title = p.nextText()
                    "description" -> if (inItem) desc = p.nextText()
                    "link" -> if (inItem) link = p.nextText()
                    "pubDate" -> if (inItem) date = parseDate(p.nextText())
                    "enclosure" -> if (inItem) img = p.getAttributeValue(null, "url")
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "item") {
                inItem = false
                val t = clean(title)
                if (t.isNotEmpty() && link.isNotBlank()) {
                    items.add(
                        NewsItem(
                            title = t,
                            summary = clean(desc).take(220),
                            link = link.trim().replace("http://", "https://"),
                            image = img?.takeIf { it.isNotBlank() }?.replace("http://", "https://"),
                            date = date,
                            source = source,
                        ),
                    )
                }
            }
            ev = p.next()
        }
        return items.take(40)
    }

    private fun clean(s: String): String =
        Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replace('￼', ' ').trim()

    private fun parseDate(s: String): Long? = try {
        ZonedDateTime.parse(s.trim(), DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli()
    } catch (_: Exception) {
        null
    }
}
