package com.f1.countdown.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.f1.countdown.data.PastState
import com.f1.countdown.data.PhotoRepo
import com.f1.countdown.data.Race
import com.f1.countdown.data.ResultsRepo
import com.f1.countdown.data.Session
import com.f1.countdown.data.SessionType
import com.f1.countdown.data.USER_AGENT
import com.f1.countdown.data.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

fun SessionType.color(): Color = when (this) {
    SessionType.FP1, SessionType.FP2, SessionType.FP3 -> Color(0xFF4FC3F7)
    SessionType.SPRINT_QUALI -> Color(0xFFEC4899)
    SessionType.QUALI -> Color(0xFFA855F7)
    SessionType.SPRINT -> Color(0xFFFF9800)
    SessionType.RACE -> F1Red
}

/** Всплывающее окно: фото трассы, расписание уикенда и итоги прошлого заезда на этой трассе. */
@Composable
fun EventDialog(
    race: Race,
    weekend: List<Session>,
    focus: SessionType?,
    day: LocalDate?,
    onDismiss: () -> Unit,
) {
    val maxH = (LocalConfiguration.current.screenHeightDp * 0.88f).dp
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    val sorted = weekend.sortedBy { it.start }
    val focused = sorted.firstOrNull { it.type == focus }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = maxH),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        ) {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                TrackPhoto(race)
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "ЭТАП ${race.round}",
                        fontSize = 11.sp,
                        letterSpacing = 1.sp,
                        color = F1Red,
                        fontWeight = FontWeight.Bold,
                    )
                    Text("${race.flag} ${race.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("${race.circuit} · ${race.city}", style = MaterialTheme.typography.bodySmall, color = gray)

                    if (focused != null) {
                        Spacer(Modifier.height(10.dp))
                        Text(focused.type.title, style = MaterialTheme.typography.titleMedium, color = focused.type.color(), fontWeight = FontWeight.Bold)
                        Text(Fmt.full(focused.msk), style = MaterialTheme.typography.bodyMedium)
                    }

                    Spacer(Modifier.height(16.dp))
                    Text("Расписание уикенда (МСК)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    for (s in sorted) {
                        val hl = s.type == focus || (day != null && s.msk.toLocalDate() == day)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (hl) s.type.color().copy(alpha = 0.18f) else Color.Transparent)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(s.type.color()),
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                s.type.title,
                                modifier = Modifier.weight(1f),
                                fontWeight = if (hl) FontWeight.Bold else FontWeight.Normal,
                            )
                            Text("${Fmt.shortDate(s.msk)} · ${Fmt.hm(s.msk)}", color = gray, fontSize = 13.sp)
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    PastResults(race)

                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) { Text("Закрыть") }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrackPhoto(race: Race) {
    val ctx = LocalContext.current
    val url by produceState<String?>(null, race.round) {
        value = withContext(Dispatchers.IO) { PhotoRepo.url(race.round) }
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(190.dp)
            .background(Color(0xFF101014)),
    ) {
        val u = url
        if (u != null) {
            AsyncImage(
                model = ImageRequest.Builder(ctx)
                    .data(u)
                    .addHeader("User-Agent", USER_AGENT)
                    .crossfade(true)
                    .build(),
                contentDescription = race.circuit,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp)
                .size(84.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x99000000)),
        ) {
            TrackImage(race, Modifier.fillMaxSize().padding(4.dp), stroke = 2.dp)
        }
    }
}

@Composable
private fun PastResults(race: Race) {
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    val state by produceState<PastState>(PastState.Loading, race.round) {
        value = ResultsRepo.lastYear(race)
    }
    when (val s = state) {
        PastState.Loading -> Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = F1Red)
            Spacer(Modifier.width(10.dp))
            Text("Загружаю итоги…", color = gray)
        }
        PastState.NoData -> Text(
            "Раньше Гран-при на этой трассе не проводились — данных для сравнения нет.",
            color = gray,
        )
        PastState.Error -> Text("Не удалось загрузить итоги прошлого заезда. Проверьте интернет.", color = gray)
        is PastState.Ok -> {
            val title = if (s.past.season >= 2026) {
                "Итоги этого этапа (${s.past.season})"
            } else {
                "Прошлый заезд на этой трассе (${s.past.season})"
            }
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            for (r in s.past.rows) {
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(r.label, modifier = Modifier.width(104.dp), fontSize = 12.sp, color = gray)
                    TeamBadge(r.teamId, r.team, 34.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.driver, fontWeight = FontWeight.Bold)
                        Text(r.team, fontSize = 12.sp, color = gray)
                    }
                }
            }
        }
    }
}
