package com.f1.countdown.data

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.abs

enum class SessionType(val title: String) {
    FP1("Свободная практика 1"),
    FP2("Свободная практика 2"),
    FP3("Свободная практика 3"),
    SPRINT_QUALI("Спринт-квалификация"),
    SPRINT("Спринт"),
    QUALI("Квалификация"),
    RACE("Гонка"),
}

data class Session(val round: Int, val type: SessionType, val start: Instant) {
    val msk: ZonedDateTime get() = start.atZone(MSK)
}

/**
 * Расписание всех сессий уикенда. Гонки зашиты в приложение (работают офлайн),
 * остальные сессии подгружаются из открытого API (Jolpica/Ergast) и кэшируются.
 */
object Sessions {
    private const val CACHE = "sessions_2026.json"
    private const val URL = "https://api.jolpi.ca/ergast/f1/2026.json?limit=100"

    fun builtIn(): List<Session> =
        Schedule.races.map { Session(it.round, SessionType.RACE, it.start.toInstant()) }

    fun cached(ctx: Context): List<Session>? = try {
        val f = File(ctx.filesDir, CACHE)
        if (f.exists()) parse(f.readText()) else null
    } catch (_: Exception) {
        null
    }

    fun fetch(ctx: Context): List<Session>? = try {
        val text = Http.getString(URL)
        val result = parse(text)
        if (result.size > Schedule.races.size) {
            File(ctx.filesDir, CACHE).writeText(text)
        }
        result
    } catch (_: Exception) {
        null
    }

    private fun parse(text: String): List<Session> {
        val races = JSONObject(text).getJSONObject("MRData").getJSONObject("RaceTable").getJSONArray("Races")
        val out = ArrayList<Session>(builtIn())
        val keys = listOf(
            "FirstPractice" to SessionType.FP1,
            "SecondPractice" to SessionType.FP2,
            "ThirdPractice" to SessionType.FP3,
            "SprintQualifying" to SessionType.SPRINT_QUALI,
            "SprintShootout" to SessionType.SPRINT_QUALI,
            "Sprint" to SessionType.SPRINT,
            "Qualifying" to SessionType.QUALI,
        )
        for (i in 0 until races.length()) {
            val r = races.getJSONObject(i)
            val round = r.optString("round").toIntOrNull() ?: continue
            val mine = Schedule.races.firstOrNull { it.round == round } ?: continue
            val apiDate = runCatching { LocalDate.parse(r.getString("date")) }.getOrNull() ?: continue
            if (abs(ChronoUnit.DAYS.between(apiDate, LocalDate.parse(mine.date))) > 3) continue
            for ((key, type) in keys) {
                val o = r.optJSONObject(key) ?: continue
                val time = o.optString("time")
                if (time.isEmpty()) continue
                val inst = runCatching { Instant.parse(o.getString("date") + "T" + time) }.getOrNull() ?: continue
                out.add(Session(round, type, inst))
            }
        }
        return out.sortedBy { it.start }
    }
}
