package com.f1.countdown.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val F1Red = Color(0xFFE10600)

private val Scheme = darkColorScheme(
    primary = F1Red,
    onPrimary = Color.White,
    background = Color(0xFF0B0B0D),
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF0B0B0D),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF17171B),
    onSurfaceVariant = Color(0xFF9A9AA3),
)

@Composable
fun F1Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
