package com.f1.countdown.data

import android.net.Uri
import org.json.JSONObject

/** Фото трассы: главное изображение статьи о трассе в Википедии. */
object PhotoRepo {
    private val titles = mapOf(
        1 to "Albert_Park_Circuit",
        2 to "Shanghai_International_Circuit",
        3 to "Suzuka_International_Racing_Course",
        4 to "Bahrain_International_Circuit",
        5 to "Jeddah_Corniche_Circuit",
        6 to "Miami_International_Autodrome",
        7 to "Circuit_Gilles_Villeneuve",
        8 to "Circuit_de_Monaco",
        9 to "Circuit_de_Barcelona-Catalunya",
        10 to "Red_Bull_Ring",
        11 to "Silverstone_Circuit",
        12 to "Circuit_de_Spa-Francorchamps",
        13 to "Hungaroring",
        14 to "Circuit_Zandvoort",
        15 to "Monza_Circuit",
        16 to "Madring",
        17 to "Baku_City_Circuit",
        18 to "Marina_Bay_Street_Circuit",
        19 to "Circuit_of_the_Americas",
        20 to "Autódromo_Hermanos_Rodríguez",
        21 to "Autódromo_José_Carlos_Pace",
        22 to "Las_Vegas_Strip_Circuit",
        23 to "Lusail_International_Circuit",
        24 to "Yas_Marina_Circuit",
    )

    private val cache = HashMap<Int, String?>()

    fun url(round: Int): String? {
        synchronized(cache) { if (cache.containsKey(round)) return cache[round] }
        val result = try {
            fetch(round)
        } catch (_: Exception) {
            return null // не кэшируем ошибку сети
        }
        synchronized(cache) { cache[round] = result }
        return result
    }

    private fun fetch(round: Int): String? {
        val title = titles[round] ?: return null
        val text = Http.getString("https://en.wikipedia.org/api/rest_v1/page/summary/" + Uri.encode(title))
        val o = JSONObject(text)
        val thumb = o.optJSONObject("thumbnail")?.optString("source")?.takeIf { it.isNotEmpty() } ?: return null
        val orig = o.optJSONObject("originalimage")
        val w = orig?.optInt("width") ?: 0
        val origUrl = orig?.optString("source").orEmpty()
        return if (origUrl.isNotEmpty() && w in 1..959 && !thumb.contains(".svg")) {
            origUrl
        } else {
            thumb.replace(Regex("/\\d+px-"), "/960px-")
        }
    }
}
