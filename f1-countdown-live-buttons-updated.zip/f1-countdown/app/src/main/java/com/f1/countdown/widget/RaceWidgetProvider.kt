package com.f1.countdown.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import android.widget.RemoteViews
import com.f1.countdown.MainActivity
import com.f1.countdown.R
import com.f1.countdown.data.Fmt
import com.f1.countdown.data.Schedule
import com.f1.countdown.data.TrackRepo
import com.f1.countdown.data.countdown
import kotlin.concurrent.thread

/** Минималистичный виджет: контур трассы на прозрачном фоне, дата/время по МСК и обратный отсчёт. */
class RaceWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        when (action) {
            AppWidgetManager.ACTION_APPWIDGET_DISABLED -> cancelTick(context)
            AppWidgetManager.ACTION_APPWIDGET_UPDATE,
            AppWidgetManager.ACTION_APPWIDGET_OPTIONS_CHANGED,
            AppWidgetManager.ACTION_APPWIDGET_ENABLED,
            ACTION_TICK -> {
                val pending = goAsync()
                thread {
                    try {
                        updateAll(context.applicationContext)
                    } catch (_: Throwable) {
                    } finally {
                        pending.finish()
                    }
                }
            }
        }
    }

    companion object {
        const val ACTION_TICK = "com.f1.countdown.WIDGET_TICK"

        /** Попросить виджеты обновиться (вызывается при запуске приложения). */
        fun refresh(context: Context) {
            context.sendBroadcast(
                Intent(context, RaceWidgetProvider::class.java).setAction(ACTION_TICK),
            )
        }

        /** Предложить пользователю добавить виджет на главный экран. */
        fun requestPin(context: Context): Boolean {
            val mgr = AppWidgetManager.getInstance(context)
            return if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(ComponentName(context, RaceWidgetProvider::class.java), null, null)
            } else {
                false
            }
        }

        private fun tickIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
            context,
            1,
            Intent(context, RaceWidgetProvider::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        private fun cancelTick(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(tickIntent(context))
        }

        private fun scheduleNextTick(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val next = (System.currentTimeMillis() / 60_000 + 1) * 60_000 + 500
            am.setAndAllowWhileIdle(AlarmManager.RTC, next, tickIntent(context))
        }

        private fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, RaceWidgetProvider::class.java))
            if (ids.isEmpty()) {
                cancelTick(context)
                return
            }
            val views = buildViews(context)
            for (id in ids) mgr.updateAppWidget(id, views)
            scheduleNextTick(context)
        }

        private fun buildViews(context: Context): RemoteViews {
            val v = RemoteViews(context.packageName, R.layout.widget_race)
            val open = PendingIntent.getActivity(
                context,
                0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            v.setOnClickPendingIntent(R.id.w_root, open)

            val race = Schedule.next()
            if (race == null) {
                v.setTextViewText(R.id.w_title, "СЕЗОН ЗАВЕРШЁН")
                v.setTextViewText(R.id.w_date, "до встречи в новом сезоне")
                v.setTextViewText(R.id.w_d, "--")
                v.setTextViewText(R.id.w_h, "--")
                v.setTextViewText(R.id.w_m, "--")
                v.setViewVisibility(R.id.w_track, View.GONE)
                return v
            }

            val cd = countdown(race)
            v.setTextViewText(R.id.w_title, "${race.round} · ${race.name}".uppercase())
            v.setTextViewText(R.id.w_date, if (cd.started) "Гонка идёт!" else Fmt.full(race))
            v.setTextViewText(R.id.w_d, cd.days.toString())
            v.setTextViewText(R.id.w_h, Fmt.two2(cd.hours))
            v.setTextViewText(R.id.w_m, Fmt.two2(cd.minutes))

            val points = TrackRepo.points(context, race)
            v.setViewVisibility(R.id.w_track, View.VISIBLE)
            v.setImageViewBitmap(R.id.w_track, drawTrack(points, 360, Color.WHITE, 9f))
            return v
        }

        /** Контур трассы белой линией на полностью прозрачном фоне. */
        private fun drawTrack(p: FloatArray, size: Int, color: Int, stroke: Float): Bitmap {
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = stroke
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                this.color = color
                setShadowLayer(stroke * 0.8f, 0f, stroke * 0.3f, 0x80000000.toInt())
            }
            val pad = stroke * 2.5f
            val side = size - 2 * pad
            val path = Path()
            for (i in 0 until p.size / 2) {
                val x = pad + p[i * 2] * side
                val y = pad + p[i * 2 + 1] * side
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
            return bmp
        }
    }
}
