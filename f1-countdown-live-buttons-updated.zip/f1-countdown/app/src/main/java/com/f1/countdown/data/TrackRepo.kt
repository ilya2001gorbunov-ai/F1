package com.f1.countdown.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Контуры трасс. Берутся из assets/f1-circuits.geojson (скачивается при сборке в GitHub Actions),
 * для каждой гонки ищется ближайшая трасса, точки нормализуются в квадрат [0..1] и кэшируются.
 * Если контура нет (например, новая трасса в Мадриде) — рисуется стилизованная петля.
 */
object TrackRepo {
    private const val CACHE_FILE = "tracks_v1.json"
    private const val ASSET = "f1-circuits.geojson"
    private const val MATCH_RADIUS_KM = 12.0

    @Volatile
    private var mem: Map<Int, FloatArray>? = null

    /** Точки трассы в виде x0,y0,x1,y1,... в диапазоне 0..1 (ось Y направлена вниз). */
    fun points(ctx: Context, race: Race): FloatArray {
        val all = mem ?: synchronized(this) {
            mem ?: load(ctx.applicationContext).also { mem = it }
        }
        return all[race.round] ?: fallback(race.round)
    }

    private fun load(ctx: Context): Map<Int, FloatArray> {
        val cache = File(ctx.filesDir, CACHE_FILE)
        if (cache.exists()) {
            try {
                return readCache(cache.readText())
            } catch (_: Exception) {
            }
        }
        val built = try {
            build(ctx)
        } catch (_: Throwable) {
            emptyMap()
        }
        if (built.isNotEmpty()) {
            try {
                cache.writeText(writeCache(built))
            } catch (_: Exception) {
            }
        }
        return built
    }

    private class Cand(val year: Int, val lat: Double, val lon: Double, val pts: List<DoubleArray>)

    private fun build(ctx: Context): Map<Int, FloatArray> {
        val text = ctx.assets.open(ASSET).bufferedReader().use { it.readText() }
        val feats = JSONObject(text).getJSONArray("features")
        val cands = ArrayList<Cand>()
        for (i in 0 until feats.length()) {
            val f = feats.getJSONObject(i)
            val coords = f.optJSONObject("geometry")?.optJSONArray("coordinates") ?: continue
            val pts = ArrayList<DoubleArray>()
            collect(coords, pts)
            if (pts.size < 10) continue
            val id = f.optJSONObject("properties")?.optString("id") ?: ""
            val year = id.substringAfterLast('-').toIntOrNull() ?: 0
            cands.add(Cand(year, pts.map { it[1] }.average(), pts.map { it[0] }.average(), pts))
        }
        val result = HashMap<Int, FloatArray>()
        for (race in Schedule.races) {
            val best = cands
                .filter { haversine(race.lat, race.lon, it.lat, it.lon) < MATCH_RADIUS_KM }
                .maxWithOrNull(compareBy<Cand>({ it.year }, { -haversine(race.lat, race.lon, it.lat, it.lon) }))
                ?: continue
            result[race.round] = normalize(best.pts)
        }
        return result
    }

    private fun collect(a: JSONArray, out: MutableList<DoubleArray>) {
        if (a.length() == 0) return
        if (a.opt(0) is Number) {
            out.add(doubleArrayOf(a.getDouble(0), a.getDouble(1)))
        } else {
            for (i in 0 until a.length()) collect(a.getJSONArray(i), out)
        }
    }

    private fun normalize(pts: List<DoubleArray>): FloatArray {
        val latC = pts.map { it[1] }.average()
        val k = cos(Math.toRadians(latC))
        val xs = pts.map { it[0] * k }
        val ys = pts.map { -it[1] }
        val minX = xs.min()
        val maxX = xs.max()
        val minY = ys.min()
        val maxY = ys.max()
        val scale = max(maxX - minX, maxY - minY).coerceAtLeast(1e-9)
        val cx = (minX + maxX) / 2
        val cy = (minY + maxY) / 2
        val step = max(1, pts.size / 400)
        val out = ArrayList<Float>()
        var i = 0
        while (i < pts.size) {
            out.add((0.5 + (xs[i] - cx) / scale).toFloat())
            out.add((0.5 + (ys[i] - cy) / scale).toFloat())
            i += step
        }
        val last = pts.size - 1
        if ((last % step) != 0) {
            out.add((0.5 + (xs[last] - cx) / scale).toFloat())
            out.add((0.5 + (ys[last] - cy) / scale).toFloat())
        }
        return out.toFloatArray()
    }

    private fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * asin(min(1.0, sqrt(a)))
    }

    private fun fallback(round: Int): FloatArray {
        val n = 120
        val out = FloatArray((n + 1) * 2)
        val ph = round * 0.9
        for (i in 0..n) {
            val t = 2 * PI * (i % n) / n
            val r = 0.30 + 0.07 * sin(3 * t + ph) + 0.04 * cos(5 * t + ph * 0.7)
            out[i * 2] = (0.5 + r * 1.1 * cos(t)).toFloat()
            out[i * 2 + 1] = (0.5 + r * 0.8 * sin(t)).toFloat()
        }
        return out
    }

    private fun readCache(text: String): Map<Int, FloatArray> {
        val o = JSONObject(text)
        val m = HashMap<Int, FloatArray>()
        for (k in o.keys()) {
            val a = o.getJSONArray(k)
            m[k.toInt()] = FloatArray(a.length()) { a.getDouble(it).toFloat() }
        }
        return m
    }

    private fun writeCache(m: Map<Int, FloatArray>): String {
        val o = JSONObject()
        for ((k, v) in m) {
            val a = JSONArray()
            for (f in v) a.put(f.toDouble())
            o.put(k.toString(), a)
        }
        return o.toString()
    }
}
