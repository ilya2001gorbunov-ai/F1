package com.f1.countdown

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.f1.countdown.ui.App
import com.f1.countdown.ui.F1Theme
import com.f1.countdown.widget.RaceWidgetProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.f1.countdown.data.AppSettings.load(this)
        setContent {
            F1Theme { App() }
        }
    }

    override fun onResume() {
        super.onResume()
        RaceWidgetProvider.refresh(this)
    }
}
