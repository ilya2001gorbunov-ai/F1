package com.f1.countdown.data

import android.content.Context
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Настоящие логотипы команд и фото пилотов.
 * Источники: Википедия / Викиданные / Wikimedia Commons (официальные логотипы и портреты).
 * Найденные адреса запоминаются на устройстве, поэтому повторно из сети ищутся только один раз.
 */
object Media {
    private const val PREFS = "media_cache"
    private val mem = ConcurrentHashMap<String, String>()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun segment(wikiUrl: String): String? =
        wikiUrl.substringAfter("/wiki/", "").substringBefore('#').substringBefore('?').takeIf { it.isNotBlank() }

    /** Кэш: найденные адреса хранятся на устройстве; «не нашли» держим только до перезапуска. Ошибка сети — исключение. */
    private fun cached(ctx: Context, key: String, compute: () -> String?): String? {
        mem[key]?.let { return it.ifEmpty { null } }
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.getString(key, null)?.takeIf { it.isNotEmpty() }?.let {
            mem[key] = it
            return it
        }
        val v = compute() ?: ""
        mem[key] = v
        if (v.isNotEmpty()) prefs.edit().putString(key, v).apply()
        return v.ifEmpty { null }
    }

    // ---------- Официальный сайт formula1.com ----------
    private const val F1 = "https://www.formula1.com"
    private const val F1_IMG = "https://media.formula1.com/image/upload"

    private fun teamSlug(id: String) = when (id) {
        "red_bull" -> "red-bull-racing"
        "rb" -> "racing-bulls"
        "aston_martin" -> "aston-martin"
        "sauber" -> "audi"
        else -> id.replace('_', '-')
    }

    private val TEAM_LOGO = Regex("(v\\d+/common/f1/\\d{4}/[a-z0-9]+/\\d{4}[a-z0-9]*logo[a-z0-9]*\\.(?:webp|png|svg))")
    private val DRIVER_IMG = Regex("(v\\d+/common/f1/\\d{4}/[a-z0-9]+/([a-z]{6})01/[a-z0-9]*01[a-z]*\\.(?:webp|png|jpg))")

    /** Логотип команды со страницы formula1.com/en/teams/<команда> (белый логотип на тёмном фоне). */
    private fun f1TeamLogo(teamId: String): String? {
        val html = Http.getString("$F1/en/teams/${teamSlug(teamId)}", BROWSER_UA)
        val all = TEAM_LOGO.findAll(html).map { it.groupValues[1] }.toList()
        val pick = all.firstOrNull { it.contains("white") } ?: all.firstOrNull() ?: return null
        return "$F1_IMG/c_fit,h_128/q_auto/$pick"
    }

    private fun plain(s: String): String =
        java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").lowercase().filter { it in 'a'..'z' }

    /** «…/Andrea_Kimi_Antonelli» → «ant» (первые три буквы фамилии без диакритики). */
    private fun family3(wikiUrl: String): String? {
        val tokens = segment(wikiUrl)?.let { java.net.URLDecoder.decode(it, "UTF-8") }
            ?.split('_')?.filter { it.isNotBlank() && !it.startsWith("Jr") && !it.startsWith("(") } ?: return null
        return tokens.lastOrNull()?.let { plain(it).take(3) }?.takeIf { it.length == 3 }
    }

    @Volatile private var driverIndexLoaded = false

    /** Одна загрузка страницы со всеми пилотами: запоминаем фото каждого. */
    private fun loadDriverIndex(ctx: Context) {
        if (driverIndexLoaded) return
        val html = Http.getString("$F1/en/drivers", BROWSER_UA)
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        for (m in DRIVER_IMG.findAll(html)) {
            val fam = m.groupValues[2].substring(3)
            val key = "f1d3:$fam"
            if (mem[key].isNullOrEmpty()) {
                val url = "$F1_IMG/c_lfill,w_260/q_auto/${m.groupValues[1]}"
                mem[key] = url
                prefs.putString(key, url)
            }
        }
        prefs.apply()
        driverIndexLoaded = true
    }

    private fun f1DriverPhoto(ctx: Context, wikiUrl: String): String? {
        val fam = family3(wikiUrl) ?: return null
        val key = "f1d3:$fam"
        mem[key]?.takeIf { it.isNotEmpty() }?.let { return it }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, null)?.takeIf { it.isNotEmpty() }
            ?.let { mem[key] = it; return it }
        loadDriverIndex(ctx)
        return mem[key]?.takeIf { it.isNotEmpty() }
    }

    private val LOGO_WORDS = Regex("logo|emblem|badge|crest|wordmark|лого|эмблем", RegexOption.IGNORE_CASE)
    private val BAD_WORDS = Regex("flag|commons-logo|edit-|question|symbol|wikimedia|wikipedia-logo|ambox", RegexOption.IGNORE_CASE)

    private fun bigger(src: String): String {
        val u = if (src.startsWith("//")) "https:$src" else src
        // миниатюры Википедии: просим размер 250 px — чёткий логотип без лишнего веса
        return Regex("/\\d+px-").replace(u, "/250px-")
    }

    /** Логотип из карточки (infobox) статьи в Википедии: берём картинку, в имени файла которой есть «logo» и т. п. */
    private fun infoboxLogo(wiki: String, title: String): String? {
        val text = Http.getString(
            "https://$wiki.wikipedia.org/w/api.php?action=parse&prop=text&section=0&redirects=1" +
                "&disableeditsection=1&format=json&page=$title",
        )
        val t = JSONObject(text).optJSONObject("parse")?.optJSONObject("text")?.optString("*") ?: return null
        val start = t.indexOf("infobox").takeIf { it >= 0 } ?: 0
        val end = t.indexOf("</table>", start).takeIf { it > start } ?: minOf(t.length, start + 40_000)
        val box = t.substring(start, end)
        val src = Regex("<img[^>]+src=\"([^\"]+)\"").findAll(box).map { it.groupValues[1] }
            .filter { it.contains("upload.wikimedia.org") }
            .firstOrNull {
                val name = java.net.URLDecoder.decode(it, "UTF-8")
                LOGO_WORDS.containsMatchIn(name) && !BAD_WORDS.containsMatchIn(name)
            }
        return src?.let { bigger(it) }
    }

    /** Файл логотипа из свойства «логотип» (P154) элемента Викиданных страницы. */
    private fun wikidataLogo(title: String): String? {
        val pages = JSONObject(
            Http.getString(
                "https://en.wikipedia.org/w/api.php?action=query&prop=pageprops&ppprop=wikibase_item" +
                    "&redirects=1&format=json&titles=$title",
            ),
        ).getJSONObject("query").getJSONObject("pages")
        val qid = pages.keys().asSequence().firstNotNullOfOrNull {
            pages.getJSONObject(it).optJSONObject("pageprops")?.optString("wikibase_item")?.takeIf { q -> q.isNotBlank() }
        } ?: return null
        val claims = JSONObject(
            Http.getString("https://www.wikidata.org/w/api.php?action=wbgetclaims&format=json&entity=$qid&property=P154"),
        ).optJSONObject("claims")?.optJSONArray("P154")
        val file = claims?.optJSONObject(0)?.optJSONObject("mainsnak")?.optJSONObject("datavalue")
            ?.optString("value")?.takeIf { it.isNotBlank() } ?: return null
        return "https://commons.wikimedia.org/wiki/Special:FilePath/${enc(file)}?width=256"
    }

    /** Последняя попытка: поиск файла «<команда> logo» в Wikimedia Commons. */
    private fun commonsLogo(teamName: String): String? {
        val key = teamName.split(' ', '-').first().lowercase()
        val text = Http.getString(
            "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrlimit=8" +
                "&gsrsearch=${enc("$teamName logo")}&prop=imageinfo&iiprop=url&iiurlwidth=256&format=json",
        )
        val pages = JSONObject(text).optJSONObject("query")?.optJSONObject("pages") ?: return null
        for (k in pages.keys()) {
            val pg = pages.getJSONObject(k)
            val title = pg.optString("title")
            val low = title.lowercase()
            if (!low.contains("logo") || !low.contains(key) || BAD_WORDS.containsMatchIn(low)) continue
            if (!(low.endsWith(".svg") || low.endsWith(".png"))) continue
            pg.optJSONArray("imageinfo")?.optJSONObject(0)?.optString("thumburl")?.takeIf { it.isNotBlank() }
                ?.let { return it }
        }
        return null
    }

    /** Адрес логотипа команды по constructorId (например «mercedes»), либо null. */
    fun teamLogo(ctx: Context, teamId: String): String? = try {
        cached(ctx, "team3:$teamId") {
            try { f1TeamLogo(teamId) } catch (_: Exception) { null }?.let { return@cached it }
            val ct = JSONObject(Http.getString("https://api.jolpi.ca/ergast/f1/constructors/$teamId.json"))
                .getJSONObject("MRData").getJSONObject("ConstructorTable").getJSONArray("Constructors")
            val c = ct.optJSONObject(0) ?: return@cached null
            val title = segment(c.optString("url"))
            var found: String? = null
            if (title != null) {
                found = try { infoboxLogo("en", title) } catch (_: Exception) { null }
                if (found == null) found = try { wikidataLogo(title) } catch (_: Exception) { null }
            }
            if (found == null) found = try { commonsLogo(c.optString("name")) } catch (_: Exception) { null }
            found
        }
    } catch (_: Exception) {
        null
    }

    /** Адрес фото пилота по ссылке на его страницу в Википедии (поле url из Ergast), либо null. */
    fun driverPhoto(ctx: Context, wikiUrl: String): String? = try {
        val title = segment(wikiUrl)
        val official = try { f1DriverPhoto(ctx, wikiUrl) } catch (_: Exception) { null }
        if (official != null) {
            official
        } else if (title == null) {
            null
        } else {
            cached(ctx, "drv2:$title") {
                JSONObject(Http.getString("https://en.wikipedia.org/api/rest_v1/page/summary/$title"))
                    .optJSONObject("thumbnail")?.optString("source")?.takeIf { it.isNotBlank() }
            }
        }
    } catch (_: Exception) {
        null
    }
}
