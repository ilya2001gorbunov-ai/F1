package com.f1.countdown.ui

import com.f1.countdown.data.title
import com.f1.countdown.data.tr
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1.countdown.data.Fmt
import com.f1.countdown.data.Race
import com.f1.countdown.data.Schedule
import com.f1.countdown.data.TrackRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.Instant
import kotlin.math.min

@Composable
fun rememberNow(periodMs: Long): State<Instant> = produceState(Instant.now()) {
    while (true) {
        delay(periodMs)
        value = Instant.now()
    }
}

private fun DrawScope.drawTrack(p: FloatArray, color: Color, strokePx: Float) {
    val pad = strokePx * 2
    val side = min(size.width, size.height) - pad * 2
    if (side <= 0f) return
    val ox = (size.width - side) / 2
    val oy = (size.height - side) / 2
    val path = Path()
    for (i in 0 until p.size / 2) {
        val x = ox + p[i * 2] * side
        val y = oy + p[i * 2 + 1] * side
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    drawPath(path, color, style = Stroke(width = strokePx, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

/** Карта трассы линией (грузится в фоне). */
@Composable
fun TrackImage(race: Race, modifier: Modifier, color: Color = Color.White, stroke: Dp = 2.dp) {
    val ctx = LocalContext.current.applicationContext
    val pts by produceState<FloatArray?>(null, race.round) {
        value = withContext(Dispatchers.Default) { TrackRepo.points(ctx, race) }
    }
    val p = pts
    Canvas(modifier) {
        if (p != null) drawTrack(p, color, stroke.toPx())
    }
}

@Composable
fun RaceRow(race: Race, now: Instant, modifier: Modifier = Modifier) {
    val isPast = now.isAfter(race.end)
    val isNext = Schedule.next(now)?.round == race.round
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    Card(
        modifier = modifier
            .fillMaxWidth()
            .alpha(if (isPast) 0.5f else 1f),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = if (isNext) BorderStroke(1.dp, F1Red) else null,
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "${tr("ЭТАП")} ${race.round}" + if (isNext) " · ${tr("БЛИЖАЙШАЯ")}" else "",
                    fontSize = 11.sp,
                    letterSpacing = 1.sp,
                    color = if (isNext) F1Red else gray,
                )
                Text("${race.flag} ${race.title}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${race.circuit} · ${race.city}", style = MaterialTheme.typography.bodySmall, color = gray)
                Spacer(Modifier.height(6.dp))
                Text(Fmt.full(race), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            }
            TrackImage(race, Modifier.size(72.dp))
        }
    }
}

@Composable
fun CountBox(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(end = 16.dp)) {
        Text(value, fontSize = 30.sp, fontWeight = FontWeight.Light)
        Text(label, fontSize = 10.sp, letterSpacing = 1.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}
