package com.f1.countdown.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.f1.countdown.data.APP_LANGS
import com.f1.countdown.data.AppSettings
import com.f1.countdown.data.tr
import com.f1.countdown.widget.RaceWidgetProvider
import java.time.ZoneId

/** Настройки приложения: язык и часовой пояс (по умолчанию — автоматически). */
@Composable
fun SettingsDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var screen by remember { mutableIntStateOf(0) }
    val gray = MaterialTheme.colorScheme.onSurfaceVariant

    fun applied() {
        RaceWidgetProvider.refresh(ctx)
        screen = 0
    }

    when (screen) {
        1 -> Picker(
            title = tr("Язык"),
            items = listOf("auto" to tr("Автоматически")) + APP_LANGS.map { it.code to it.native },
            selected = AppSettings.langPref,
            onPick = { AppSettings.setLang(ctx, it); applied() },
            onBack = { screen = 0 },
        )
        2 -> {
            val now = java.time.Instant.now()
            val zones = AppSettings.ZONES
                .filter { runCatching { ZoneId.of(it) }.isSuccess }
                .sortedBy { ZoneId.of(it).rules.getOffset(now).totalSeconds }
                .map { id ->
                    id to "${AppSettings.offsetLabel(ZoneId.of(id), now)} · ${AppSettings.zoneName(id)}"
                }
            val auto = "${tr("Автоматически (устройство)")} · ${AppSettings.offsetLabel(ZoneId.systemDefault(), now)}"
            Picker(
                title = tr("Часовой пояс"),
                items = listOf("auto" to auto) + zones,
                selected = AppSettings.zonePref,
                onPick = { AppSettings.setZone(ctx, it); applied() },
                onBack = { screen = 0 },
            )
        }
        else -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(tr("Настройки")) },
            text = {
                Column {
                    val langText = if (AppSettings.langPref == "auto") {
                        "${tr("Автоматически")} · ${APP_LANGS.first { it.code == AppSettings.lang }.native}"
                    } else {
                        APP_LANGS.first { it.code == AppSettings.langPref }.native
                    }
                    val zoneText = if (AppSettings.zonePref == "auto") {
                        "${tr("Автоматически")} · ${AppSettings.zoneLabel()}"
                    } else {
                        "${AppSettings.zoneLabel()} · ${AppSettings.zoneName(AppSettings.zonePref)}"
                    }
                    SettingRow(tr("Язык"), langText) { screen = 1 }
                    HorizontalDivider(color = gray.copy(alpha = 0.3f))
                    SettingRow(tr("Часовой пояс"), zoneText) { screen = 2 }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Готово")) } },
        )
    }
}

@Composable
private fun SettingRow(title: String, value: String, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
    ) {
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(value, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Picker(
    title: String,
    items: List<Pair<String, String>>,
    selected: String,
    onPick: (String) -> Unit,
    onBack: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onBack,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                for ((key, label) in items) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(key) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = key == selected, onClick = { onPick(key) })
                        Text(label, modifier = Modifier.padding(end = 4.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
            }
        },
        confirmButton = { TextButton(onClick = onBack) { Text(tr("Отмена")) } },
    )
}
