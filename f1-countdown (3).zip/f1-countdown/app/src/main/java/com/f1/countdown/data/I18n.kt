package com.f1.countdown.data

import java.util.Locale

/** Языки приложения (страны СНГ). Порядок кодов совпадает с порядком переводов в таблице ниже (после русского). */
class AppLang(val code: String, val native: String)

val APP_LANGS = listOf(
    AppLang("ru", "Русский"),
    AppLang("be", "Беларуская"),
    AppLang("kk", "Қазақша"),
    AppLang("uz", "Oʻzbekcha"),
    AppLang("hy", "Հայերեն"),
    AppLang("az", "Azərbaycanca"),
    AppLang("ky", "Кыргызча"),
    AppLang("tg", "Тоҷикӣ"),
    AppLang("tk", "Türkmençe"),
    AppLang("ro", "Română"),
)

/** Перевод строки интерфейса. Ключ — русский текст; если перевода нет, показывается русский. */
fun tr(ru: String): String {
    val lang = AppSettings.lang
    if (lang == "ru") return ru
    val i = APP_LANGS.indexOfFirst { it.code == lang } - 1
    if (i < 0) return ru
    return TABLE[ru]?.getOrNull(i) ?: ru
}

private fun isoOf(flag: String): String? {
    val cps = flag.codePoints().toArray()
    if (cps.size != 2 || cps.any { it !in 0x1F1E6..0x1F1FF }) return null
    return String(CharArray(2) { 'A' + (cps[it] - 0x1F1E6) })
}

private val CITY_GP = mapOf(
    "Гран-при Майами" to "Miami",
    "Гран-при Лас-Вегаса" to "Las Vegas",
    "Гран-при Сан-Паулу" to "São Paulo",
    "Гран-при Барселоны" to "Barcelona",
)

/** Название места проведения Гран-при на выбранном языке («Италия», «Italy»…). */
val Race.place: String
    get() {
        val ruPlace = name.removePrefix("Гран-при ")
        if (AppSettings.lang == "ru") return ruPlace
        CITY_GP[name]?.let { return it }
        val country = isoOf(flag)?.let { Locale("", it).getDisplayCountry(AppSettings.locale) }
        return country?.takeIf { it.isNotBlank() } ?: ruPlace
    }

/** Полное название этапа: «Гран-при Италии» / «Гран-при: Италия» на других языках. */
val Race.title: String
    get() = if (AppSettings.lang == "ru") name else "${tr("Гран-при")}: $place"

private val TABLE: Map<String, Array<String>> = mapOf(
    "Новости" to arrayOf("Навіны", "Жаңалықтар", "Yangiliklar", "Նորություններ", "Xəbərlər", "Жаңылыктар", "Хабарҳо", "Habarlar", "Știri"),
    "Календарь" to arrayOf("Каляндар", "Күнтізбе", "Taqvim", "Օրացույց", "Təqvim", "Календарь", "Тақвим", "Senenama", "Calendar"),
    "Зачёт" to arrayOf("Залік", "Есеп", "Reyting", "Աղյուսակ", "Xal cədvəli", "Эсеп", "Ҷадвал", "Hasap", "Clasament"),
    "Месяц" to arrayOf("Месяц", "Ай", "Oy", "Ամիս", "Ay", "Ай", "Моҳ", "Aý", "Lună"),
    "Список" to arrayOf("Спіс", "Тізім", "Roʻyxat", "Ցանկ", "Siyahı", "Тизме", "Феҳрист", "Sanaw", "Listă"),
    "Пилоты" to arrayOf("Пілоты", "Жүргізушілер", "Uchuvchilar", "Վարորդներ", "Pilotlar", "Айдоочулар", "Ронандагон", "Sürüjiler", "Piloți"),
    "Команды" to arrayOf("Каманды", "Командалар", "Jamoalar", "Թիմեր", "Komandalar", "Командалар", "Дастаҳо", "Toparlar", "Echipe"),
    "Закрыть" to arrayOf("Закрыць", "Жабу", "Yopish", "Փակել", "Bağla", "Жабуу", "Пӯшидан", "Ýap", "Închide"),
    "Отмена" to arrayOf("Адмена", "Бас тарту", "Bekor qilish", "Չեղարկել", "Ləğv et", "Жокко чыгаруу", "Бекор кардан", "Ýatyr", "Anulează"),
    "Повторить" to arrayOf("Паўтарыць", "Қайталау", "Takrorlash", "Կրկնել", "Təkrarla", "Кайталоо", "Такрор кардан", "Gaýtala", "Reîncearcă"),
    "Обновить" to arrayOf("Абнавіць", "Жаңарту", "Yangilash", "Թարմացնել", "Yenilə", "Жаңыртуу", "Навсозӣ", "Täzele", "Actualizează"),
    "+ Виджет" to arrayOf("+ Віджэт", "+ Виджет", "+ Vidjet", "+ Վիջեթ", "+ Vidcet", "+ Виджет", "+ Виҷет", "+ Widjet", "+ Widget"),
    "Добавить виджет" to arrayOf("Дадаць віджэт", "Виджет қосу", "Vidjet qoʻshish", "Ավելացնել վիջեթ", "Vidcet əlavə et", "Виджет кошуу", "Иловаи виҷет", "Widjet goş", "Adaugă widget"),
    "Нажмите, чтобы добавить на главный экран" to arrayOf("Націсніце, каб дадаць на галоўны экран", "Басты экранға қосу үшін басыңыз", "Bosh ekranga qoʻshish uchun bosing", "Սեղմեք՝ գլխավոր էկրանին ավելացնելու համար", "Əsas ekrana əlavə etmək üçün toxunun", "Башкы экранга кошуу үчүн басыңыз", "Барои илова ба экрани асосӣ пахш кунед", "Esasy ekrana goşmak üçin basyň", "Atingeți pentru a adăuga pe ecranul principal"),
    "Долгое нажатие на рабочем столе → Виджеты → All F1" to arrayOf("Доўгае націсканне на працоўным стале → Віджэты → All F1", "Үстелді ұзақ басыңыз → Виджеттер → All F1", "Ish stolini uzoq bosing → Vidjetlar → All F1", "Երկար սեղմեք աշխատասեղանին → Վիջեթներ → All F1", "Əsas ekranda uzun basın → Vidcetlər → All F1", "Столду узак басыңыз → Виджеттер → All F1", "Рӯйдастро дароз пахш кунед → Виҷетҳо → All F1", "Esasy ekrany uzak basyň → Widjetler → All F1", "Apăsați lung pe ecranul principal → Widgeturi → All F1"),
    "Классический 4×2" to arrayOf("Класічны 4×2", "Классикалық 4×2", "Klassik 4×2", "Դասական 4×2", "Klassik 4×2", "Классикалык 4×2", "Классикӣ 4×2", "Klassiki 4×2", "Clasic 4×2"),
    "Компактный 2×2" to arrayOf("Кампактны 2×2", "Шағын 2×2", "Ixcham 2×2", "Կոմպակտ 2×2", "Kompakt 2×2", "Компакттуу 2×2", "Паймон 2×2", "Kiçi 2×2", "Compact 2×2"),
    "Цвета флага 4×2" to arrayOf("Колеры сцяга 4×2", "Ту түстері 4×2", "Bayroq ranglari 4×2", "Դրոշի գույներ 4×2", "Bayraq rəngləri 4×2", "Желек түстөрү 4×2", "Рангҳои парчам 4×2", "Baýdak reňkleri 4×2", "Culorile drapelului 4×2"),
    "Настройки" to arrayOf("Налады", "Баптаулар", "Sozlamalar", "Կարգավորումներ", "Parametrlər", "Жөндөөлөр", "Танзимот", "Sazlamalar", "Setări"),
    "Язык" to arrayOf("Мова", "Тіл", "Til", "Լեզու", "Dil", "Тил", "Забон", "Dil", "Limba"),
    "Часовой пояс" to arrayOf("Гадзінны пояс", "Уақыт белдеуі", "Vaqt zonasi", "Ժամային գոտի", "Saat qurşağı", "Убакыт алкагы", "Минтақаи вақт", "Wagt guşagy", "Fus orar"),
    "Автоматически" to arrayOf("Аўтаматычна", "Автоматты", "Avtomatik", "Ավտոմատ", "Avtomatik", "Автоматтык", "Худкор", "Awtomatik", "Automat"),
    "Автоматически (устройство)" to arrayOf("Аўтаматычна (прылада)", "Автоматты (құрылғы)", "Avtomatik (qurilma)", "Ավտոմատ (սարք)", "Avtomatik (cihaz)", "Автоматтык (түзмөк)", "Худкор (дастгоҳ)", "Awtomatik (enjam)", "Automat (dispozitiv)"),
    "Готово" to arrayOf("Гатова", "Дайын", "Tayyor", "Պատրաստ է", "Hazır", "Даяр", "Тайёр", "Taýyn", "Gata"),
    "Не удалось загрузить новости. Проверьте интернет и нажмите «Обновить»." to arrayOf("Не ўдалося загрузіць навіны. Праверце інтэрнэт і націсніце «Абнавіць».", "Жаңалықтарды жүктеу мүмкін болмады. Интернетті тексеріп, «Жаңарту» түймесін басыңыз.", "Yangiliklarni yuklab boʻlmadi. Internetni tekshirib, «Yangilash» tugmasini bosing.", "Չհաջողվեց բեռնել նորությունները։ Ստուգեք ինտերնետը և սեղմեք «Թարմացնել»։", "Xəbərləri yükləmək alınmadı. İnterneti yoxlayıb «Yenilə» düyməsinə basın.", "Жаңылыктарды жүктөө мүмкүн болгон жок. Интернетти текшерип, «Жаңыртуу» баскычын басыңыз.", "Хабарҳо бор нашуданд. Интернетро санҷед ва «Навсозӣ»-ро пахш кунед.", "Habarlary ýükläp bolmady. Internetiňizi barlaň we «Täzele» düwmesine basyň.", "Nu s-au putut încărca știrile. Verificați internetul și apăsați «Actualizează»."),
    "Сезон 2026 завершён. До встречи в новом сезоне!" to arrayOf("Сезон 2026 завершаны. Да сустрэчы ў новым сезоне!", "2026 маусымы аяқталды. Жаңа маусымда кездескенше!", "2026-yil mavsumi yakunlandi. Yangi mavsumda koʻrishguncha!", "2026 մրցաշրջանը ավարտվել է։ Կհանդիպենք նոր մրցաշրջանում։", "2026 mövsümü başa çatdı. Yeni mövsümdə görüşənədək!", "2026-жылдын сезону аяктады. Жаңы сезондо көрүшкөнчө!", "Мавсими 2026 ба охир расид. То дидор дар мавсими нав!", "2026 möwsümi tamamlandy. Täze möwsümde duşuşarys!", "Sezonul 2026 s-a încheiat. Ne vedem în noul sezon!"),
    "БЛИЖАЙШЕЕ СОБЫТИЕ" to arrayOf("БЛІЖЭЙШАЯ ПАДЗЕЯ", "ЖАҚЫНДАҒЫ ОҚИҒА", "ENG YAQIN VOQEA", "ՀԱՋՈՐԴ ՄԻՋՈՑԸ", "ƏN YAXIN HADİSƏ", "ЭҢ ЖАКЫНКЫ ОКУЯ", "ТАДБИРИ НАЗДИКТАРИН", "IŇ ÝAKYN WAKA", "CEL MAI APROPIAT EVENIMENT"),
    "ДНЕЙ" to arrayOf("ДЗЁН", "КҮН", "KUN", "ՕՐ", "GÜN", "КҮН", "РӮЗ", "GÜN", "ZILE"),
    "ЧАСОВ" to arrayOf("ГАДЗІН", "САҒАТ", "SOAT", "ԺԱՄ", "SAAT", "САГАТ", "СОАТ", "SAGAT", "ORE"),
    "МИНУТ" to arrayOf("ХВІЛІН", "МИНУТ", "DAQIQA", "ՐՈՊԵ", "DƏQİQƏ", "МҮНӨТ", "ДАҚИҚА", "MINUT", "MINUTE"),
    "СЕК" to arrayOf("СЕК", "СЕК", "SEK", "ՎՐԿ", "SAN", "СЕК", "СОН", "SEK", "SEC"),
    "ЭТАП" to arrayOf("ЭТАП", "КЕЗЕҢ", "BOSQICH", "ԷՏԱՊ", "MƏRHƏLƏ", "ЭТАП", "МАРҲИЛА", "ŞAPY", "ETAPA"),
    "БЛИЖАЙШИЙ" to arrayOf("БЛІЖЭЙШЫ", "ЖАҚЫНДАҒЫ", "ENG YAQIN", "ՀԱՋՈՐԴ", "ƏN YAXIN", "ЭҢ ЖАКЫН", "НАЗДИКТАРИН", "IŇ ÝAKYN", "CEL MAI APROPIAT"),
    "БЛИЖАЙШАЯ" to arrayOf("БЛІЖЭЙШАЯ", "ЖАҚЫНДАҒЫ", "ENG YAQIN", "ՀԱՋՈՐԴ", "ƏN YAXIN", "ЭҢ ЖАКЫН", "НАЗДИКТАРИН", "IŇ ÝAKYN", "CEA MAI APROPIATĂ"),
    "Гонка" to arrayOf("Гонка", "Жарыс", "Poyga", "Մրցավազք", "Yarış", "Жарыш", "Мусобиқа", "Ýaryş", "Cursă"),
    "Заезд" to arrayOf("Гонка", "Жарыс", "Poyga", "Մրցավազք", "Yarış", "Жарыш", "Мусобиқа", "Ýaryş", "Cursă"),
    "Спринт" to arrayOf("Спрынт", "Спринт", "Sprint", "Սպրինտ", "Sprint", "Спринт", "Спринт", "Sprint", "Sprint"),
    "Квалиф." to arrayOf("Кваліф.", "Саралау", "Kval.", "Որակ.", "Kvalif.", "Квалиф.", "Квалиф.", "Kwalif.", "Calif."),
    "Практика" to arrayOf("Практыка", "Жаттығу", "Mashq", "Վարժանք", "Məşq", "Машыгуу", "Машқ", "Türgenleşik", "Antrenament"),
    "Свободная практика 1" to arrayOf("Свабодная практыка 1", "Еркін жаттығу 1", "Erkin mashq 1", "Ազատ մարզում 1", "Sərbəst məşq 1", "Эркин машыгуу 1", "Машқи озод 1", "Erkin türgenleşik 1", "Antrenamente libere 1"),
    "Свободная практика 2" to arrayOf("Свабодная практыка 2", "Еркін жаттығу 2", "Erkin mashq 2", "Ազատ մարզում 2", "Sərbəst məşq 2", "Эркин машыгуу 2", "Машқи озод 2", "Erkin türgenleşik 2", "Antrenamente libere 2"),
    "Свободная практика 3" to arrayOf("Свабодная практыка 3", "Еркін жаттығу 3", "Erkin mashq 3", "Ազատ մարզում 3", "Sərbəst məşq 3", "Эркин машыгуу 3", "Машқи озод 3", "Erkin türgenleşik 3", "Antrenamente libere 3"),
    "Спринт-квалификация" to arrayOf("Спрынт-кваліфікацыя", "Спринт іріктеуі", "Sprint saralashi", "Սպրինտ-որակավորում", "Sprint təsnifatı", "Спринт саралоосу", "Квалификатсияи спринт", "Sprint saýlama ýaryşy", "Calificări sprint"),
    "Квалификация" to arrayOf("Кваліфікацыя", "Іріктеу", "Saralash", "Որակավորում", "Təsnifat", "Саралоо", "Квалификатсия", "Saýlama ýaryş", "Calificări"),
    "Время" to arrayOf("Час", "Уақыт", "Vaqt", "Ժամանակ", "Vaxt", "Убакыт", "Вақт", "Wagt", "Ora"),
    "Нажмите на дату или событие." to arrayOf("Націсніце на дату або падзею.", "Күнді немесе оқиғаны басыңыз.", "Sana yoki voqeani bosing.", "Սեղմեք ամսաթվի կամ իրադարձության վրա։", "Tarixə və ya hadisəyə toxunun.", "Датаны же окуяны басыңыз.", "Ба сана ё чорабинӣ пахш кунед.", "Senä ýa-da wakana basyň.", "Apăsați pe dată sau eveniment."),
    "В этом месяце событий нет" to arrayOf("У гэтым месяцы падзей няма", "Бұл айда оқиғалар жоқ", "Bu oyda voqealar yoʻq", "Այս ամսում իրադարձություններ չկան", "Bu ayda hadisə yoxdur", "Бул айда окуялар жок", "Дар ин моҳ чорабиниҳо нест", "Bu aýda wakalar ýok", "În această lună nu sunt evenimente"),
    "Расписание уикенда" to arrayOf("Расклад уікенда", "Уикенд кестесі", "Hafta oxiri jadvali", "Շաբաթավերջի ծրագիր", "Həftəsonu cədvəli", "Уикенд тартиби", "Ҷадвали рӯзҳои мусобиқа", "Ýaryş dynç güni tertibi", "Programul weekendului"),
    "Загружаю итоги…" to arrayOf("Загружаю вынікі…", "Нәтижелер жүктелуде…", "Natijalar yuklanmoqda…", "Բեռնվում են արդյունքները…", "Nəticələr yüklənir…", "Жыйынтыктар жүктөлүүдө…", "Натиҷаҳо бор мешаванд…", "Netijeler ýüklenýär…", "Se încarcă rezultatele…"),
    "Загружаю результаты…" to arrayOf("Загружаю вынікі…", "Нәтижелер жүктелуде…", "Natijalar yuklanmoqda…", "Բեռնվում են արդյունքները…", "Nəticələr yüklənir…", "Жыйынтыктар жүктөлүүдө…", "Натиҷаҳо бор мешаванд…", "Netijeler ýüklenýär…", "Se încarcă rezultatele…"),
    "Раньше Гран-при на этой трассе не проводились — данных для сравнения нет." to arrayOf("Раней Гран-пры на гэтай трасе не праводзіліся — даных для параўнання няма.", "Бұрын бұл трассада Гран-при өтпеген — салыстыру үшін дерек жоқ.", "Avval bu trassada Gran-pri oʻtkazilmagan — solishtirish uchun maʼlumot yoʻq.", "Նախկինում այս ուղու վրա Գրան պրի չի անցկացվել․ համեմատելու տվյալներ չկան։", "Əvvəllər bu trasda Qran-pri keçirilməyib — müqayisə üçün məlumat yoxdur.", "Мурда бул трассада Гран-при өтпөгөн — салыштыруу үчүн маалымат жок.", "Қаблан дар ин трасса Гран-при баргузор нашудааст — маълумот барои муқоиса нест.", "Öň bu ýolda Grand Pri geçirilmändi — deňeşdirmek üçin maglumat ýok.", "Pe acest circuit nu s-a mai desfășurat un Mare Premiu — nu există date pentru comparație."),
    "Не удалось загрузить итоги прошлого заезда. Проверьте интернет." to arrayOf("Не ўдалося загрузіць вынікі мінулай гонкі. Праверце інтэрнэт.", "Өткен жарыстың нәтижелерін жүктеу мүмкін болмады. Интернетті тексеріңіз.", "Oʻtgan poyga natijalarini yuklab boʻlmadi. Internetni tekshiring.", "Չհաջողվեց բեռնել նախորդ մրցավազքի արդյունքները։ Ստուգեք ինտերնետը։", "Keçən yarışın nəticələrini yükləmək alınmadı. İnterneti yoxlayın.", "Өткөн жарыштын жыйынтыктарын жүктөө мүмкүн болгон жок. Интернетти текшериңиз.", "Натиҷаҳои мусобиқаи гузашта бор нашуданд. Интернетро санҷед.", "Geçen ýaryşyň netijelerini ýükläp bolmady. Internetiňizi barlaň.", "Nu s-au putut încărca rezultatele cursei anterioare. Verificați internetul."),
    "Итоги этого этапа" to arrayOf("Вынікі гэтага этапу", "Осы кезеңнің қорытындысы", "Ushbu bosqich natijalari", "Այս էտապի արդյունքները", "Bu mərhələnin nəticələri", "Ушул этаптын жыйынтыгы", "Натиҷаҳои ин марҳила", "Bu şapyň netijeleri", "Rezultatele acestei etape"),
    "Прошлый заезд на этой трассе" to arrayOf("Мінулая гонка на гэтай трасе", "Осы трассадағы өткен жарыс", "Ushbu trassadagi oxirgi poyga", "Այս ուղու վրա նախորդ մրցավազքը", "Bu trasdakı keçən yarış", "Ушул трассадагы мурунку жарыш", "Мусобиқаи гузашта дар ин трасса", "Bu ýoldaky geçen ýaryş", "Cursa anterioară pe acest circuit"),
    "Результаты ещё не опубликованы — загляните чуть позже." to arrayOf("Вынікі яшчэ не апублікаваны — зазірніце крыху пазней.", "Нәтижелер әлі жарияланбады — сәл кейінірек кіріңіз.", "Natijalar hali eʼlon qilinmagan — birozdan keyin qayting.", "Արդյունքները դեռ հրապարակված չեն․ անցեք մի փոքր ուշ։", "Nəticələr hələ dərc olunmayıb — bir az sonra baxın.", "Жыйынтыктар азырынча жарыяланган жок — бир аздан кийин кириңиз.", "Натиҷаҳо ҳанӯз нашр нашудаанд — каме дертар боздид кунед.", "Netijeler entek çap edilmedi — birazdan gaýdyp geliň.", "Rezultatele nu au fost încă publicate — reveniți puțin mai târziu."),
    "Не удалось загрузить результаты. Проверьте интернет." to arrayOf("Не ўдалося загрузіць вынікі. Праверце інтэрнэт.", "Нәтижелерді жүктеу мүмкін болмады. Интернетті тексеріңіз.", "Natijalarni yuklab boʻlmadi. Internetni tekshiring.", "Չհաջողվեց բեռնել արդյունքները։ Ստուգեք ինտերնետը։", "Nəticələri yükləmək alınmadı. İnterneti yoxlayın.", "Жыйынтыктарды жүктөө мүмкүн болгон жок. Интернетти текшериңиз.", "Натиҷаҳо бор нашуданд. Интернетро санҷед.", "Netijeleri ýükläp bolmady. Internetiňizi barlaň.", "Nu s-au putut încărca rezultatele. Verificați internetul."),
    "Результаты" to arrayOf("Вынікі", "Нәтижелер", "Natijalar", "Արդյունքներ", "Nəticələr", "Жыйынтыктар", "Натиҷаҳо", "Netijeler", "Rezultate"),
    "оч." to arrayOf("ачк.", "ұпай", "ball", "միավ.", "xal", "упай", "хол", "utuk", "p."),
    "очки" to arrayOf("ачкі", "ұпай", "ball", "միավոր", "xal", "упай", "хол", "utuk", "puncte"),
    "побед:" to arrayOf("перамог:", "жеңіс:", "gʻalaba:", "հաղթանակ՝", "qələbə:", "жеңиш:", "ғалаба:", "ýeňiş:", "victorii:"),
    "Не удалось загрузить зачёт. Проверьте интернет." to arrayOf("Не ўдалося загрузіць залік. Праверце інтэрнэт.", "Есепті жүктеу мүмкін болмады. Интернетті тексеріңіз.", "Reytingni yuklab boʻlmadi. Internetni tekshiring.", "Չհաջողվեց բեռնել աղյուսակը։ Ստուգեք ինտերնետը։", "Xal cədvəlini yükləmək alınmadı. İnterneti yoxlayın.", "Эсепти жүктөө мүмкүн болгон жок. Интернетти текшериңиз.", "Ҷадвал бор нашуд. Интернетро санҷед.", "Hasaby ýükläp bolmady. Internetiňizi barlaň.", "Nu s-a putut încărca clasamentul. Verificați internetul."),
    "Эфиры и записи всех сессий." to arrayOf("Эфіры і запісы ўсіх сесій.", "Барлық сессиялардың эфирлері мен жазбалары.", "Barcha sessiyalarning efirlari va yozuvlari.", "Բոլոր սեսիաների եթերներն ու ձայնագրությունները։", "Bütün sessiyaların efirləri və yazıları.", "Бардык сессиялардын эфирлери жана жазуулары.", "Пахш ва сабтҳои ҳамаи сессияҳо.", "Ähli sessiýalaryň göni efirleri we ýazgylary.", "Transmisiuni și înregistrări ale tuturor sesiunilor."),
    "БЛИЖАЙШАЯ СЕССИЯ" to arrayOf("БЛІЖЭЙШАЯ СЕСІЯ", "ЖАҚЫНДАҒЫ СЕССИЯ", "ENG YAQIN SESSIYA", "ՀԱՋՈՐԴ ՍԵՍԻԱ", "ƏN YAXIN SESSİYA", "ЭҢ ЖАКЫН СЕССИЯ", "СЕССИЯИ НАЗДИКТАРИН", "IŇ ÝAKYN SESSIÝA", "CEA MAI APROPIATĂ SESIUNE"),
    "АРХИВ СЕССИЙ" to arrayOf("АРХІЎ СЕСІЙ", "СЕССИЯЛАР АРХИВІ", "SESSIYALAR ARXIVI", "ՍԵՍԻԱՆԵՐԻ ԱՐԽԻՎ", "SESSİYA ARXİVİ", "СЕССИЯЛАР АРХИВИ", "АРХИВИ СЕССИЯҲО", "SESSIÝALARYŇ ARHIWI", "ARHIVA SESIUNILOR"),
    "По запросу ничего не найдено." to arrayOf("Па запыце нічога не знойдзена.", "Сұраныс бойынша ештеңе табылмады.", "Soʻrov boʻyicha hech narsa topilmadi.", "Հարցման համար ոչինչ չի գտնվել։", "Sorğu üzrə heç nə tapılmadı.", "Сурам боюнча эч нерсе табылган жок.", "Аз рӯи дархост чизе ёфт нашуд.", "Gözleg boýunça hiç zat tapylmady.", "Nu s-a găsit nimic."),
    "Спринт, Монако, Остин…" to arrayOf("Спрынт, Манака, Осцін…", "Спринт, Монако, Остин…", "Sprint, Monako, Ostin…", "Սպրինտ, Մոնակո, Օսթին…", "Sprint, Monako, Ostin…", "Спринт, Монако, Остин…", "Спринт, Монако, Остин…", "Sprint, Monako, Ostin…", "Sprint, Monaco, Austin…"),
    "Выберите хотя бы одну площадку" to arrayOf("Выберыце хаця б адну пляцоўку", "Кемінде бір алаңды таңдаңыз", "Kamida bitta platformani tanlang", "Ընտրեք առնվազն մեկ հարթակ", "Ən azı bir platforma seçin", "Жок дегенде бир платформаны тандаңыз", "Ақаллан як майдонро интихоб кунед", "Iň bolmanda bir platforma saýlaň", "Selectați cel puțin o platformă"),
    "Кнопки эфира появятся за 10 минут до старта" to arrayOf("Кнопкі эфіру з’явяцца за 10 хвілін да старту", "Эфир түймелері старттан 10 минут бұрын пайда болады", "Efir tugmalari startdan 10 daqiqa oldin paydo boʻladi", "Եթերի կոճակները կհայտնվեն մեկնարկից 10 րոպե առաջ", "Efir düymələri startdan 10 dəqiqə əvvəl görünəcək", "Эфир баскычтары старттан 10 мүнөт мурун пайда болот", "Тугмаҳои пахш 10 дақиқа пеш аз оғоз пайдо мешаванд", "Göni efir düwmeleri başlamazdan 10 minut öň peýda bolar", "Butoanele de transmisie apar cu 10 minute înainte de start"),
    "Ближайший заезд" to arrayOf("Бліжэйшая гонка", "Жақындағы жарыс", "Eng yaqin poyga", "Մոտակա մրցավազք", "Ən yaxın yarış", "Эң жакынкы жарыш", "Мусобиқаи наздиктарин", "Iň ýakyn ýaryş", "Cea mai apropiată cursă"),
    "Эфир" to arrayOf("Эфір", "Эфир", "Efir", "Եթեր", "Efir", "Эфир", "Пахш", "Göni efir", "Transmisie"),
    "Архив" to arrayOf("Архіў", "Архив", "Arxiv", "Արխիվ", "Arxiv", "Архив", "Бойгонӣ", "Arhiw", "Arhivă"),
    "● В ЭФИРЕ" to arrayOf("● У ЭФІРЫ", "● ЭФИРДЕ", "● EFIRDA", "● ԵԹԵՐՈՒՄ", "● EFİRDƏ", "● ЭФИРДЕ", "● ДАР ПАХШ", "● GÖNI EFIRDE", "● ÎN DIRECT"),
    "○ ЖДЁМ ЭФИР" to arrayOf("○ ЧАКАЕМ ЭФІР", "○ ЭФИРДІ КҮТІП ТҰР", "○ EFIRNI KUTMOQDA", "○ ՍՊԱՍՈՒՄ ԵՆՔ ԵԹԵՐԻՆ", "○ EFİR GÖZLƏNİLİR", "○ ЭФИРДИ КҮТҮҮДӨ", "○ ПАХШРО МЕИНТИЗОРЕМ", "○ GÖNI EFIRI GARAŞÝARYS", "○ AȘTEPTĂM TRANSMISIA"),
    "○ ПОДКЛЮЧАЕМСЯ" to arrayOf("○ ПАДКЛЮЧАЕМСА", "○ ҚОСЫЛУДАМЫЗ", "○ ULANMOQDA", "○ ԿԱՊ ԵՆՔ ՀԱՍՏԱՏՈՒՄ", "○ QOŞULUR", "○ УЛАНУУДА", "○ ПЕЙВАНД МЕШАВЕМ", "○ BAGLANYŞÝARYS", "○ SE CONECTEAZĂ"),
    "трансляции с других платформ можно найти в разделе " to arrayOf("Трансляцыі з іншых платформаў — у раздзеле: ", "Басқа платформалардағы трансляциялар мына бөлімде: ", "Boshqa platformalardagi translyatsiyalar bu boʻlimda: ", "Այլ հարթակների հեռարձակումները գտեք այս բաժնում՝ ", "Digər platformalardakı yayımlar bu bölmədə: ", "Башка платформалардагы трансляциялар бул бөлүмдө: ", "Пахшҳо аз платформаҳои дигар дар ин бахш: ", "Beýleki platformalardaky göni efirler şu bölümde: ", "Transmisiunile de pe alte platforme se găsesc în secțiunea: "),
    "СЕЗОН ЗАВЕРШЁН" to arrayOf("СЕЗОН ЗАВЕРШАНЫ", "МАУСЫМ АЯҚТАЛДЫ", "MAVSUM YAKUNLANDI", "ՄՐՑԱՇՐՋԱՆԸ ԱՎԱՐՏՎԵԼ Է", "MÖVSÜM BAŞA ÇATDI", "СЕЗОН АЯКТАДЫ", "МАВСИМ ТАМОМ ШУД", "MÖWSÜM TAMAMLANDY", "SEZON ÎNCHEIAT"),
    "до встречи!" to arrayOf("да сустрэчы!", "кездескенше!", "koʻrishguncha!", "կհանդիպենք։", "görüşənədək!", "көрүшкөнчө!", "то дидор!", "duşuşarys!", "ne vedem!"),
    "до встречи в новом сезоне" to arrayOf("да сустрэчы ў новым сезоне", "жаңа маусымда кездескенше", "yangi mavsumda koʻrishguncha", "կհանդիպենք նոր մրցաշրջանում", "yeni mövsümdə görüşənədək", "жаңы сезондо көрүшкөнчө", "то дидор дар мавсими нав", "täze möwsümde duşuşarys", "ne vedem în noul sezon"),
    "Гран-при" to arrayOf("Гран-пры", "Гран-при", "Gran-pri", "Գրան պրի", "Qran-pri", "Гран-при", "Гран-при", "Grand Pri", "Marele Premiu")
)
