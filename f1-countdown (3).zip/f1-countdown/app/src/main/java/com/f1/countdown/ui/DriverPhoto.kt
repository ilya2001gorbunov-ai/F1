package com.f1.countdown.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.f1.countdown.data.Media
import com.f1.countdown.data.USER_AGENT
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Круглое фото пилота (Википедия). Пока фото грузится или его нет — инициалы. */
@Composable
fun DriverPhoto(name: String, wikiUrl: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val url by produceState<String?>(null, wikiUrl) {
        value = if (wikiUrl.isBlank()) null else withContext(Dispatchers.IO) { Media.driverPhoto(ctx.applicationContext, wikiUrl) }
    }
    val initials = name.split(' ').filter { it.isNotBlank() }.takeLast(2).joinToString("") { it.take(1) }.uppercase()
    val placeholder: @Composable () -> Unit = {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(initials, fontSize = (size.value * 0.34f).sp, fontWeight = FontWeight.Bold, color = Color(0xFFBBBBBB))
        }
    }
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(0xFF2A2A30)),
    ) {
        val u = url
        if (u == null) {
            placeholder()
        } else {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(ctx).data(u).addHeader("User-Agent", USER_AGENT).crossfade(true).build(),
                contentDescription = name,
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter,
                modifier = Modifier.fillMaxSize(),
                loading = { placeholder() },
                error = { placeholder() },
            )
        }
    }
}
