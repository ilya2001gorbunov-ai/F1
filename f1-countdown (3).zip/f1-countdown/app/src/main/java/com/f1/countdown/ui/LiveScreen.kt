@file:OptIn(ExperimentalMaterial3Api::class)

package com.f1.countdown.ui

import com.f1.countdown.data.title
import com.f1.countdown.data.tr
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.produceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.f1.countdown.data.Session
import com.f1.countdown.data.Sessions
import com.f1.countdown.data.Fmt
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.f1.countdown.data.Race
import com.f1.countdown.data.Schedule
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private enum class VideoPlatform(val label: String, val sourceUrl: String, val searchUrl: String) {
    YOUTUBE("YouTube", "https://youtube.com/@stanizlavsky", "https://www.youtube.com/results?search_query="),
    RUTUBE("RuTube", "https://rutube.ru/channel/30588664/", "https://rutube.ru/search/?query="),
    VK("VK Видео", "https://vk.ru/f1commentatorsnews", "https://m.vkvideo.ru/?q=")
}

@Composable
fun LiveScreen() {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf(VideoPlatform.YOUTUBE, VideoPlatform.RUTUBE, VideoPlatform.VK)) }
    val ctx = LocalContext.current.applicationContext
    val now = remember { Instant.now() }
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    val sessions by produceState(Sessions.builtIn()) {
        withContext(Dispatchers.IO) { Sessions.cached(ctx) }?.let { value = it }
        withContext(Dispatchers.IO) { Sessions.fetch(ctx) }?.let { value = it }
    }
    val ordered = sessions.filter { session ->
        val race = Schedule.races.firstOrNull { it.round == session.round } ?: return@filter false
        query.isBlank() || raceMatches(race, query) || normalizeSearch(session.type.ruTitle).contains(normalizeSearch(query)) || normalizeSearch(query).contains("спринт") && session.type.name.contains("SPRINT")
    }.sortedBy { it.start }
    val nearest = ordered.firstOrNull { it.start.isAfter(now) || java.time.Duration.between(it.start, now).toMinutes() < 180L }
    val past = ordered.filter { it.start.isBefore(now) && java.time.Duration.between(it.start, now).toMinutes() >= 180L }.sortedByDescending { it.start }
    LazyColumn(
        modifier = Modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(Modifier.padding(top = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(F1Red))
                    Spacer(Modifier.width(10.dp))
                    Text("LIVE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                }
                Spacer(Modifier.height(4.dp))
                Text("${tr("Эфиры и записи всех сессий.")} (${com.f1.countdown.data.AppSettings.zoneLabel()})", style = MaterialTheme.typography.bodyMedium, color = gray)
                Spacer(Modifier.height(16.dp))
                SearchField(query) { query = it }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VideoPlatform.entries.forEach { platform ->
                        FilterPill(platform.label, platform in selected) {
                            selected = if (platform in selected) selected - platform else selected + platform
                        }
                    }
                }
                if (selected.isEmpty()) {
                    Text(tr("Выберите хотя бы одну площадку"), color = F1Red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        if (nearest != null) {
            item { SectionHeading(tr("БЛИЖАЙШАЯ СЕССИЯ")) }
            item { SessionVideoCard(nearest, selected, isUpcoming = true) }
        }
        if (past.isNotEmpty()) {
            item { SectionHeading(tr("АРХИВ СЕССИЙ")) }
            items(past.size) { index -> SessionVideoCard(past[index], selected, isUpcoming = false) }
        }
        if (nearest == null && past.isEmpty()) item { Text(tr("По запросу ничего не найдено."), color = gray) }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit) {
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    val container = MaterialTheme.colorScheme.surfaceVariant
    TextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        placeholder = { Text(tr("Спринт, Монако, Остин…"), color = gray) },
        leadingIcon = { SearchGlyph(gray) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                Text(
                    "×",
                    fontSize = 24.sp,
                    color = gray,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable { onChange("") }
                        .padding(horizontal = 14.dp, vertical = 2.dp),
                )
            }
        },
        colors = TextFieldDefaults.colors(
            focusedContainerColor = container,
            unfocusedContainerColor = container,
            disabledContainerColor = container,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            cursorColor = F1Red,
        ),
    )
}

@Composable
private fun SearchGlyph(color: Color) {
    Canvas(Modifier.size(20.dp)) {
        val w = size.width
        val stroke = 2.dp.toPx()
        drawCircle(color, radius = w * 0.32f, center = Offset(w * 0.42f, w * 0.42f), style = Stroke(stroke))
        drawLine(color, Offset(w * 0.66f, w * 0.66f), Offset(w * 0.92f, w * 0.92f), strokeWidth = stroke, cap = StrokeCap.Round)
    }
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) F1Red.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, if (selected) F1Red else Color.Transparent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ActionPill(text: String, live: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val line = if (live) F1Red else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
    Box(
        modifier
            .clip(shape)
            .border(1.dp, line, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            (if (live) "● " else "") + text,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = if (live) F1Red else MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun SessionVideoCard(session: Session, selected: Set<VideoPlatform>, isUpcoming: Boolean) {
    val uri = LocalUriHandler.current
    val race = Schedule.races.firstOrNull { it.round == session.round } ?: return
    val now = Instant.now()
    val minutesUntilStart = java.time.Duration.between(now, session.start).toMinutes()
    val minutesSinceStart = java.time.Duration.between(session.start, now).toMinutes()
    val showLive = isUpcoming && minutesUntilStart <= 10L && minutesSinceStart < 180L
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    val platforms = VideoPlatform.entries.filter { it in selected }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                session.type.title.uppercase(),
                fontSize = 11.sp,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Bold,
                color = session.type.color(),
                modifier = Modifier.weight(1f),
            )
            if (showLive) Text("● LIVE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = F1Red)
        }
        Spacer(Modifier.height(6.dp))
        Text("${race.flag} ${race.title}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("${race.city} · ${Fmt.full(session.msk)}", style = MaterialTheme.typography.bodySmall, color = gray)
        if (platforms.isNotEmpty() && (showLive || !isUpcoming)) {
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                platforms.forEach { platform ->
                    ActionPill(platform.label, live = showLive, modifier = Modifier.weight(1f)) {
                        val q = if (showLive) {
                            "прямой эфир, ${session.type.ruTitle}, ${race.city}, ${session.msk.toLocalDate()}"
                        } else {
                            "архив, ${session.type.ruTitle}, ${race.name}, ${race.city}, ${session.msk.toLocalDate()}"
                        }
                        openSearch(uri, platform, q, race)
                    }
                }
            }
        } else if (isUpcoming) {
            Spacer(Modifier.height(10.dp))
            Text(tr("Кнопки эфира появятся за 10 минут до старта"), fontSize = 12.sp, color = gray)
        }
    }
}

@Composable
private fun SectionHeading(title: String) {
    Text(
        title,
        fontSize = 12.sp,
        letterSpacing = 1.5.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 8.dp),
    )
}

@Composable
private fun RaceVideoCard(race: Race, selected: Set<VideoPlatform>, query: String, isUpcoming: Boolean) {
    val uri = LocalUriHandler.current
    val now = Instant.now()
    val start = race.start.toInstant()
    val minutesUntilStart = java.time.Duration.between(now, start).toMinutes()
    val minutesSinceStart = java.time.Duration.between(start, now).toMinutes()
    // Эфир доступен в окне от 10 минут до старта и до 3 часов после старта.
    val showLive = isUpcoming && minutesUntilStart <= 10L && minutesSinceStart < 180L
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(14.dp)) {
            Text("${race.flag} ${if (isUpcoming) tr("Ближайший заезд") else tr("Заезд")}: ${race.title}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("${race.circuit} · ${formatDate(race.date)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            selected.forEach { platform ->
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(platform.label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                    Spacer(Modifier.weight(1f))
                    if (isUpcoming && showLive) {
                        TextButton(onClick = { openSearch(uri, platform, queryFor("", race, "прямой эфир ${race.name} ${race.city} ${race.date}"), race) }) { Text(tr("Эфир")) }
                    }
                    if (!isUpcoming) {
                        TextButton(onClick = { openSearch(uri, platform, queryFor("", race, "прямой эфир ${race.name} ${race.city} ${race.date}"), race) }) { Text(tr("Архив")) }
                    }
                }
            }
        }
    }
}

/** Поиск терпим к дефисам, опечаткам, русским/английским названиям и типам сессий. */
private fun raceMatches(race: Race, query: String): Boolean {
    val q = normalizeSearch(query)
    if (q.isBlank()) return true

    val fields = listOf(race.name, race.circuit, race.city, race.date) + raceAliases(race)
    val normalizedFields = fields.map(::normalizeSearch)
    if (normalizedFields.any { it.contains(q) || q.contains(it) && it.length >= 4 }) return true

    val queryTerms = expandTerms(q.split(' ').filter { it.isNotBlank() })
    val allText = normalizedFields.joinToString(" ")
    val fieldTerms = expandTerms(allText.split(' ').filter { it.isNotBlank() }).toSet()

    // Все значимые слова должны иметь хотя бы приблизительное совпадение.
    // Короткие слова пропускаем, чтобы «гп» и похожие сокращения не давали шум.
    val significant = queryTerms.filter { it.length >= 3 }
    if (significant.isEmpty()) return normalizedFields.any { it.contains(q) }
    val matched = significant.count { term ->
        fieldTerms.any { candidate ->
            candidate.startsWith(term) || term.startsWith(candidate) ||
                (term.length >= 5 && candidate.length >= 5 && editDistanceAtMostOne(term, candidate))
        }
    }
    // OR-подобный поиск для коротких запросов (например, «Монако» или «спринт»),
    // но для длинных фраз требуется совпадение большей части слов.
    return if (significant.size <= 2) matched >= 1 else matched >= (significant.size + 1) / 2
}

private fun raceAliases(race: Race): List<String> {
    val text = "${race.name} ${race.circuit} ${race.city}".lowercase(Locale.ROOT)
    val aliases = mutableListOf<String>()
    if (listOf("monaco", "монако").any { text.contains(it) }) aliases += listOf("Monaco Grand Prix", "Гран-при Монако", "Монако", "Monte Carlo", "Монте-Карло")
    if (listOf("united states", "сша", "америки", "austin", "остин").any { text.contains(it) }) aliases += listOf("US Grand Prix", "Гран-при США", "Гран-при Америк", "Austin", "Остин")
    if (listOf("great britain", "британии", "silverstone", "силверстоун").any { text.contains(it) }) aliases += listOf("British Grand Prix", "Гран-при Великобритании", "Silverstone")
    if (text.contains("sao paulo") || text.contains("сан-паулу")) aliases += listOf("Brazilian Grand Prix", "Гран-при Бразилии", "Interlagos", "Интерлагос")
    return aliases
}

private fun normalizeSearch(value: String): String = value.lowercase(Locale.ROOT)
    .replace('ё', 'е')
    .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
    .trim()
    .replace(Regex("\\s+"), " ")

private fun expandTerms(terms: List<String>): List<String> = terms.flatMap { term ->
    when (term) {
        "гранпри", "гран", "при", "gp", "grandprix", "grand", "prix" -> listOf("гранпри", "grandprix", "gp")
        "спринт", "сприн", "sprint", "спринтквалификация" -> listOf("спринт", "sprint", "квалификация", "qualifying", "shootout")
        "квалификация", "квал", "qualifying", "qualy" -> listOf("квалификация", "qualifying", "qualy", "квал")
        "гонка", "race", "заезд" -> listOf("гонка", "race", "заезд", "grandprix", "гранпри")
        "монако", "monaco", "монте", "карло", "montecarlo" -> listOf("монако", "monaco", "монте", "карло", "montecarlo")
        else -> listOf(term)
    }
}

private fun editDistanceAtMostOne(a: String, b: String): Boolean {
    if (kotlin.math.abs(a.length - b.length) > 1) return false
    var i = 0; var j = 0; var edits = 0
    while (i < a.length && j < b.length) {
        if (a[i] == b[j]) { i++; j++ } else {
            edits++
            if (edits > 1) return false
            if (a.length > b.length) i++ else if (b.length > a.length) j++ else { i++; j++ }
        }
    }
    if (i < a.length || j < b.length) edits++
    return edits <= 1
}

private fun queryFor(userQuery: String, race: Race, kind: String): String {
    val base = "${race.name} ${race.circuit} ${race.city} Formula 1"
    return "$kind, ${race.name}, ${race.city}, ${race.date}"
}

private fun openSearch(handler: androidx.compose.ui.platform.UriHandler, platform: VideoPlatform, query: String, race: Race? = null) {
    // Для VK Видео используем строго заданный пользователем формат: «формула 1, тип заезда, город, год».
    // Не добавляем лишние слова, названия трасс и дату целиком — они ухудшают релевантность выдачи.
    val fullQuery = if (platform == VideoPlatform.VK) {
        val normalized = query.trim()
        val sessionKind = when {
            normalized.contains("Свободная практика 1", true) -> "практика 1"
            normalized.contains("Свободная практика 2", true) -> "практика 2"
            normalized.contains("Свободная практика 3", true) -> "практика 3"
            normalized.contains("спринт-квалификация", true) -> "спринт-квалификация"
            normalized.contains("квалификация", true) -> "квалификация"
            normalized.contains("спринт", true) -> "спринт"
            normalized.contains("гонка", true) -> "гонка"
            else -> "гонка"
        }
        val city = race?.city?.trim().orEmpty()
        val year = race?.let { runCatching { LocalDate.parse(it.date).year }.getOrDefault(it.start.year) }
        listOfNotNull("формула 1", sessionKind, city.ifEmpty { null }, year?.toString()).joinToString(" ")
    } else {
        if (query.trimStart().startsWith("формула 1", ignoreCase = true)) query else "формула 1, $query"
    }
    val encoded = URLEncoder.encode(fullQuery, StandardCharsets.UTF_8.toString()).replace("+", "%20")
    openUrl(handler, platform.searchUrl + encoded)
}

private fun openUrl(handler: androidx.compose.ui.platform.UriHandler, url: String) {
    runCatching { handler.openUri(url) }
}

private fun formatDate(date: String): String = runCatching {
    LocalDate.parse(date).format(DateTimeFormatter.ofPattern("d MMMM yyyy", com.f1.countdown.data.AppSettings.locale))
}.getOrDefault(date)
