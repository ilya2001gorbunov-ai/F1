@file:OptIn(ExperimentalMaterial3Api::class)

package com.f1.countdown.ui

import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.width
import com.f1.countdown.data.title
import com.f1.countdown.data.tr
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.produceState
import androidx.compose.ui.platform.LocalContext
import com.f1.countdown.data.Sessions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.f1.countdown.data.Fmt
import com.f1.countdown.data.LiveState
import com.f1.countdown.data.NewsItem
import com.f1.countdown.data.NewsRepo
import com.f1.countdown.data.Schedule
import com.f1.countdown.data.countdown
import kotlinx.coroutines.launch

@Composable
fun NewsScreen(onOpenLive: () -> Unit = {}) {
    var items by remember { mutableStateOf<List<NewsItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val appCtx = LocalContext.current.applicationContext
    val sessions by produceState(Sessions.builtIn()) {
        withContext(Dispatchers.IO) { Sessions.cached(appCtx) }?.let { value = it }
    }
    // Сессии, чей эфир закончился или скрыт вручную (хранятся на устройстве)
    var hidden by remember { mutableStateOf(LiveState.load(appCtx)) }
    val liveSession by rememberLiveSession(sessions, hidden)
    val live = liveSession

    fun refresh() {
        scope.launch {
            loading = true
            val r = NewsRepo.load()
            if (r.isNotEmpty()) items = r
            failed = r.isEmpty()
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (live != null) {
            item(key = "live-player") {
                LiveStreamCard(live, onOpenLive) { hidden = LiveState.add(appCtx, live) }
            }
        }
        item { NextRaceCard(sessions) }
        item {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                SectionTitle(tr("Новости"))
                if (loading) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = F1Red)
                } else {
                    TextButton(onClick = { refresh() }) { Text(tr("Обновить")) }
                }
            }
        }
        if (failed) {
            item {
                Text(
                    tr("Не удалось загрузить новости. Проверьте интернет и нажмите «Обновить»."),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        items(items) { NewsCard(it) }
    }
}

@Composable
private fun NewsCard(n: NewsItem) {
    val uri = LocalUriHandler.current
    Card(
        onClick = { runCatching { uri.openUri(n.link) } },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column {
            if (n.image != null) {
                AsyncImage(
                    model = n.image,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                )
            }
            Column(Modifier.padding(14.dp)) {
                Text(n.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (n.summary.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        n.summary,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(8.dp))
                val date = n.date?.let { " · " + Fmt.newsDate(it) } ?: ""
                Text(
                    n.source + date,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun NextRaceCard(sessions: List<com.f1.countdown.data.Session>) {
    val now by rememberNow(1000)
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    // ближайшее событие уикенда: практика, квалификация, спринт или гонка
    val session = sessions.filter { now.isBefore(it.start) }.minByOrNull { it.start }
    val race = session?.let { se -> Schedule.races.firstOrNull { it.round == se.round } }
    Card(
        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        if (session == null || race == null) {
            Box(Modifier.padding(24.dp)) { Text(tr("Сезон 2026 завершён. До встречи в новом сезоне!")) }
            return@Card
        }
        val total = java.time.Duration.between(now, session.start).seconds.coerceAtLeast(0)
        Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(6.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(F1Red),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        session.type.title.uppercase(),
                        fontSize = 11.sp,
                        letterSpacing = 1.6.sp,
                        color = F1Red,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    race.title,
                    fontSize = 22.sp,
                    lineHeight = 26.sp,
                    fontWeight = FontWeight.Bold,
                )
                Spacer(Modifier.height(2.dp))
                Text("${race.flag}  ${race.circuit}", fontSize = 13.sp, color = gray)
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.Top) {
                    CountCell((total / 86400).toString(), tr("ДНЕЙ"))
                    CountColon()
                    CountCell(Fmt.two2(total % 86400 / 3600), tr("ЧАСОВ"))
                    CountColon()
                    CountCell(Fmt.two2(total % 3600 / 60), tr("МИНУТ"))
                    CountColon()
                    CountCell(Fmt.two2(total % 60), tr("СЕК"))
                }
                Spacer(Modifier.height(14.dp))
                Text(Fmt.full(session.msk), fontSize = 12.sp, color = gray, letterSpacing = 0.3.sp)
            }
            Spacer(Modifier.width(8.dp))
            TrackImage(race, Modifier.size(80.dp), stroke = 2.dp)
        }
    }
}

@Composable
private fun CountCell(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            value,
            style = androidx.compose.ui.text.TextStyle(
                fontSize = 30.sp,
                fontWeight = FontWeight.Light,
                fontFeatureSettings = "tnum",
            ),
        )
        Text(label, fontSize = 8.sp, letterSpacing = 1.2.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun CountColon() {
    Text(
        ":",
        fontSize = 24.sp,
        fontWeight = FontWeight.Light,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.padding(horizontal = 5.dp),
    )
}
