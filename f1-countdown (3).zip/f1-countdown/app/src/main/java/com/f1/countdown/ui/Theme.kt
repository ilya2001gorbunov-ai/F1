package com.f1.countdown.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.material3.Typography
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.f1.countdown.R

val F1Red = Color(0xFFE10600)

private val Scheme = darkColorScheme(
    primary = F1Red,
    onPrimary = Color.White,
    background = Color(0xFF0B0B0D),
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF0B0B0D),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF17171B),
    onSurfaceVariant = Color(0xFF9A9AA3),
)

/** Шрифт приложения: Inter Display (свободная лицензия OFL) — геометричный, близкий к фирменному стилю F1. */
val F1Font = FontFamily(
    Font(R.font.inter_display_light, FontWeight.Light),
    Font(R.font.inter_display_regular, FontWeight.Normal),
    Font(R.font.inter_display_medium, FontWeight.Medium),
    Font(R.font.inter_display_bold, FontWeight.Bold),
    Font(R.font.inter_display_bold, FontWeight.Black),
    Font(R.font.inter_display_medium, FontWeight.SemiBold),
)

private val F1Typography = Typography().let { t ->
    t.copy(
        displayLarge = t.displayLarge.copy(fontFamily = F1Font),
        displayMedium = t.displayMedium.copy(fontFamily = F1Font),
        displaySmall = t.displaySmall.copy(fontFamily = F1Font),
        headlineLarge = t.headlineLarge.copy(fontFamily = F1Font),
        headlineMedium = t.headlineMedium.copy(fontFamily = F1Font),
        headlineSmall = t.headlineSmall.copy(fontFamily = F1Font),
        titleLarge = t.titleLarge.copy(fontFamily = F1Font),
        titleMedium = t.titleMedium.copy(fontFamily = F1Font),
        titleSmall = t.titleSmall.copy(fontFamily = F1Font),
        bodyLarge = t.bodyLarge.copy(fontFamily = F1Font),
        bodyMedium = t.bodyMedium.copy(fontFamily = F1Font),
        bodySmall = t.bodySmall.copy(fontFamily = F1Font),
        labelLarge = t.labelLarge.copy(fontFamily = F1Font),
        labelMedium = t.labelMedium.copy(fontFamily = F1Font),
        labelSmall = t.labelSmall.copy(fontFamily = F1Font),
    )
}

@Composable
fun F1Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = F1Typography, content = content)
}
