package com.f1.countdown.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.time.Instant
import java.time.ZoneId
import java.util.Locale
import java.util.TimeZone

/** Настройки: язык и часовой пояс. Значение «auto» — определять по устройству. */
object AppSettings {
    private const val PREFS = "app_settings"

    var langPref by mutableStateOf("auto")
        private set
    var zonePref by mutableStateOf("auto")
        private set

    /** Читает сохранённые настройки (можно вызывать сколько угодно раз). */
    fun load(ctx: Context) {
        try {
            val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            langPref = p.getString("lang", "auto") ?: "auto"
            zonePref = p.getString("zone", "auto") ?: "auto"
        } catch (_: Exception) {
        }
    }

    fun setLang(ctx: Context, value: String) {
        langPref = value
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("lang", value).apply()
    }

    fun setZone(ctx: Context, value: String) {
        zonePref = value
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("zone", value).apply()
    }

    /** Код языка: выбранный, а при «авто» — язык устройства, если он поддерживается, иначе русский. */
    val lang: String
        get() {
            val pref = langPref
            if (pref != "auto") return pref
            val dev = Locale.getDefault().language
            return APP_LANGS.firstOrNull { it.code == dev }?.code ?: "ru"
        }

    val locale: Locale get() = Locale.forLanguageTag(lang)

    /** Часовой пояс, в котором показывается всё время в приложении. */
    val zone: ZoneId
        get() {
            val pref = zonePref
            if (pref == "auto") return ZoneId.systemDefault()
            return try {
                ZoneId.of(pref)
            } catch (_: Exception) {
                ZoneId.systemDefault()
            }
        }

    fun offsetLabel(zone: ZoneId, at: Instant = Instant.now()): String {
        val secs = zone.rules.getOffset(at).totalSeconds
        val sign = if (secs < 0) "-" else "+"
        val abs = Math.abs(secs)
        val h = abs / 3600
        val m = abs % 3600 / 60
        return "UTC$sign$h" + if (m != 0) ":" + m.toString().padStart(2, '0') else ""
    }

    /** Подпись часового пояса рядом со временем: «МСК», «UTC+5». */
    fun zoneLabel(at: Instant = Instant.now()): String {
        val z = zone
        if (z.id == "Europe/Moscow") return if (lang == "ru") "МСК" else "MSK"
        return offsetLabel(z, at)
    }

    /** Часовые пояса для выбора: страны СНГ и несколько популярных. */
    val ZONES = listOf(
        "Europe/Kaliningrad", "Europe/Moscow", "Europe/Samara", "Asia/Yekaterinburg", "Asia/Omsk",
        "Asia/Novosibirsk", "Asia/Krasnoyarsk", "Asia/Irkutsk", "Asia/Yakutsk", "Asia/Vladivostok",
        "Asia/Magadan", "Asia/Kamchatka", "Europe/Minsk", "Europe/Kiev", "Europe/Chisinau",
        "Asia/Tbilisi", "Asia/Yerevan", "Asia/Baku", "Asia/Almaty", "Asia/Aqtobe", "Asia/Tashkent",
        "Asia/Bishkek", "Asia/Dushanbe", "Asia/Ashgabat", "Europe/Istanbul", "Asia/Dubai",
        "Europe/London", "Europe/Berlin", "America/New_York", "UTC",
    )

    fun zoneName(id: String): String =
        TimeZone.getTimeZone(id).getDisplayName(false, TimeZone.LONG, locale)
}
