package com.f1.countdown.data

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.time.Duration
import java.time.Instant
import java.time.ZonedDateTime
import kotlin.math.abs

enum class SessionType(val ruTitle: String) {
    FP1("Свободная практика 1"),
    FP2("Свободная практика 2"),
    FP3("Свободная практика 3"),
    SPRINT_QUALI("Спринт-квалификация"),
    SPRINT("Спринт"),
    QUALI("Квалификация"),
    RACE("Гонка"),
    ;

    /** Название на выбранном языке; ruTitle — русское (нужно для поисковых запросов). */
    val title: String get() = tr(ruTitle)
}

data class Session(val round: Int, val type: SessionType, val start: Instant) {
    val msk: ZonedDateTime get() = start.atZone(MSK)
}

/**
 * Расписание всех сессий уикенда. Источник — те же данные, что на f1calendar.com
 * (репозиторий sportstimes/f1). Полный календарь зашит в приложение (работает офлайн),
 * при запуске он обновляется из интернета и кэшируется.
 */
object Sessions {
    private const val CACHE = "sessions_f1calendar_2026.json"
    private val URLS = listOf(
        "https://raw.githubusercontent.com/sportstimes/f1/main/_db/f1/2026.json",
        "https://cdn.jsdelivr.net/gh/sportstimes/f1@main/_db/f1/2026.json",
    )

    fun builtIn(): List<Session> = try {
        parse(BUILTIN_JSON)
    } catch (_: Exception) {
        Schedule.races.map { Session(it.round, SessionType.RACE, it.start.toInstant()) }
    }

    fun cached(ctx: Context): List<Session>? = try {
        val f = File(ctx.filesDir, CACHE)
        if (f.exists()) parse(f.readText()).takeIf { it.isNotEmpty() } else null
    } catch (_: Exception) {
        null
    }

    fun fetch(ctx: Context): List<Session>? {
        for (url in URLS) {
            try {
                val text = Http.getString(url)
                val result = parse(text)
                if (result.size >= Schedule.races.size) {
                    File(ctx.filesDir, CACHE).writeText(text)
                    return result
                }
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun instant(s: String?): Instant? =
        if (s.isNullOrEmpty()) null else runCatching { Instant.parse(s) }.getOrNull()

    /** Гонки из файла сопоставляются с нашим списком по времени старта гонки (не по номеру этапа). */
    private fun parse(text: String): List<Session> {
        val races = JSONObject(text).getJSONArray("races")
        val out = ArrayList<Session>()
        for (i in 0 until races.length()) {
            val r = races.getJSONObject(i)
            if (r.optBoolean("tbc", false)) continue
            val sessions = r.optJSONObject("sessions") ?: continue
            val gp = instant(sessions.optString("gp")) ?: continue
            val mine = Schedule.races.minByOrNull {
                abs(Duration.between(it.start.toInstant(), gp).toMinutes())
            } ?: continue
            if (abs(Duration.between(mine.start.toInstant(), gp).toHours()) > 36) continue
            for (key in sessions.keys()) {
                val type = when (key) {
                    "fp1" -> SessionType.FP1
                    "fp2" -> SessionType.FP2
                    "fp3" -> SessionType.FP3
                    "qualifying" -> SessionType.QUALI
                    "sprintQualifying", "sprintShootout" -> SessionType.SPRINT_QUALI
                    "sprint" -> SessionType.SPRINT
                    "gp" -> SessionType.RACE
                    else -> continue
                }
                // Время гонки берём из нашего списка (оно же в виджете), чтобы везде совпадало
                val t = if (type == SessionType.RACE) mine.start.toInstant()
                else instant(sessions.optString(key)) ?: continue
                out.add(Session(mine.round, type, t))
            }
        }
        return out.sortedBy { it.start }
    }

    private const val BUILTIN_JSON = """{"races":[{"name":"Australian","round":1,"sessions":{"fp1":"2026-03-06T01:30:00Z","fp2":"2026-03-06T05:00:00Z","fp3":"2026-03-07T01:30:00Z","qualifying":"2026-03-07T05:00:00Z","gp":"2026-03-08T04:00:00Z"}},{"name":"Chinese","round":2,"sessions":{"fp1":"2026-03-13T03:30:00Z","sprintQualifying":"2026-03-13T07:30:00Z","sprint":"2026-03-14T03:00:00Z","qualifying":"2026-03-14T07:00:00Z","gp":"2026-03-15T07:00:00Z"}},{"name":"Japanese","round":3,"sessions":{"fp1":"2026-03-27T02:30:00Z","fp2":"2026-03-27T06:00:00Z","fp3":"2026-03-28T02:30:00Z","qualifying":"2026-03-28T06:00:00Z","gp":"2026-03-29T05:00:00Z"}},{"name":"Miami","round":4,"sessions":{"fp1":"2026-05-01T16:00:00Z","sprintQualifying":"2026-05-01T20:30:00Z","sprint":"2026-05-02T16:00:00Z","qualifying":"2026-05-02T20:00:00Z","gp":"2026-05-03T17:00:00Z"}},{"name":"Canadian","round":5,"sessions":{"fp1":"2026-05-22T16:30:00Z","sprintQualifying":"2026-05-22T20:30:00Z","sprint":"2026-05-23T16:00:00Z","qualifying":"2026-05-23T20:00:00Z","gp":"2026-05-24T20:00:00Z"}},{"name":"Monaco","round":6,"sessions":{"fp1":"2026-06-05T11:30:00Z","fp2":"2026-06-05T15:00:00Z","fp3":"2026-06-06T10:30:00Z","qualifying":"2026-06-06T14:00:00Z","gp":"2026-06-07T13:00:00Z"}},{"name":"Barcelona","round":7,"sessions":{"fp1":"2026-06-12T11:30:00Z","fp2":"2026-06-12T15:00:00Z","fp3":"2026-06-13T10:30:00Z","qualifying":"2026-06-13T14:00:00Z","gp":"2026-06-14T13:00:00Z"}},{"name":"Austrian","round":8,"sessions":{"fp1":"2026-06-26T11:30:00Z","fp2":"2026-06-26T15:00:00Z","fp3":"2026-06-27T10:30:00Z","qualifying":"2026-06-27T14:00:00Z","gp":"2026-06-28T13:00:00Z"}},{"name":"British","round":9,"sessions":{"fp1":"2026-07-03T11:30:00Z","sprintQualifying":"2026-07-03T15:30:00Z","sprint":"2026-07-04T11:00:00Z","qualifying":"2026-07-04T15:00:00Z","gp":"2026-07-05T14:00:00Z"}},{"name":"Belgian","round":10,"sessions":{"fp1":"2026-07-17T11:30:00Z","fp2":"2026-07-17T15:00:00Z","fp3":"2026-07-18T10:30:00Z","qualifying":"2026-07-18T14:00:00Z","gp":"2026-07-19T13:00:00Z"}},{"name":"Hungarian","round":11,"sessions":{"fp1":"2026-07-24T11:30:00Z","fp2":"2026-07-24T15:00:00Z","fp3":"2026-07-25T10:30:00Z","qualifying":"2026-07-25T14:00:00Z","gp":"2026-07-26T13:00:00Z"}},{"name":"Dutch","round":12,"sessions":{"fp1":"2026-08-21T10:30:00Z","sprintQualifying":"2026-08-21T14:30:00Z","sprint":"2026-08-22T10:00:00Z","qualifying":"2026-08-22T14:00:00Z","gp":"2026-08-23T13:00:00Z"}},{"name":"Italian","round":13,"sessions":{"fp1":"2026-09-04T10:30:00Z","fp2":"2026-09-04T14:00:00Z","fp3":"2026-09-05T10:30:00Z","qualifying":"2026-09-05T14:00:00Z","gp":"2026-09-06T13:00:00Z"}},{"name":"Spanish","round":14,"sessions":{"fp1":"2026-09-11T11:30:00Z","fp2":"2026-09-11T15:00:00Z","fp3":"2026-09-12T10:30:00Z","qualifying":"2026-09-12T14:00:00Z","gp":"2026-09-13T13:00:00Z"}},{"name":"Azerbaijan","round":15,"sessions":{"fp1":"2026-09-24T08:30:00Z","fp2":"2026-09-24T12:00:00Z","fp3":"2026-09-25T08:30:00Z","qualifying":"2026-09-25T12:00:00Z","gp":"2026-09-26T11:00:00Z"}},{"name":"Singapore","round":17,"sessions":{"fp1":"2026-10-09T08:30:00Z","sprintQualifying":"2026-10-09T12:30:00Z","sprint":"2026-10-10T09:00:00Z","qualifying":"2026-10-10T13:00:00Z","gp":"2026-10-11T12:00:00Z"}},{"name":"United States","round":18,"sessions":{"fp1":"2026-10-23T17:30:00Z","fp2":"2026-10-23T21:00:00Z","fp3":"2026-10-24T17:30:00Z","qualifying":"2026-10-24T21:00:00Z","gp":"2026-10-25T20:00:00Z"}},{"name":"Mexican","round":19,"sessions":{"fp1":"2026-10-30T18:30:00Z","fp2":"2026-10-30T22:00:00Z","fp3":"2026-10-31T17:30:00Z","qualifying":"2026-10-31T21:00:00Z","gp":"2026-11-01T20:00:00Z"}},{"name":"Brazilian","round":20,"sessions":{"fp1":"2026-11-06T15:30:00Z","fp2":"2026-11-06T19:00:00Z","fp3":"2026-11-07T14:30:00Z","qualifying":"2026-11-07T18:00:00Z","gp":"2026-11-08T17:00:00Z"}},{"name":"Las Vegas","round":21,"sessions":{"fp1":"2026-11-20T00:30:00Z","fp2":"2026-11-20T04:00:00Z","fp3":"2026-11-21T00:30:00Z","qualifying":"2026-11-21T04:00:00Z","gp":"2026-11-22T04:00:00Z"}},{"name":"Qatar","round":22,"sessions":{"fp1":"2026-11-27T13:30:00Z","fp2":"2026-11-27T17:00:00Z","fp3":"2026-11-28T14:30:00Z","qualifying":"2026-11-28T18:00:00Z","gp":"2026-11-29T16:00:00Z"}},{"name":"Abu Dhabi","round":23,"sessions":{"fp1":"2026-12-04T09:30:00Z","fp2":"2026-12-04T13:00:00Z","fp3":"2026-12-05T10:30:00Z","qualifying":"2026-12-05T14:00:00Z","gp":"2026-12-06T13:00:00Z"}}]}"""
}
