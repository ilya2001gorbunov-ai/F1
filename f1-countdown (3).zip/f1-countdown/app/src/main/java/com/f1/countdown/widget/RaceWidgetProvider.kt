package com.f1.countdown.widget

import com.f1.countdown.data.place
import com.f1.countdown.data.AppSettings
import com.f1.countdown.data.tr
import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.widget.RemoteViews
import com.f1.countdown.MainActivity
import com.f1.countdown.R
import com.f1.countdown.data.FlagArt
import com.f1.countdown.data.FlagColors
import com.f1.countdown.data.FlagPalette
import com.f1.countdown.data.Fmt
import com.f1.countdown.data.Schedule
import com.f1.countdown.data.Sessions
import com.f1.countdown.data.SessionType
import com.f1.countdown.data.TrackRepo
import com.f1.countdown.data.countdown
import kotlin.concurrent.thread

/** Виды виджетов. */
enum class WidgetKind(
    private val ruTitle: String,
    val provider: Class<out RaceWidgetProvider>,
    val layout: Int,
    val compact: Boolean,
    val flagColors: Boolean,
) {
    CLASSIC("Классический 4×2", RaceWidgetProvider::class.java, R.layout.widget_race, false, false),
    SMALL("Компактный 2×2", RaceWidgetSmallProvider::class.java, R.layout.widget_race_small, true, false),
    FLAG("Цвета флага 4×2", RaceWidgetFlagProvider::class.java, R.layout.widget_race, false, true),
    ;

    val title: String get() = tr(ruTitle)
}

/** Минималистичный виджет: контур трассы на прозрачном фоне, дата/время по МСК и обратный отсчёт. */
open class RaceWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            AppWidgetManager.ACTION_APPWIDGET_UPDATE,
            AppWidgetManager.ACTION_APPWIDGET_OPTIONS_CHANGED,
            AppWidgetManager.ACTION_APPWIDGET_ENABLED,
            AppWidgetManager.ACTION_APPWIDGET_DISABLED,
            ACTION_TICK,
            -> {
                val pending = goAsync()
                thread {
                    try {
                        updateAll(context.applicationContext)
                    } catch (_: Throwable) {
                    } finally {
                        pending.finish()
                    }
                }
            }
        }
    }

    companion object {
        const val ACTION_TICK = "com.f1.countdown.WIDGET_TICK"

        /** Попросить виджеты обновиться (вызывается при запуске приложения). */
        fun refresh(context: Context) {
            context.sendBroadcast(
                Intent(context, RaceWidgetProvider::class.java).setAction(ACTION_TICK),
            )
        }

        /** Предложить пользователю добавить виджет на главный экран. */
        fun requestPin(context: Context, kind: WidgetKind = WidgetKind.CLASSIC): Boolean {
            val mgr = AppWidgetManager.getInstance(context)
            return if (mgr.isRequestPinAppWidgetSupported) {
                // после добавления сразу перерисовываем виджеты
                val done = PendingIntent.getBroadcast(
                    context,
                    2,
                    Intent(context, kind.provider).setAction(ACTION_TICK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                )
                mgr.requestPinAppWidget(ComponentName(context, kind.provider), null, done)
            } else {
                false
            }
        }

        /** Готовый виджет для показа «примера» внутри приложения. */
        fun previewViews(context: Context, kind: WidgetKind): RemoteViews = buildViews(context, kind, preview = true)

        private fun tickIntent(context: Context): PendingIntent = PendingIntent.getBroadcast(
            context,
            1,
            Intent(context, RaceWidgetProvider::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        private fun cancelTick(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(tickIntent(context))
        }

        private fun scheduleNextTick(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val next = (System.currentTimeMillis() / 60_000 + 1) * 60_000 + 500
            am.setAndAllowWhileIdle(AlarmManager.RTC, next, tickIntent(context))
        }

        /** Обновляет все виджеты всех видов; если ни одного нет — выключает таймер. */
        private fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            var any = false
            for (kind in WidgetKind.entries) {
                val ids = mgr.getAppWidgetIds(ComponentName(context, kind.provider))
                if (ids.isEmpty()) continue
                any = true
                val views = buildViews(context, kind)
                for (id in ids) mgr.updateAppWidget(id, views)
            }
            if (any) scheduleNextTick(context) else cancelTick(context)
        }

        private fun shortType(t: SessionType): String = when (t) {
            SessionType.FP1 -> "ПРАКТИКА 1"
            SessionType.FP2 -> "ПРАКТИКА 2"
            SessionType.FP3 -> "ПРАКТИКА 3"
            SessionType.SPRINT_QUALI -> "СПРИНТ-КВАЛИФ."
            SessionType.SPRINT -> "СПРИНТ"
            SessionType.QUALI -> "КВАЛИФИКАЦИЯ"
            SessionType.RACE -> "ГОНКА"
        }

        private fun buildViews(context: Context, kind: WidgetKind, preview: Boolean = false): RemoteViews {
            AppSettings.load(context)
            val v = RemoteViews(context.packageName, kind.layout)
            v.setTextViewText(R.id.w_ld, tr("ДНЕЙ"))
            v.setTextViewText(R.id.w_lh, tr("ЧАСОВ"))
            v.setTextViewText(R.id.w_lm, tr("МИНУТ"))
            // В примере (окно «Добавить виджет») переход в приложение не нужен: касание обрабатывает само окно
            if (!preview) {
                val open = PendingIntent.getActivity(
                    context,
                    0,
                    Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                )
                v.setOnClickPendingIntent(R.id.w_root, open)
            }

            // Ближайшее событие уикенда: практика, квалификация, спринт или гонка
            val now = java.time.Instant.now()
            val all = Sessions.cached(context) ?: Sessions.builtIn()
            val session = all.filter { now.isBefore(it.start) }.minByOrNull { it.start }
            val race = session?.let { se -> Schedule.races.firstOrNull { it.round == se.round } }
            if (session == null || race == null) {
                v.setTextViewText(R.id.w_title, tr("СЕЗОН ЗАВЕРШЁН"))
                v.setTextViewText(R.id.w_date, if (kind.compact) tr("до встречи!") else tr("до встречи в новом сезоне"))
                v.setTextViewText(R.id.w_d, "--")
                v.setTextViewText(R.id.w_h, "--")
                v.setTextViewText(R.id.w_m, "--")
                v.setViewVisibility(R.id.w_track, View.GONE)
                return v
            }

            val total = java.time.Duration.between(now, session.start).seconds.coerceAtLeast(0)
            val title = if (kind.compact) {
                if (AppSettings.lang == "ru") shortType(session.type) else session.type.title.uppercase()
            } else {
                "${session.type.title} · ${race.place}".uppercase()
            }
            val date = if (kind.compact) {
                "${Fmt.shortDate(session.msk)} · ${Fmt.hm(session.msk)}"
            } else {
                Fmt.full(session.msk)
            }
            v.setTextViewText(R.id.w_title, title)
            v.setTextViewText(R.id.w_date, date)
            v.setTextViewText(R.id.w_d, (total / 86400).toString())
            v.setTextViewText(R.id.w_h, Fmt.two2(total % 86400 / 3600))
            v.setTextViewText(R.id.w_m, Fmt.two2(total % 3600 / 60))

            val points = TrackRepo.points(context, race)
            v.setViewVisibility(R.id.w_track, View.VISIBLE)
            val bitmap = if (kind.flagColors) {
                // толстая трасса, на поверхности — настоящий флаг страны
                drawTrack(points, 512, 40f, FlagArt.bitmap(context, race.flag), FlagColors.of(race.flag), true)
            } else {
                drawTrack(points, 360, 9f, null, null, false)
            }
            v.setImageViewBitmap(R.id.w_track, bitmap)
            return v
        }

        /**
         * Контур трассы на прозрачном фоне. Обычный вариант — белая линия.
         * Флаговый — толстая линия, залитая изображением флага страны (или полосами, если флаг не получилось нарисовать).
         */
        private fun drawTrack(
            p: FloatArray,
            size: Int,
            stroke: Float,
            flag: Bitmap?,
            palette: FlagPalette?,
            thick: Boolean,
        ): Bitmap {
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val pad = if (thick) stroke * 0.5f + 8f else stroke * 2.5f
            val side = size - 2 * pad
            val path = Path()
            for (i in 0 until p.size / 2) {
                val x = pad + p[i * 2] * side
                val y = pad + p[i * 2 + 1] * side
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }

            fun basePaint(width: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = width
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }

            if (!thick || (flag == null && palette == null)) {
                val paint = basePaint(stroke).apply {
                    color = Color.WHITE
                    setShadowLayer(stroke * 0.8f, 0f, stroke * 0.3f, 0x80000000.toInt())
                }
                canvas.drawPath(path, paint)
                return bmp
            }

            // тёмная полупрозрачная кайма — отделяет трассу от любых обоев
            canvas.drawPath(path, basePaint(stroke + 5f).apply { color = 0x99000000.toInt() })

            val b = RectF()
            path.computeBounds(b, true)
            val shader: Shader = if (flag != null) {
                // Прямоугольник, который должен быть закрыт флагом целиком: контур трассы + половина толщины линии
                val rw = b.width() + stroke + 2f
                val rh = b.height() + stroke + 2f
                var sx = rw / flag.width
                var sy = rh / flag.height
                // Флаг тянется под форму трассы, но не сильнее чем в ~1,6 раза (иначе круг превратится в блин);
                // лишнее обрезается, флаг всегда остаётся больше области — пустых мест нет
                val ratio = sx / sy
                if (ratio > 1.6f) sy = sx / 1.6f else if (ratio < 0.62f) sx = sy * 0.62f
                val tw = Math.round(flag.width * sx).coerceAtLeast(1)
                val th = Math.round(flag.height * sy).coerceAtLeast(1)
                // Заранее приводим флаг к нужному размеру с фильтрацией — так он остаётся чётким
                var scaled: Bitmap = flag
                while (scaled.width > tw * 2) {
                    scaled = Bitmap.createScaledBitmap(scaled, scaled.width / 2, scaled.height / 2, true)
                }
                scaled = Bitmap.createScaledBitmap(scaled, tw, th, true)
                val bs = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                val m = Matrix()
                m.postTranslate(b.centerX() - tw / 2f, b.centerY() - th / 2f)
                bs.setLocalMatrix(m)
                bs
            } else {
                val pal = palette!!
                val n = pal.colors.size
                val colors = IntArray(n * 2)
                val positions = FloatArray(n * 2)
                for (i in 0 until n) {
                    colors[i * 2] = pal.colors[i]
                    colors[i * 2 + 1] = pal.colors[i]
                    positions[i * 2] = i.toFloat() / n
                    positions[i * 2 + 1] = (i + 1).toFloat() / n
                }
                if (pal.vertical) {
                    LinearGradient(b.left, 0f, b.right.coerceAtLeast(b.left + 1f), 0f, colors, positions, Shader.TileMode.CLAMP)
                } else {
                    LinearGradient(0f, b.top, 0f, b.bottom.coerceAtLeast(b.top + 1f), colors, positions, Shader.TileMode.CLAMP)
                }
            }
            canvas.drawPath(
                path,
                basePaint(stroke).apply {
                    this.shader = shader
                    isFilterBitmap = true
                    isDither = true
                },
            )
            return bmp
        }
    }
}

class RaceWidgetSmallProvider : RaceWidgetProvider()

class RaceWidgetFlagProvider : RaceWidgetProvider()
