package com.f1.countdown.data

import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit

/** Часовой пояс пользователя (по умолчанию — устройства): все даты и время в приложении показываются в нём. */
val MSK: ZoneId get() = AppSettings.zone

data class Race(
    val round: Int,
    val name: String,
    val circuit: String,
    val city: String,
    val flag: String,
    val zone: String,
    val date: String, // местная дата гонки yyyy-MM-dd
    val time: String, // местное время старта HH:mm
    val lat: Double,
    val lon: Double,
) {
    val start: ZonedDateTime
        get() = ZonedDateTime.of(LocalDate.parse(date), LocalTime.parse(time), ZoneId.of(zone))

    val startMsk: ZonedDateTime
        get() = start.withZoneSameInstant(MSK)

    /** Считаем гонку «идущей» ещё 2 часа после старта. */
    val end: Instant
        get() = start.toInstant().plus(2, ChronoUnit.HOURS)
}

object Schedule {
    val races: List<Race> = listOf(
        Race(1, "Гран-при Австралии", "Альберт-Парк", "Мельбурн", "🇦🇺", "Australia/Melbourne", "2026-03-08", "15:00", -37.8497, 144.968),
        Race(2, "Гран-при Китая", "Шанхай", "Шанхай", "🇨🇳", "Asia/Shanghai", "2026-03-15", "15:00", 31.3389, 121.2198),
        Race(3, "Гран-при Японии", "Сузука", "Судзука", "🇯🇵", "Asia/Tokyo", "2026-03-29", "14:00", 34.8431, 136.5407),
        Race(4, "Гран-при Майами", "Майами", "Майами", "🇺🇸", "America/New_York", "2026-05-03", "16:00", 25.9581, -80.2389),
        Race(5, "Гран-при Канады", "Жиль-Вильнёв", "Монреаль", "🇨🇦", "America/Toronto", "2026-05-24", "16:00", 45.5, -73.5228),
        Race(6, "Гран-при Монако", "Монте-Карло", "Монако", "🇲🇨", "Europe/Monaco", "2026-06-07", "15:00", 43.7347, 7.4206),
        Race(7, "Гран-при Барселоны", "Барселона-Каталунья", "Монтмело", "🇪🇸", "Europe/Madrid", "2026-06-14", "15:00", 41.57, 2.2611),
        Race(8, "Гран-при Австрии", "Ред Булл Ринг", "Шпильберг", "🇦🇹", "Europe/Vienna", "2026-06-28", "15:00", 47.2197, 14.7647),
        Race(9, "Гран-при Великобритании", "Сильверстоун", "Сильверстоун", "🇬🇧", "Europe/London", "2026-07-05", "15:00", 52.0786, -1.0169),
        Race(10, "Гран-при Бельгии", "Спа-Франкоршам", "Спа", "🇧🇪", "Europe/Brussels", "2026-07-19", "15:00", 50.4372, 5.9714),
        Race(11, "Гран-при Венгрии", "Хунгароринг", "Могёрод", "🇭🇺", "Europe/Budapest", "2026-07-26", "15:00", 47.5789, 19.2486),
        Race(12, "Гран-при Нидерландов", "Зандфорт", "Зандфорт", "🇳🇱", "Europe/Amsterdam", "2026-08-23", "15:00", 52.3888, 4.5409),
        Race(13, "Гран-при Италии", "Монца", "Монца", "🇮🇹", "Europe/Rome", "2026-09-06", "15:00", 45.6156, 9.2811),
        Race(14, "Гран-при Испании", "Мадринг", "Мадрид", "🇪🇸", "Europe/Madrid", "2026-09-13", "15:00", 40.4655, -3.6107),
        Race(15, "Гран-при Азербайджана", "Баку", "Баку", "🇦🇿", "Asia/Baku", "2026-09-26", "15:00", 40.3725, 49.8533),
        Race(16, "Гран-при Сингапура", "Марина-Бэй", "Сингапур", "🇸🇬", "Asia/Singapore", "2026-10-11", "20:00", 1.2914, 103.864),
        Race(17, "Гран-при США", "Circuit of the Americas", "Остин", "🇺🇸", "America/Chicago", "2026-10-25", "15:00", 30.1328, -97.6411),
        Race(18, "Гран-при Мексики", "Эрманос Родригес", "Мехико", "🇲🇽", "America/Mexico_City", "2026-11-01", "14:00", 19.4042, -99.0907),
        Race(19, "Гран-при Сан-Паулу", "Интерлагос", "Сан-Паулу", "🇧🇷", "America/Sao_Paulo", "2026-11-08", "14:00", -23.7036, -46.6997),
        Race(20, "Гран-при Лас-Вегаса", "Лас-Вегас", "Лас-Вегас", "🇺🇸", "America/Los_Angeles", "2026-11-21", "20:00", 36.1147, -115.1728),
        Race(21, "Гран-при Катара", "Лусаил", "Лусаил", "🇶🇦", "Asia/Qatar", "2026-11-29", "19:00", 25.49, 51.4542),
        Race(22, "Гран-при Абу-Даби", "Яс-Марина", "Абу-Даби", "🇦🇪", "Asia/Dubai", "2026-12-06", "17:00", 24.4672, 54.6031),
    )

    /** Ближайшая (или идущая прямо сейчас) гонка. */
    fun next(now: Instant = Instant.now()): Race? = races.firstOrNull { now.isBefore(it.end) }
}

data class Countdown(val days: Long, val hours: Long, val minutes: Long, val seconds: Long, val started: Boolean)

fun countdown(race: Race, now: Instant = Instant.now()): Countdown {
    val startInstant = race.start.toInstant()
    val total = Duration.between(now, startInstant).seconds.coerceAtLeast(0)
    return Countdown(
        days = total / 86400,
        hours = total % 86400 / 3600,
        minutes = total % 3600 / 60,
        seconds = total % 60,
        started = !now.isBefore(startInstant),
    )
}

object Fmt {
    private val monthsGen = arrayOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря",
    )
    private val monthsNom = arrayOf(
        "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
        "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
    )
    private val weekdaysRu = arrayOf("пн", "вт", "ср", "чт", "пт", "сб", "вс")
    private val monthsShortRu = arrayOf(
        "янв", "фев", "мар", "апр", "мая", "июн",
        "июл", "авг", "сен", "окт", "ноя", "дек",
    )

    private val ru: Boolean get() = AppSettings.lang == "ru"

    fun weekdays(): List<String> =
        if (ru) weekdaysRu.toList()
        else (1..7).map { java.time.DayOfWeek.of(it).getDisplayName(java.time.format.TextStyle.SHORT, AppSettings.locale) }

    private fun weekday(d: ZonedDateTime): String = weekdays()[d.dayOfWeek.value - 1]

    private fun monthGen(m: Int): String =
        if (ru) monthsGen[m - 1]
        else java.time.Month.of(m).getDisplayName(java.time.format.TextStyle.FULL, AppSettings.locale)

    private fun monthShort(m: Int): String =
        if (ru) monthsShortRu[m - 1]
        else java.time.Month.of(m).getDisplayName(java.time.format.TextStyle.SHORT, AppSettings.locale)

    fun monthName(month: Int): String =
        if (ru) {
            monthsNom[month - 1]
        } else {
            java.time.Month.of(month).getDisplayName(java.time.format.TextStyle.FULL_STANDALONE, AppSettings.locale)
                .replaceFirstChar { it.uppercase(AppSettings.locale) }
        }

    private fun two(v: Int) = v.toString().padStart(2, '0')

    /** «25 октября, вс» (в часовом поясе пользователя) */
    fun dateMsk(r: Race): String {
        val d = r.startMsk
        return "${d.dayOfMonth} ${monthGen(d.monthValue)}, ${weekday(d)}"
    }

    /** «23:00 МСК» */
    fun timeMsk(r: Race): String {
        val d = r.startMsk
        return "${two(d.hour)}:${two(d.minute)} ${AppSettings.zoneLabel(d.toInstant())}"
    }

    /** «25 октября, вс · 23:00 МСК» */
    fun full(r: Race): String = "${dateMsk(r)} · ${timeMsk(r)}"

    /** «сб 24 окт» */
    fun shortDate(d: ZonedDateTime): String =
        "${weekday(d)} ${d.dayOfMonth} ${monthShort(d.monthValue)}"

    /** «20:30» */
    fun hm(d: ZonedDateTime): String = "${two(d.hour)}:${two(d.minute)}"

    /** «24 октября, сб · 20:30 МСК» */
    fun full(d: ZonedDateTime): String =
        "${d.dayOfMonth} ${monthGen(d.monthValue)}, ${weekday(d)} · ${hm(d)} ${AppSettings.zoneLabel(d.toInstant())}"

    fun newsDate(epochMs: Long): String {
        val d = Instant.ofEpochMilli(epochMs).atZone(MSK)
        return "${d.dayOfMonth} ${monthGen(d.monthValue)}, ${two(d.hour)}:${two(d.minute)}"
    }

    fun two2(v: Long): String = v.toString().padStart(2, '0')
}
