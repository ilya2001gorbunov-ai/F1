package com.f1.countdown.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class DriverStanding(
    val pos: String,
    val name: String,
    val teamId: String,
    val team: String,
    val points: String,
    val wins: String,
    val wiki: String = "",
)

data class TeamStanding(
    val pos: String,
    val teamId: String,
    val team: String,
    val points: String,
    val wins: String,
)

class StandingsData(val drivers: List<DriverStanding>, val teams: List<TeamStanding>)

/** Личный и командный зачёт текущего сезона (api.jolpi.ca). */
object StandingsRepo {
    private fun list(path: String, listKey: String): org.json.JSONArray {
        val text = Http.getString("https://api.jolpi.ca/ergast/f1/current/$path.json?limit=100")
        val lists = JSONObject(text).getJSONObject("MRData").getJSONObject("StandingsTable")
            .getJSONArray("StandingsLists")
        return lists.optJSONObject(0)?.optJSONArray(listKey) ?: org.json.JSONArray()
    }

    suspend fun load(): StandingsData? = withContext(Dispatchers.IO) {
        try {
            val d = list("driverstandings", "DriverStandings")
            val drivers = (0 until d.length()).map { i ->
                val r = d.getJSONObject(i)
                val drv = r.getJSONObject("Driver")
                val c = r.optJSONArray("Constructors")?.optJSONObject(0)
                DriverStanding(
                    pos = r.optString("position", (i + 1).toString()),
                    name = DriverNames.name(drv.optString("familyName"), drv.optString("givenName")),
                    teamId = c?.optString("constructorId") ?: "",
                    team = c?.optString("name") ?: "",
                    points = r.optString("points"),
                    wins = r.optString("wins"),
                    wiki = drv.optString("url"),
                )
            }
            val t = list("constructorstandings", "ConstructorStandings")
            val teams = (0 until t.length()).map { i ->
                val r = t.getJSONObject(i)
                val c = r.getJSONObject("Constructor")
                TeamStanding(
                    pos = r.optString("position", (i + 1).toString()),
                    teamId = c.optString("constructorId"),
                    team = c.optString("name"),
                    points = r.optString("points"),
                    wins = r.optString("wins"),
                )
            }
            if (drivers.isEmpty() && teams.isEmpty()) null else StandingsData(drivers, teams)
        } catch (_: Exception) {
            null
        }
    }
}
