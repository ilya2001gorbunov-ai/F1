@file:OptIn(ExperimentalMaterial3Api::class)

package com.f1.countdown.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.f1.countdown.data.Schedule
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private enum class VideoPlatform(val label: String, val base: String) {
    YOUTUBE("YouTube", "https://www.youtube.com/results?search_query="),
    RUTUBE("RuTube", "https://rutube.ru/search/?query="),
    VK("VK Видео", "https://vk.com/video?q=")
}

@Composable
fun LiveScreen() {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf(VideoPlatform.YOUTUBE, VideoPlatform.RUTUBE, VideoPlatform.VK)) }
    val uri = LocalUriHandler.current
    val races = remember {
        Schedule.races.sortedByDescending { runCatching { LocalDate.parse(it.date) }.getOrNull() }
    }
    val filtered = races.filter { race ->
        query.isBlank() || listOf(race.name, race.circuit, race.city, race.date).any { it.contains(query, true) }
    }

    LazyColumn(
        modifier = Modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                Text("LIVE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = F1Red)
                Text("Прямые эфиры и записи заездов", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Поиск гонки или трассы") },
                    placeholder = { Text("Например, Сильверстоун или Гран-при США") }
                )
                Spacer(Modifier.height(8.dp))
                Text("Искать на площадках", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    VideoPlatform.entries.forEach { platform ->
                        AssistChip(
                            onClick = { selected = if (platform in selected) selected - platform else selected + platform },
                            label = { Text((if (platform in selected) "✓ " else "") + platform.label) }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Выберите гонку и тип видео — откроется поиск на выбранных платформах. Доступность эфиров зависит от правообладателей и региона.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (selected.isEmpty()) {
            item { Text("Выберите хотя бы одну площадку.", color = F1Red) }
        }
        items(filtered, key = { it.round }) { race ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp)) {
                    Text("${race.flag} ${race.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${race.circuit} · ${formatDate(race.date)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    selected.forEach { platform ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(platform.label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                            TextButton(onClick = { openSearch(uri, platform, queryFor(query, race.name, race.circuit, "прямая трансляция")) }) {
                                Text("▶ Эфир")
                            }
                            TextButton(onClick = { openSearch(uri, platform, queryFor(query, race.name, race.circuit, "полная запись гонки replay")) }) {
                                Text("▣ Запись")
                            }
                        }
                    }
                }
            }
        }
        if (filtered.isEmpty()) item { Text("Ничего не найдено. Попробуйте изменить запрос.") }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

private fun queryFor(userQuery: String, raceName: String, circuit: String, kind: String): String {
    val target = if (userQuery.isBlank()) "$raceName $circuit Formula 1" else "$userQuery Formula 1 $raceName $circuit"
    return "$target $kind"
}

private fun openSearch(handler: androidx.compose.ui.platform.UriHandler, platform: VideoPlatform, query: String) {
    val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
    runCatching { handler.openUri(platform.base + encoded) }
}

private fun formatDate(date: String): String = runCatching {
    LocalDate.parse(date).format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("ru")))
}.getOrDefault(date)
