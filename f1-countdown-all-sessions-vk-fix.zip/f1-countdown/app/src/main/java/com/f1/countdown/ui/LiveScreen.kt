@file:OptIn(ExperimentalMaterial3Api::class)

package com.f1.countdown.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.produceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.f1.countdown.data.Session
import com.f1.countdown.data.Sessions
import com.f1.countdown.data.Fmt
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.f1.countdown.data.Race
import com.f1.countdown.data.Schedule
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private enum class VideoPlatform(val label: String, val sourceUrl: String, val searchUrl: String) {
    YOUTUBE("YouTube", "https://youtube.com/@stanizlavsky", "https://www.youtube.com/results?search_query="),
    RUTUBE("RuTube", "https://rutube.ru/channel/30588664/", "https://rutube.ru/search/?query="),
    VK("VK Видео", "https://vk.ru/f1commentatorsnews", "https://vk.com/video?q=")
}

@Composable
fun LiveScreen() {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf(VideoPlatform.YOUTUBE, VideoPlatform.RUTUBE, VideoPlatform.VK)) }
    val uri = LocalUriHandler.current
    val ctx = LocalContext.current.applicationContext
    val now = remember { Instant.now() }
    val sessions by produceState(Sessions.builtIn()) {
        withContext(Dispatchers.IO) { Sessions.cached(ctx) }?.let { value = it }
        withContext(Dispatchers.IO) { Sessions.fetch(ctx) }?.let { value = it }
    }
    val ordered = sessions.filter { session ->
        val race = Schedule.races.firstOrNull { it.round == session.round } ?: return@filter false
        query.isBlank() || raceMatches(race, query) || normalizeSearch(session.type.title).contains(normalizeSearch(query)) || normalizeSearch(query).contains("спринт") && session.type.name.contains("SPRINT")
    }.sortedBy { it.start }
    val nearest = ordered.firstOrNull { it.start.isAfter(now) || java.time.Duration.between(it.start, now).toMinutes() < 180L }
    val past = ordered.filter { it.start.isBefore(now) && java.time.Duration.between(it.start, now).toMinutes() >= 180L }.sortedByDescending { it.start }
    LazyColumn(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column {
                Text("🔴 LIVE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = F1Red)
                Text("Эфиры и записи всех сессий Формулы 1", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Поиск заезда или трассы") }, placeholder = { Text("Например, спринт, Монако или Остин") })
                Spacer(Modifier.height(8.dp)); Text("Площадки", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    VideoPlatform.entries.forEach { platform -> AssistChip(onClick = { selected = if (platform in selected) selected - platform else selected + platform }, label = { Text((if (platform in selected) "✓ " else "") + platform.label) }) }
                }
                Spacer(Modifier.height(4.dp))
                Text("Показаны ближайшая сессия и архив предыдущих сессий. Время московское.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (selected.isEmpty()) Text("Выберите хотя бы одну площадку.", color = F1Red)
            }
        }
        if (nearest != null) {
            item { SectionHeading("БЛИЖАЙШАЯ СЕССИЯ") }
            item { SessionVideoCard(nearest, selected, isUpcoming = true) }
        }
        if (past.isNotEmpty()) {
            item { SectionHeading("АРХИВ СЕССИЙ") }
            items(past.size) { index -> SessionVideoCard(past[index], selected, isUpcoming = false) }
        }
        if (nearest == null && past.isEmpty()) item { Text("По запросу ничего не найдено.") }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun SessionVideoCard(session: Session, selected: Set<VideoPlatform>, isUpcoming: Boolean) {
    val uri = LocalUriHandler.current
    val race = Schedule.races.firstOrNull { it.round == session.round } ?: return
    val now = Instant.now()
    val minutesUntilStart = java.time.Duration.between(now, session.start).toMinutes()
    val minutesSinceStart = java.time.Duration.between(session.start, now).toMinutes()
    val showLive = isUpcoming && minutesUntilStart <= 10L && minutesSinceStart < 180L
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(14.dp)) {
            Text("${race.flag} ${session.type.title} · ${race.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("${race.city} · ${Fmt.full(session.msk)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            selected.forEach { platform ->
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(platform.label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                    Spacer(Modifier.weight(1f))
                    if (showLive) TextButton(onClick = { openSearch(uri, platform, "прямой эфир, ${session.type.title}, ${race.city}, ${session.msk.toLocalDate()}") }) { Text("Эфир") }
                    if (!isUpcoming) TextButton(onClick = { openSearch(uri, platform, "прямой эфир, ${session.type.title}, ${race.city}, ${session.msk.toLocalDate()}") }) { Text("Архив") }
                }
            }
        }
    }
}

@Composable
private fun SectionHeading(title: String) {
    Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.ExtraBold, color = F1Red, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun RaceVideoCard(race: Race, selected: Set<VideoPlatform>, query: String, isUpcoming: Boolean) {
    val uri = LocalUriHandler.current
    val now = Instant.now()
    val start = race.start.toInstant()
    val minutesUntilStart = java.time.Duration.between(now, start).toMinutes()
    val minutesSinceStart = java.time.Duration.between(start, now).toMinutes()
    // Эфир доступен в окне от 10 минут до старта и до 3 часов после старта.
    val showLive = isUpcoming && minutesUntilStart <= 10L && minutesSinceStart < 180L
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(14.dp)) {
            Text("${race.flag} ${if (isUpcoming) "Ближайший заезд" else "Заезд"}: ${race.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("${race.circuit} · ${formatDate(race.date)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            selected.forEach { platform ->
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(platform.label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                    Spacer(Modifier.weight(1f))
                    if (isUpcoming && showLive) {
                        TextButton(onClick = { openSearch(uri, platform, queryFor("", race, "прямой эфир ${race.name} ${race.city} ${race.date}")) }) { Text("Эфир") }
                    }
                    if (!isUpcoming) {
                        TextButton(onClick = { openSearch(uri, platform, queryFor("", race, "прямой эфир ${race.name} ${race.city} ${race.date}")) }) { Text("Архив") }
                    }
                }
            }
        }
    }
}

/** Поиск терпим к дефисам, опечаткам, русским/английским названиям и типам сессий. */
private fun raceMatches(race: Race, query: String): Boolean {
    val q = normalizeSearch(query)
    if (q.isBlank()) return true

    val fields = listOf(race.name, race.circuit, race.city, race.date) + raceAliases(race)
    val normalizedFields = fields.map(::normalizeSearch)
    if (normalizedFields.any { it.contains(q) || q.contains(it) && it.length >= 4 }) return true

    val queryTerms = expandTerms(q.split(' ').filter { it.isNotBlank() })
    val allText = normalizedFields.joinToString(" ")
    val fieldTerms = expandTerms(allText.split(' ').filter { it.isNotBlank() }).toSet()

    // Все значимые слова должны иметь хотя бы приблизительное совпадение.
    // Короткие слова пропускаем, чтобы «гп» и похожие сокращения не давали шум.
    val significant = queryTerms.filter { it.length >= 3 }
    if (significant.isEmpty()) return normalizedFields.any { it.contains(q) }
    val matched = significant.count { term ->
        fieldTerms.any { candidate ->
            candidate.startsWith(term) || term.startsWith(candidate) ||
                (term.length >= 5 && candidate.length >= 5 && editDistanceAtMostOne(term, candidate))
        }
    }
    // OR-подобный поиск для коротких запросов (например, «Монако» или «спринт»),
    // но для длинных фраз требуется совпадение большей части слов.
    return if (significant.size <= 2) matched >= 1 else matched >= (significant.size + 1) / 2
}

private fun raceAliases(race: Race): List<String> {
    val text = "${race.name} ${race.circuit} ${race.city}".lowercase(Locale.ROOT)
    val aliases = mutableListOf<String>()
    if (listOf("monaco", "монако").any { text.contains(it) }) aliases += listOf("Monaco Grand Prix", "Гран-при Монако", "Монако", "Monte Carlo", "Монте-Карло")
    if (listOf("united states", "сша", "америки", "austin", "остин").any { text.contains(it) }) aliases += listOf("US Grand Prix", "Гран-при США", "Гран-при Америк", "Austin", "Остин")
    if (listOf("great britain", "британии", "silverstone", "силверстоун").any { text.contains(it) }) aliases += listOf("British Grand Prix", "Гран-при Великобритании", "Silverstone")
    if (text.contains("sao paulo") || text.contains("сан-паулу")) aliases += listOf("Brazilian Grand Prix", "Гран-при Бразилии", "Interlagos", "Интерлагос")
    return aliases
}

private fun normalizeSearch(value: String): String = value.lowercase(Locale.ROOT)
    .replace('ё', 'е')
    .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
    .trim()
    .replace(Regex("\\s+"), " ")

private fun expandTerms(terms: List<String>): List<String> = terms.flatMap { term ->
    when (term) {
        "гранпри", "гран", "при", "gp", "grandprix", "grand", "prix" -> listOf("гранпри", "grandprix", "gp")
        "спринт", "сприн", "sprint", "спринтквалификация" -> listOf("спринт", "sprint", "квалификация", "qualifying", "shootout")
        "квалификация", "квал", "qualifying", "qualy" -> listOf("квалификация", "qualifying", "qualy", "квал")
        "гонка", "race", "заезд" -> listOf("гонка", "race", "заезд", "grandprix", "гранпри")
        "монако", "monaco", "монте", "карло", "montecarlo" -> listOf("монако", "monaco", "монте", "карло", "montecarlo")
        else -> listOf(term)
    }
}

private fun editDistanceAtMostOne(a: String, b: String): Boolean {
    if (kotlin.math.abs(a.length - b.length) > 1) return false
    var i = 0; var j = 0; var edits = 0
    while (i < a.length && j < b.length) {
        if (a[i] == b[j]) { i++; j++ } else {
            edits++
            if (edits > 1) return false
            if (a.length > b.length) i++ else if (b.length > a.length) j++ else { i++; j++ }
        }
    }
    if (i < a.length || j < b.length) edits++
    return edits <= 1
}

private fun queryFor(userQuery: String, race: Race, kind: String): String {
    val base = "${race.name} ${race.circuit} ${race.city} Formula 1"
    return "$kind, ${race.name}, ${race.city}, ${race.date}"
}

private fun openSearch(handler: androidx.compose.ui.platform.UriHandler, platform: VideoPlatform, query: String) {
    val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
    openUrl(handler, platform.searchUrl + encoded)
}

private fun openUrl(handler: androidx.compose.ui.platform.UriHandler, url: String) {
    runCatching { handler.openUri(url) }
}

private fun formatDate(date: String): String = runCatching {
    LocalDate.parse(date).format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("ru")))
}.getOrDefault(date)
