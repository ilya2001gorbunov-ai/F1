@file:OptIn(ExperimentalMaterial3Api::class)

package com.f1.countdown.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.f1.countdown.widget.RaceWidgetProvider

@Composable
fun App() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val ctx = LocalContext.current
    val bg = MaterialTheme.colorScheme.background

    Scaffold(
        containerColor = bg,
        topBar = {
            TopAppBar(
                title = {
                    Text("FORMULA 1", fontWeight = FontWeight.Black, letterSpacing = 2.sp, color = F1Red)
                },
                actions = {
                    TextButton(onClick = {
                        if (!RaceWidgetProvider.requestPin(ctx)) {
                            Toast.makeText(
                                ctx,
                                "Долгое нажатие на рабочем столе → Виджеты → F1 Календарь",
                                Toast.LENGTH_LONG,
                            ).show()
                        }
                    }) { Text("+ Виджет") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = bg),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("📰") },
                    label = { Text("Новости") },
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("📅") },
                    label = { Text("Календарь") },
                )
                NavigationBarItem(
                    selected = tab == 2,
                    onClick = { tab = 2 },
                    icon = { Text("▶") },
                    label = { Text("LIVE") },
                )
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> NewsScreen(); 1 -> CalendarScreen(); else -> LiveScreen() }
        }
    }
}
