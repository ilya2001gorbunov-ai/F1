@file:OptIn(ExperimentalMaterial3Api::class)

package com.f1.countdown.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.f1.countdown.data.Race
import com.f1.countdown.data.Schedule
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private enum class VideoPlatform(val label: String, val sourceUrl: String, val searchUrl: String) {
    YOUTUBE("YouTube", "https://youtube.com/@stanizlavsky", "https://www.youtube.com/results?search_query="),
    RUTUBE("RuTube", "https://rutube.ru/channel/30588664/", "https://rutube.ru/search/?query="),
    VK("VK Видео", "https://vk.ru/f1commentatorsnews", "https://vkvideo.ru/search?q=")
}

@Composable
fun LiveScreen() {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf(VideoPlatform.YOUTUBE, VideoPlatform.RUTUBE, VideoPlatform.VK)) }
    val uri = LocalUriHandler.current
    val now = remember { Instant.now() }
    val allRaces = remember { Schedule.races }
    val upcoming = allRaces.filter { it.start.toInstant().isAfter(now) }.minByOrNull { it.start.toInstant() }
    val pastRaces = allRaces.filter { race ->
        race.start.toInstant().isBefore(now) && (query.isBlank() || raceMatches(race, query))
    }.sortedByDescending { it.start.toInstant() }
    val showUpcoming = upcoming?.takeIf { query.isBlank() || raceMatches(it, query) }

    LazyColumn(
        modifier = Modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                Text("LIVE 🔴", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = F1Red)
                Text("Эфиры и записи с официальных страниц авторов", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Поиск заезда или трассы") },
                    placeholder = { Text("Например, Остин или Гран-при США") }
                )
                Spacer(Modifier.height(8.dp))
                Text("Площадки", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    VideoPlatform.entries.forEach { platform ->
                        AssistChip(
                            onClick = { selected = if (platform in selected) selected - platform else selected + platform },
                            label = { Text((if (platform in selected) "✓ " else "") + platform.label) }
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("В первую очередь показывается ближайший предстоящий заезд. Более поздние будущие этапы скрыты; ниже идут прошедшие этапы от новых к старым.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (selected.isEmpty()) Text("Выберите хотя бы одну площадку.", color = F1Red)
            }
        }

        if (showUpcoming != null) {
            item { SectionHeading("БЛИЖАЙШИЙ ЗАЕЗД") }
            item { RaceVideoCard(showUpcoming, selected, query, isUpcoming = true) }
        }
        if (query.isNotBlank() && showUpcoming == null && pastRaces.isEmpty()) {
            item { Text("По запросу ничего не найдено. Попробуйте другое название.") }
        }
        if (pastRaces.isNotEmpty()) {
            item { SectionHeading("ЗАПИСИ ПРОШЕДШИХ ЭТАПОВ") }
            items(pastRaces.size) { index ->
                RaceVideoCard(pastRaces[index], selected, query, isUpcoming = false)
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun SectionHeading(title: String) {
    Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.ExtraBold, color = F1Red, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun RaceVideoCard(race: Race, selected: Set<VideoPlatform>, query: String, isUpcoming: Boolean) {
    val uri = LocalUriHandler.current
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(14.dp)) {
            Text("${race.flag} ${if (isUpcoming) "Ближайший заезд" else "Заезд"}: ${race.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("${race.circuit} · ${formatDate(race.date)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            selected.forEach { platform ->
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(platform.label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = {
                        if (isUpcoming) openUrl(uri, platform.sourceUrl)
                        else openSearch(uri, platform, queryFor(query, race, "полная запись заезда replay"))
                    }) { Text(if (isUpcoming) "Открыть канал" else "Запись") }
                    val minutesUntilStart = if (isUpcoming) java.time.Duration.between(Instant.now(), race.start.toInstant()).toMinutes() else Long.MAX_VALUE
                    if (!isUpcoming || minutesUntilStart >= 10L) {
                        TextButton(onClick = { openSearch(uri, platform, queryFor(query, race, "прямая трансляция live")) }) { Text("Поиск эфира") }
                    }
                }
            }
        }
    }
}

/** Поиск терпим к дефисам, опечаткам, русским/английским названиям и типам сессий. */
private fun raceMatches(race: Race, query: String): Boolean {
    val q = normalizeSearch(query)
    if (q.isBlank()) return true

    val fields = listOf(race.name, race.circuit, race.city, race.date) + raceAliases(race)
    val normalizedFields = fields.map(::normalizeSearch)
    if (normalizedFields.any { it.contains(q) || q.contains(it) && it.length >= 4 }) return true

    val queryTerms = expandTerms(q.split(' ').filter { it.isNotBlank() })
    val allText = normalizedFields.joinToString(" ")
    val fieldTerms = expandTerms(allText.split(' ').filter { it.isNotBlank() }).toSet()

    // Все значимые слова должны иметь хотя бы приблизительное совпадение.
    // Короткие слова пропускаем, чтобы «гп» и похожие сокращения не давали шум.
    val significant = queryTerms.filter { it.length >= 3 }
    if (significant.isEmpty()) return normalizedFields.any { it.contains(q) }
    val matched = significant.count { term ->
        fieldTerms.any { candidate ->
            candidate.startsWith(term) || term.startsWith(candidate) ||
                (term.length >= 5 && candidate.length >= 5 && editDistanceAtMostOne(term, candidate))
        }
    }
    // OR-подобный поиск для коротких запросов (например, «Монако» или «спринт»),
    // но для длинных фраз требуется совпадение большей части слов.
    return if (significant.size <= 2) matched >= 1 else matched >= (significant.size + 1) / 2
}

private fun raceAliases(race: Race): List<String> {
    val text = "${race.name} ${race.circuit} ${race.city}".lowercase(Locale.ROOT)
    val aliases = mutableListOf<String>()
    if (listOf("monaco", "монако").any { text.contains(it) }) aliases += listOf("Monaco Grand Prix", "Гран-при Монако", "Монако", "Monte Carlo", "Монте-Карло")
    if (listOf("united states", "сша", "америки", "austin", "остин").any { text.contains(it) }) aliases += listOf("US Grand Prix", "Гран-при США", "Гран-при Америк", "Austin", "Остин")
    if (listOf("great britain", "британии", "silverstone", "силверстоун").any { text.contains(it) }) aliases += listOf("British Grand Prix", "Гран-при Великобритании", "Silverstone")
    if (text.contains("sao paulo") || text.contains("сан-паулу")) aliases += listOf("Brazilian Grand Prix", "Гран-при Бразилии", "Interlagos", "Интерлагос")
    return aliases
}

private fun normalizeSearch(value: String): String = value.lowercase(Locale.ROOT)
    .replace('ё', 'е')
    .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
    .trim()
    .replace(Regex("\\s+"), " ")

private fun expandTerms(terms: List<String>): List<String> = terms.flatMap { term ->
    when (term) {
        "гранпри", "гран", "при", "gp", "grandprix", "grand", "prix" -> listOf("гранпри", "grandprix", "gp")
        "спринт", "сприн", "sprint", "спринтквалификация" -> listOf("спринт", "sprint", "квалификация", "qualifying", "shootout")
        "квалификация", "квал", "qualifying", "qualy" -> listOf("квалификация", "qualifying", "qualy", "квал")
        "гонка", "race", "заезд" -> listOf("гонка", "race", "заезд", "grandprix", "гранпри")
        "монако", "monaco", "монте", "карло", "montecarlo" -> listOf("монако", "monaco", "монте", "карло", "montecarlo")
        else -> listOf(term)
    }
}

private fun editDistanceAtMostOne(a: String, b: String): Boolean {
    if (kotlin.math.abs(a.length - b.length) > 1) return false
    var i = 0; var j = 0; var edits = 0
    while (i < a.length && j < b.length) {
        if (a[i] == b[j]) { i++; j++ } else {
            edits++
            if (edits > 1) return false
            if (a.length > b.length) i++ else if (b.length > a.length) j++ else { i++; j++ }
        }
    }
    if (i < a.length || j < b.length) edits++
    return edits <= 1
}

private fun queryFor(userQuery: String, race: Race, kind: String): String {
    val base = "${race.name} ${race.circuit} ${race.city} Formula 1"
    return "${if (userQuery.isBlank()) base else "$userQuery $base"} $kind"
}

private fun openSearch(handler: androidx.compose.ui.platform.UriHandler, platform: VideoPlatform, query: String) {
    val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
    openUrl(handler, platform.searchUrl + encoded)
}

private fun openUrl(handler: androidx.compose.ui.platform.UriHandler, url: String) {
    runCatching { handler.openUri(url) }
}

private fun formatDate(date: String): String = runCatching {
    LocalDate.parse(date).format(DateTimeFormatter.ofPattern("d MMMM yyyy", Locale("ru")))
}.getOrDefault(date)
